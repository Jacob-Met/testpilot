"""Probe the unchanged public liveness predicate against two owned finite workers."""
import ast
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "original/tests/test_sandbox_interrupt.py"
OUT = ROOT / "evidence/original-oracle"
OUT.mkdir()
source = SOURCE.read_bytes()
assert hashlib.sha1(b"blob " + str(len(source)).encode() + b"\0" + source).hexdigest() == "184e969e57fc2a483b6a4e7b1709e16f66ce37e6"
tree = ast.parse(source)
names = ("command_if_running", "is_owned_running")
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(selected) == 2
ns = {"subprocess": subprocess}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE), "exec"), ns)
worker = next(ast.literal_eval(n.value) for n in tree.body
              if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "WORKER" for t in n.targets))

def identity(pid):
    proc = Path("/proc") / str(pid)
    stat = (proc / "stat").read_text()
    fields = stat[stat.rindex(")") + 2:].split()
    argv = [x.decode() for x in (proc / "cmdline").read_bytes().split(b"\0") if x]
    return {"pid": pid, "state": fields[0], "ppid": int(fields[1]), "pgid": int(fields[2]),
            "session": int(fields[3]), "start_ticks": int(fields[19]), "argv": argv,
            "exe": os.readlink(proc / "exe"), "raw_stat": stat}

results = []
for label, folder in [
    ("short", ROOT / "s"),
    ("long", ROOT / ("long-worker-location-" + "x" * 120)),
]:
    folder.mkdir()
    script = folder / "worker.py"
    script.write_text(worker)
    argv = [sys.executable, str(script), "child", "escape-wait", str(folder)]
    process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, start_new_session=True)
    before = None
    try:
        deadline = time.monotonic() + 3
        while not (folder / "child.json").exists():
            assert process.poll() is None
            assert time.monotonic() < deadline
            time.sleep(0.01)
        info = json.loads((folder / "child.json").read_text())
        before = identity(process.pid)
        assert info["pid"] == process.pid and before["argv"] == argv
        assert before["pgid"] == process.pid and before["session"] == process.pid
        plain = subprocess.run(["ps", "-p", str(process.pid), "-o", "stat=", "-o", "command="],
                               capture_output=True, text=True, timeout=1)
        original_result = ns["is_owned_running"](info, folder)
        wide = subprocess.run(["ps", "-ww", "-p", str(process.pid), "-o", "stat=", "-o", "command="],
                              capture_output=True, text=True, timeout=1)
        after = identity(process.pid)
        for suffix, result in (("plain", plain), ("wide", wide)):
            (OUT / (label + "-" + suffix + ".stdout")).write_text(result.stdout)
            (OUT / (label + "-" + suffix + ".stderr")).write_text(result.stderr)
        fields = wide.stdout.strip().split(None, 1)
        wide_result = (wide.returncode == 0 and len(fields) == 2
                       and not fields[0].startswith("Z") and str(script) in fields[1])
        live_identity = (process.poll() is None and before["start_ticks"] == after["start_ticks"]
                         and after["argv"] == argv and after["state"] != "Z")
        row = {"case": label, "worker_path": str(script), "worker_path_chars": len(str(script)),
               "native_worker_original_bytes": True, "before": before, "after": after,
               "popen_poll": process.poll(), "reliable_live_identity": live_identity,
               "unchanged_is_owned_running": original_result, "wide_equivalent_predicate": wide_result,
               "plain": {"returncode": plain.returncode, "stdout": plain.stdout, "stderr": plain.stderr,
                         "stdout_bytes": len(plain.stdout.encode())},
               "wide": {"returncode": wide.returncode, "stdout": wide.stdout, "stderr": wide.stderr,
                        "stdout_bytes": len(wide.stdout.encode())}}
        results.append(row)
        print(json.dumps(row), flush=True)
    finally:
        if process.poll() is None:
            current = identity(process.pid)
            assert before is not None and current["start_ticks"] == before["start_ticks"]
            assert current["argv"] == argv
            process.send_signal(signal.SIGTERM)
        process.wait(timeout=2)
        if results and results[-1]["case"] == label:
            results[-1]["owned_worker_reaped_returncode"] = process.returncode

receipt = {"source_head": "95a3116c175debdf97fd9dc1c984a587a90a5d3b",
           "source_blob": "184e969e57fc2a483b6a4e7b1709e16f66ce37e6",
           "source_sha256": hashlib.sha256(source).hexdigest(),
           "python": sys.version, "cases": results,
           "production_modified": False, "test_modified": False,
           "all_workers_owned_finite_and_reaped": True,
           "note": "The -ww command is a diagnostic only; no candidate test has been made or executed."}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("RECEIPT " + str(OUT / "receipt.json"), flush=True)
