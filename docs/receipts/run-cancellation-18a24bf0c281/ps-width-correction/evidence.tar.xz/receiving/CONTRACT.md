# Before-change liveness oracle receiving

Canonical input: TestPilot PR43 head 95a3116c175debdf97fd9dc1c984a587a90a5d3b. The public test blob is 184e969e57fc2a483b6a4e7b1709e16f66ce37e6. Production sandbox blob is 84330f96ebd71b37dc40575fa2ac59ba53cf2a72 and is not edited.

Extract only the unchanged command_if_running and is_owned_running function ASTs and exact WORKER string from the public test. Run that native finite worker at a short and a long owned path. Before any test edit, record original predicate, plain ps bytes, unlimited-width ps bytes, /proc command-line/state/start identity, and the parent Popen state. The direct Popen handles and exact /proc argv/start identity authorize only cleanup of these own two workers.

Expected evidence needed to support the proposed correction: the long-path worker remains the same live non-zombie process while the original predicate says false, the full worker path is absent only from width-limited ps output, and the unlimited-width equivalent predicate sees it. The short-path control should remain identifiable. If native evidence does not show this, do not assume truncation caused the hosted failure.

Only after preserving that observation may the public test's ps argv gain -ww. Preserve the complete worker-path predicate, zombie refusal, process-group guards, finite fixture deadlines and all four focused process cases. Qualify the exact focused tests against unchanged production; do not replay unrelated suites.
