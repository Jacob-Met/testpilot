"""Observation-only pytest plugin: return the original ps result without alteration."""
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
TRACE = ROOT / "evidence/pytest-original-observed/ps-trace.jsonl"
_ORIGINAL_RUN = subprocess.run

def identity(pid):
    try:
        folder = Path("/proc") / str(pid)
        stat = (folder / "stat").read_text()
        fields = stat[stat.rindex(")") + 2:].split()
        argv = [part.decode() for part in (folder / "cmdline").read_bytes().split(b"\0") if part]
        return {"pid":pid, "state":fields[0], "pgid":int(fields[2]),
                "session":int(fields[3]), "start_ticks":int(fields[19]), "argv":argv}
    except (FileNotFoundError, ProcessLookupError):
        return None

def observed_run(*args, **kwargs):
    command = args[0] if args else kwargs.get("args")
    selected = (isinstance(command, list) and len(command) == 7
                and command[:2] == ["ps", "-p"]
                and command[3:] == ["-o", "stat=", "-o", "command="])
    if not selected:
        return _ORIGINAL_RUN(*args, **kwargs)
    pid = int(command[2])
    before = identity(pid)
    started = time.monotonic()
    original = _ORIGINAL_RUN(*args, **kwargs)
    after = identity(pid)
    wide = _ORIGINAL_RUN(["ps", "-ww", *command[1:]], capture_output=True,
                         text=True, timeout=1)
    final = identity(pid)
    fds = {}
    for fd in (0, 1, 2):
        info = {"isatty":os.isatty(fd)}
        try: info["terminal_size"] = list(os.get_terminal_size(fd))
        except OSError: info["terminal_size"] = None
        fds[str(fd)] = info
    row = {"command":command, "kwargs":kwargs, "original_returncode":original.returncode,
           "original_stdout":original.stdout, "original_stderr":original.stderr,
           "wide_returncode":wide.returncode, "wide_stdout":wide.stdout,
           "wide_stderr":wide.stderr, "identity_before":before, "identity_after":after,
           "identity_final":final, "elapsed_s":time.monotonic()-started,
           "columns_env":os.environ.get("COLUMNS"), "fds":fds,
           "returned_original_result_unmodified":True}
    with TRACE.open("a") as output:
        output.write(json.dumps(row, sort_keys=True)+"\n")
    return original

def pytest_sessionstart(session):
    assert not TRACE.exists()
    subprocess.run = observed_run

def pytest_sessionfinish(session, exitstatus):
    subprocess.run = _ORIGINAL_RUN
