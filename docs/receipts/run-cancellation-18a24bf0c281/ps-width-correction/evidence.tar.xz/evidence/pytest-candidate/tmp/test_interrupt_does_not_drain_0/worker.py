import json, os, pathlib, subprocess, sys, time
role, mode, folder = sys.argv[1:]
root = pathlib.Path(folder)
deadline = time.monotonic() + 8
info = {"pid": os.getpid(), "pgid": os.getpgrp(), "role": role}
(root / (role + ".json")).write_text(json.dumps(info))
if role == "leader":
    child = subprocess.Popen(
        [sys.executable, __file__, "child", mode, folder],
        start_new_session=mode.startswith("escape"),
    )
    while not (root / "child.json").exists() and time.monotonic() < deadline:
        time.sleep(0.01)
    (root / "ready").write_text("Both fixture processes have started")
    print("leader-ready", flush=True)
    if mode.endswith("exit"):
        raise SystemExit(0)
while time.monotonic() < deadline:
    time.sleep(0.01)
