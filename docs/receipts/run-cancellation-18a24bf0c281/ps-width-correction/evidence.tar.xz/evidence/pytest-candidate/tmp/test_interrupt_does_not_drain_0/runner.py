import json, os, pathlib, sys
from testpilot.sandbox import _run, clean_env
root = pathlib.Path(sys.argv[1])
try:
    result = _run([sys.executable, str(root / "worker.py"), "leader",
                   sys.argv[2], str(root)], root, clean_env(root), 12)
except KeyboardInterrupt:
    info = json.loads((root / "leader.json").read_text())
    try:
        waited = os.waitpid(info["pid"], os.WNOHANG)
        # A live child returns (0, 0); a zombie reaped here was not reaped by _run.
        reaped = False
    except ChildProcessError:
        waited, reaped = None, True
    receipt = {"kind": "KeyboardInterrupt", "leader_reaped_before_return": reaped,
               "waitpid_probe": waited}
else:
    receipt = {"kind": "returned_result", "result": result}
(root / "interrupt.json").write_text(json.dumps(receipt))
