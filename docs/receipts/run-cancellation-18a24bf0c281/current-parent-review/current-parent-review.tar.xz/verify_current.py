"""Static current-parent/whitelist review. Does not import or execute TestPilot."""
from pathlib import Path
from datetime import datetime, timezone
import base64, hashlib, json
ROOT=Path(__file__).resolve().parent
PACKET=Path("/Users/me/testpilot-cancellation-18a24bf0c281-publication/publication-packet.json")
EXPECTED_PACKET_SHA="9883fd2329d7cc312507b6704eed0a4c98e268bf18b2e2d6b6acaa11d27a61a9"
def need(value,message):
    if not value:raise RuntimeError(message)
def digest(kind,data):
    return hashlib.sha1(kind.encode()+b" "+str(len(data)).encode()+b"\0"+data).hexdigest()
def write(name,value):
    (ROOT/name).write_bytes((json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False)+"\n").encode("utf-8"))
def tree_hash(leaves):
    nodes={"":{}}
    for path,row in leaves.items():
        parts=path.split("/");parent=""
        for part in parts[:-1]:
            child=(parent+"/"+part).lstrip("/")
            nodes.setdefault(parent,{})[part]={"mode":"040000","type":"tree","child":child}
            nodes.setdefault(child,{})
            parent=child
        nodes[parent][parts[-1]]=dict(row)
    hashes={}
    for parent in sorted(nodes,key=lambda p:p.count("/")+bool(p),reverse=True):
        rows=nodes[parent]
        names=sorted(rows,key=lambda n:n.encode()+(b"/" if rows[n]["type"]=="tree" else b""))
        data=b""
        for name in names:
            row=rows[name]
            sha=hashes[row["child"]] if row["type"]=="tree" else row["sha"]
            data+=row["mode"].lstrip("0").encode()+b" "+name.encode()+b"\0"+bytes.fromhex(sha)
        hashes[parent]=digest("tree",data)
    return hashes[""],hashes
api=json.loads((ROOT/"intake/github-current.json").read_bytes())
tree=api["tree"]
parent=api["main"]["object"]["sha"]
need(parent=="7f44c4f134f4d56d37dd14c7c2d2aaa3c8c8749e","Current parent advanced")
need(api["commit"]["sha"]==parent,"Commit/ref mismatch")
need(api["commit"]["tree"]["sha"]==tree["sha"]=="ea3f7b4170f1515abb7188d31dc269623b9e0738","Tree identity mismatch")
need(tree["truncated"] is False,"Truncated tree")
leaves={r["path"]:{k:r[k] for k in ("mode","type","sha")} for r in tree["tree"] if r["type"]!="tree"}
need(len(leaves)==1063,"Parent leaf count differs")
actual,subtrees=tree_hash(leaves)
need(actual==tree["sha"],"Full tree hash mismatch")
for row in tree["tree"]:
    if row["type"]=="tree":need(subtrees[row["path"]]==row["sha"],"Subtree hash mismatch")
need(not [p for p in leaves if p.split("/")[-1]=="AGENTS.md"],"Unexpected governing AGENTS file")
packet_bytes=PACKET.read_bytes()
need(len(packet_bytes)==713816 and hashlib.sha256(packet_bytes).hexdigest()==EXPECTED_PACKET_SHA,"Packet identity differs")
packet=json.loads(packet_bytes)
need(packet["base_sha"]==parent and packet["base_tree"]==tree["sha"],"Author parent mismatch")
need(packet["source_commit"]=="649dc7d1fd02493af298876eea0697849404bba9","Candidate freeze differs")
need(packet["file_count"]==len(packet["files"])==27,"Whitelist count differs")
paths=[f["path"] for f in packet["files"]]
need(len(set(paths))==27,"Duplicate whitelist paths")
need(set(paths)&set(leaves)=={"testpilot/sandbox.py"},"Unexpected replaced parent path")
body={}
metadata=[]
for row in packet["files"]:
    data=base64.b64decode(row["content"],validate=True) if row["encoding"]=="base64" else row["content"].encode("utf-8")
    need(len(data)==row["bytes"],"Packet size mismatch "+row["path"])
    need(hashlib.sha256(data).hexdigest()==row["sha256"],"Packet SHA256 mismatch "+row["path"])
    need(digest("blob",data)==row["git_blob"],"Packet Git blob mismatch "+row["path"])
    need(row["mode"]=="100644" and row["type"]=="blob","Unexpected packet mode/type")
    body[row["path"]]=data
    metadata.append({k:v for k,v in row.items() if k!="content"})
prefix="docs/receipts/run-cancellation-18a24bf0c281/"
parent_source=json.loads(body[prefix+"current-parent-source.json"])
freeze=json.loads(body[prefix+"candidate-source-freeze.json"])
need(parent_source["canonical_head"]==parent and parent_source["canonical_tree"]==tree["sha"],"Receiving parent mismatch")
need(len(parent_source["captured_files"])==14,"Captured closure count differs")
for row in parent_source["captured_files"]:
    need(leaves[row["path"]]["sha"]==row["git_blob"] and leaves[row["path"]]["mode"]==row["mode"],"Receiving closure drift "+row["path"])
runtime=[r for r in parent_source["captured_files"] if r["path"].startswith("testpilot/")]
need(len(runtime)==9,"Runtime closure count differs")
for row in freeze["files"]:
    expected=next((f["git_blob"] for f in packet["files"] if f["path"]==row["path"]),None)
    if expected is None:expected=leaves[row["path"]]["sha"]
    need(row["git_blob"]==expected,"Candidate closure mapping differs "+row["path"])
sandbox=body["testpilot/sandbox.py"]
handler=b'''    except KeyboardInterrupt:
        if os.name == "posix":
            try:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # Reap the leader without draining an escaped helper's pipe.
                proc.wait(timeout=1.0)
            except (OSError, subprocess.TimeoutExpired):
                # Cleanup failure must not replace the caller's cancellation.
                pass
            finally:
                proc.stdout.close()
        raise
'''
new_doc=b'    """Collect output, bounding POSIX timeout and interrupt cleanup."""'
old_doc=b'    """Collect output, with at most one extra second of POSIX timeout cleanup."""'
need(sandbox.count(handler)==1 and sandbox.count(new_doc)==1,"Source additions ambiguous")
reconstructed=sandbox.replace(handler,b"",1).replace(new_doc,old_doc,1)
need(digest("blob",reconstructed)==leaves["testpilot/sandbox.py"]["sha"]=="8ca4a4102c7890e89eae99548e28ba8325974f1e","Non-handler sandbox source changed")
expected=dict(leaves)
for row in metadata:
    expected[row["path"]]={"mode":row["mode"],"type":row["type"],"sha":row["git_blob"]}
expected_sha,_=tree_hash(expected)
unrelated=sorted(set(leaves)-set(paths))
need(len(unrelated)==1062 and all(expected[p]==leaves[p] for p in unrelated),"Unrelated parent preservation failed")
need(len(expected)==1089,"Expected author-overlay leaf count differs")
open_prs=api["open_prs"]
coverage=next(p for p in open_prs if p["number"]==40)
need(coverage["state"]=="open" and coverage["draft"] is True,"Coverage ownership state differs")
need(coverage["base"]["sha"]==parent,"Coverage base differs")
need("testpilot/recheck_html.py" not in leaves,"Recheck renderer has landed")
need(leaves["testpilot/recheck.py"]["sha"]=="4ab26cbb83beff563b9c3683c593b3efd2495b6b","Recheck changed")
write("packet-manifest.json",{"packet":str(PACKET),"bytes":len(packet_bytes),"sha256":EXPECTED_PACKET_SHA,
 "source_commit":packet["source_commit"],"evidence_commit":packet["evidence_commit"],"files":metadata})
write("receiving-closure.json",{"parent_source":parent_source,"candidate_source_freeze":freeze,
 "all14_original_closure_pins_match_current":True,"runtime_modules":runtime,
 "exact_candidate_sandbox":digest("blob",sandbox),
 "sandbox_without_only_handler_and_docstring_matches_original":True})
write("expected-author-overlay.json",{"kind":"computed author27-path overlay only; independent reviewer additions are separate",
 "parent":parent,"parent_tree":tree["sha"],"expected_tree":expected_sha,"leaves":len(expected),
 "whitelist_count":27,"new_paths":26,"replaced_paths":["testpilot/sandbox.py"],
 "unrelated_parent_exact_count":1062,
 "entries":[{"path":p,**row} for p,row in sorted(expected.items())]})
receipt={"recorded_at":datetime.now(timezone.utc).isoformat(),"repository":"Jacob-Met/testpilot","issue":35,
 "decision":"Current parent and native receiving closure preserved; no later production delta",
 "current_parent":parent,"current_tree":tree["sha"],"current_leaves":len(leaves),"tree_complete_and_reconstructed":True,
 "later_production_changes":[],"author_source_commit":packet["source_commit"],"author_evidence_commit":packet["evidence_commit"],
 "packet_sha256":EXPECTED_PACKET_SHA,"packet_files_verified":27,"author_only_expected_tree":expected_sha,
 "author_only_expected_leaves":len(expected),"unrelated_parent_retained":1062,
 "original_sandbox_blob":leaves["testpilot/sandbox.py"]["sha"],"candidate_sandbox_blob":digest("blob",sandbox),
 "loop_output_staging_blob":leaves["testpilot/loop.py"]["sha"],
 "native_closure_all14_pins_current":True,"all9_runtime_modules_current":True,
 "ownership":{"issue35":"Cancellation owner retains sandbox._run; generated-phase independent receiver remains separate.",
  "issue36":{"state":api["issue36"]["state"],"source_pr":40,"draft":True,"head":coverage["head"]["sha"],"landed":False,
             "scope":"Only run CLI --no-coverage and constructor forwarding; sandbox/loop/recheck excluded."},
  "issue37":{"state":api["issue37"]["state"],"landed":False,
             "current_recheck_blob":leaves["testpilot/recheck.py"]["sha"],
             "latest_comment":api["issue37_comments"][-1]["id"],
             "scope":"New offline recheck HTML and additive output writer; sandbox/CLI/loop/model excluded."},
  "other_open_prs":[{"number":p["number"],"head":p["head"]["sha"],"draft":p["draft"]} for p in open_prs]},
 "no_test_execution":True,"no_source_edit":True,"no_github_mutation":True,
 "limits":["This is a static current-parent and complete-whitelist review, not a duplicate receiving run.",
           "Expected tree includes author27 paths only; root must account separately for product's independent evidence.",
           "Future main advances need their own exact-parent comparison; no claim of future branch preservation."]}
write("qualification.json",receipt)
print(json.dumps({k:receipt[k] for k in ("decision","current_parent","current_tree","packet_files_verified",
 "author_only_expected_tree","author_only_expected_leaves","unrelated_parent_retained","original_sandbox_blob","candidate_sandbox_blob")}))
