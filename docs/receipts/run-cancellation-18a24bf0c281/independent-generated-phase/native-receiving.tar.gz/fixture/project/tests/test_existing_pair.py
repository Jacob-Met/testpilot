from pair_math import combine

def test_existing_pair():
    assert combine(6, 7) == 13
