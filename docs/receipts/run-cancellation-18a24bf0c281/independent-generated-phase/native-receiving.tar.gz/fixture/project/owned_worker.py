import json
import os
from pathlib import Path
import sys
import time

control = Path(sys.argv[1])
deadline = time.monotonic() + 8.0
identity = {"pid": os.getpid(), "ppid": os.getppid(), "pgid": os.getpgrp()}
(control / "worker-ready.json").write_text(json.dumps(identity))
while time.monotonic() < deadline:
    (control / "heartbeat.json").write_text(json.dumps({**identity, "monotonic": time.monotonic()}))
    flag = control / "parent-exited.json"
    if flag.exists():
        parent_receipt = json.loads(flag.read_text())
        (control / "work-after-parent-exit.json").write_text(json.dumps({**identity, "observed_ppid": os.getppid(), "monotonic": time.monotonic(), "parent_exit": parent_receipt}))
        time.sleep(0.15)
        break
    time.sleep(0.025)
