def combine(left, right):
    return left + right
