# Previous regular review artifact

Generation 17 must survive interruption.
