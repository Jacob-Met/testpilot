import pathlib,json,hashlib,sys,importlib.metadata
src=pathlib.Path('/Users/me/testpilot-cancellation-18a24bf0c281'); root=pathlib.Path('/Users/me/testpilot-independent-interrupt-18a24bf0c281'); assert not root.exists(); root.mkdir(); (root/'drivers').mkdir(); (root/'evidence').mkdir()
manifest=json.loads((src/'evidence/current-parent-source.json').read_text()); entries=[]
for e in manifest['captured_files']:
 p=src/'current-baseline'/e['path']; b=p.read_bytes(); assert hashlib.sha256(b).hexdigest()==e['sha256']; assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['git_blob']; target=root/'source-baseline'/e['path']; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b); target.chmod(0o644); entries.append(e)
assert len(entries)==14
out={'upstream_repository':'Jacob-Met/TestPilot','canonical_head':manifest['canonical_head'],'canonical_tree':manifest['canonical_tree'],'canonical_blob_count':manifest['full_tree_blobs'],'captured_files':entries,'receiving_kind':'Own exact14-file snapshot of current7f44 native source; original ownerf3 execution not relabeled; candidate has not been copied or run.'}
(root/'evidence/source-intake.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({'root':str(root),'files':len(entries),'canonical_head':manifest['canonical_head'],'candidate_intake':False}))