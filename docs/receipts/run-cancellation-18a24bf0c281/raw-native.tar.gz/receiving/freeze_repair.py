"""Retain the exact negative gate, then freeze the minimal cancellation repair."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/Users/me/testpilot-cancellation-18a24bf0c281")
source = ROOT / "candidate"
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()
subprocess.run(["git", "add", "evidence/current-baseline-focused", "receiving/run_pytest_gate.py"],
               cwd=ROOT, check=True)
subprocess.run(["git", "commit", "-m", "Preserve current-parent cancellation failures and detached control"],
               cwd=ROOT, check=True)
red_commit = git("rev-parse", "HEAD")
payload = json.loads((ROOT / "receiving/repair-payload.json").read_text())
original = (ROOT / "current-baseline/testpilot/sandbox.py").read_bytes()
if (source / "testpilot/sandbox.py").read_bytes() != original:
    raise ValueError("Candidate was changed before the negative gate")
(source / "testpilot/sandbox.py").write_text(payload["sandbox"])
(source / "docs").mkdir(exist_ok=True)
(source / "docs/run-cancellation.md").write_text(payload["doc"])
candidate = (source / "testpilot/sandbox.py").read_bytes()
start = candidate.index(b"    except KeyboardInterrupt:\n", candidate.index(b"def _run("))
end = candidate.index(b"    except subprocess.TimeoutExpired:\n", start)
reconstructed = candidate[:start] + candidate[end:]
reconstructed = reconstructed.replace(
    b'"""Collect output, bounding POSIX timeout and interrupt cleanup."""',
    b'"""Collect output, with at most one extra second of POSIX timeout cleanup."""',
)
if reconstructed != original:
    raise ValueError("The cancellation edit changed existing timeout or other source bytes")
rows = []
for path in sorted(p for p in source.rglob("*") if p.is_file()):
    data = path.read_bytes()
    rel = str(path.relative_to(source))
    rows.append({"path": rel, "size": len(data),
                 "sha256": hashlib.sha256(data).hexdigest(),
                 "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()})
for row in rows:
    baseline = ROOT / "current-baseline" / row["path"]
    if baseline.exists() and row["path"] != "testpilot/sandbox.py":
        if hashlib.sha256(baseline.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError(f"Nonowned source drift: {row['path']}")
freeze = {"canonical_parent": "7f44c4f134f4d56d37dd14c7c2d2aaa3c8c8749e",
          "canonical_tree": "ea3f7b4170f1515abb7188d31dc269623b9e0738",
          "original_executed_parent": "f3b2135cad31852b599350564fe76dd160a6a522",
          "negative_receiving_commit": red_commit,
          "issue": "https://github.com/Jacob-Met/testpilot/issues/35",
          "source_paths": ["testpilot/sandbox.py", "tests/test_sandbox_interrupt.py", "docs/run-cancellation.md"],
          "files": rows, "timeout_and_remaining_module_reconstruction_matches_original": True,
          "native_execution": "Not yet executed; this is the pre-execution source freeze."}
(ROOT / "evidence/candidate-source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n")
patch = "".join(difflib.unified_diff(original.decode().splitlines(True),
                                    candidate.decode().splitlines(True),
                                    fromfile="a/testpilot/sandbox.py", tofile="b/testpilot/sandbox.py"))
(ROOT / "evidence/production.patch").write_text(patch)
subprocess.run(["git", "add", "candidate/testpilot/sandbox.py", "candidate/docs/run-cancellation.md",
                "receiving/repair-payload.json", "receiving/freeze_repair.py",
                "evidence/candidate-source-freeze.json", "evidence/production.patch"],
               cwd=ROOT, check=True)
subprocess.run(["git", "commit", "-m", "Stop the POSIX sandbox process group when its caller is interrupted"],
               cwd=ROOT, check=True)
print(json.dumps({"source_commit": git("rev-parse", "HEAD"), "red_commit": red_commit,
                  "sandbox": next(r for r in rows if r["path"] == "testpilot/sandbox.py"),
                  "source_paths": freeze["source_paths"], "working_tree": git("status", "--porcelain")}))
print(patch)
