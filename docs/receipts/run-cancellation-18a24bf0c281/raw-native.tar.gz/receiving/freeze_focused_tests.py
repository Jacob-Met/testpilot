"""Freeze native cancellation tests before changing the maintained sandbox."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/Users/me/testpilot-cancellation-18a24bf0c281")
payload = json.loads((ROOT / "receiving/focused-test-payload.json").read_text())
destination = ROOT / "candidate"
destination.mkdir(exist_ok=False)
rows = []
for item in payload["files"]:
    original = ROOT / "current-baseline" / item["path"]
    data = original.read_bytes()
    if data != item["content"].encode("utf-8"):
        raise ValueError(f"current parent changed: {item['path']}")
    target = destination / item["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    rows.append({"path": item["path"], "git_blob": item["meta"]["sha"],
                 "sha256": hashlib.sha256(data).hexdigest()})
test = destination / "tests/test_sandbox_interrupt.py"
test.write_text(payload["test"])
rows.append({"path": "tests/test_sandbox_interrupt.py",
             "sha256": hashlib.sha256(test.read_bytes()).hexdigest(),
             "git_blob": hashlib.sha1(b"blob " + str(test.stat().st_size).encode() + b"\0" + test.read_bytes()).hexdigest()})
receipt = {"canonical_parent": "7f44c4f134f4d56d37dd14c7c2d2aaa3c8c8749e",
           "canonical_tree": "ea3f7b4170f1515abb7188d31dc269623b9e0738",
           "claim": "https://github.com/Jacob-Met/testpilot/issues/35",
           "production_delta": [], "files": rows,
           "test_policy": "Four real POSIX process-group/pipe cases; fixture-only signals, eight-second worker lifetimes, ten-second fallback cleanup. No dependency installation."}
(ROOT / "evidence/focused-test-baseline-freeze.json").write_text(json.dumps(receipt, indent=2) + "\n")
subprocess.run(["git", "add", "candidate", "receiving/focused-test-payload.json",
                "receiving/freeze_focused_tests.py", "evidence/focused-test-baseline-freeze.json"],
               cwd=ROOT, check=True)
subprocess.run(["git", "commit", "-m", "Freeze real POSIX interruption regressions before repair"],
               cwd=ROOT, check=True)
print(json.dumps({"commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
                  "test_sha256": rows[-1]["sha256"], "files": len(rows),
                  "production_delta": []}))
