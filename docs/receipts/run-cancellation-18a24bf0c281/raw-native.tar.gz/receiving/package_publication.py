"""Package only the claimed source delta and complete additive native evidence."""
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path("/Users/me/testpilot-cancellation-18a24bf0c281")
PUB = ROOT / "publication"
REL = Path("docs/receipts/run-cancellation-18a24bf0c281")
OUT = PUB / REL
PUB.mkdir(exist_ok=False)
OUT.mkdir(parents=True)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
freeze = json.loads((ROOT / "evidence/candidate-source-freeze.json").read_text())
for row in freeze["files"]:
    data = (ROOT / "candidate" / row["path"]).read_bytes()
    if sha(data) != row["sha256"] or blob(data) != row["git_blob"]:
        raise ValueError(f"Frozen candidate changed: {row['path']}")
source_paths = ["testpilot/sandbox.py", "tests/test_sandbox_interrupt.py", "docs/run-cancellation.md"]
for path in source_paths:
    copy(ROOT / "candidate" / path, PUB / path)
copies = {
    "README.md": "receiving/packet-readme.md",
    "source-intake.json": "evidence/source-intake.json",
    "current-parent-source.json": "evidence/current-parent-source.json",
    "candidate-source-freeze.json": "evidence/candidate-source-freeze.json",
    "focused-test-baseline-freeze.json": "evidence/focused-test-baseline-freeze.json",
    "proposed-scope.md": "evidence/proposed-scope.md",
    "receiver-correction.json": "evidence/receiver-correction.json",
    "production.patch": "evidence/production.patch",
    "original-cli-receipt.json": "evidence/original-cancellation-v2/receipt.json",
    "current-focused-receipt.json": "evidence/current-baseline-focused/receipt.json",
    "candidate-pytest-receipt.json": "evidence/candidate-sandbox-gate/receipt.json",
    "candidate-cli-receipt.json": "evidence/candidate-cli/receipt.json",
    "candidate-cli-composition.json": "evidence/candidate-cli-composition.json",
    "receive-cancellation.py": "receiving/receive_cancellation.py",
    "run-pytest-gate.py": "receiving/run_pytest_gate.py",
    "run-cli-gate.py": "receiving/run_cli_gate.py",
    "original-v1.stderr": "evidence/original-driver.stderr",
    "original-v2.stdout": "evidence/v2-driver.stdout",
    "current-baseline.stdout": "evidence/current-baseline-focused/pytest.stdout",
    "candidate-sandbox.stdout": "evidence/candidate-sandbox-gate/pytest.stdout",
    "candidate-cli.stdout": "evidence/candidate-cli.stdout",
}
for target, source in copies.items():
    copy(ROOT / source, OUT / target)

# Archive every retained file in the explicitly scoped input/evidence roots.
# Record convenience links as metadata instead of creating absolute archive links.
regular = []
links = []
for folder in ("baseline", "current-baseline", "candidate", "evidence", "receiving"):
    for path in sorted((ROOT / folder).rglob("*")):
        rel = str(path.relative_to(ROOT))
        if path.is_symlink():
            target = os.readlink(path)
            links.append({"path": rel, "kind": "symlink_metadata", "target": target,
                          "target_text_sha256": sha(os.fsencode(target))})
        elif path.is_file():
            data = path.read_bytes()
            regular.append({"path": rel, "bytes": len(data), "sha256": sha(data),
                            "git_blob": blob(data), "mode": "100644"})
archive = OUT / "raw-native.tar.gz"
with archive.open("xb") as raw:
    with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as tar:
            for row in regular:
                data = (ROOT / row["path"]).read_bytes()
                info = tarfile.TarInfo(row["path"])
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
verified = []
expected = {r["path"]: r for r in regular}
with tarfile.open(archive, "r:gz") as tar:
    for member in tar.getmembers():
        if not member.isfile() or member.name not in expected:
            raise ValueError(f"Unexpected archive member: {member.name}")
        data = tar.extractfile(member).read()
        row = expected[member.name]
        if len(data) != row["bytes"] or sha(data) != row["sha256"]:
            raise ValueError(f"Archive member mismatch: {member.name}")
        verified.append(member.name)
if set(verified) != set(expected) or len(verified) != len(expected):
    raise ValueError("Archive membership mismatch")
raw_manifest = {"archive": "raw-native.tar.gz", "archive_bytes": archive.stat().st_size,
                "archive_sha256": sha(archive.read_bytes()),
                "regular_file_count": len(regular), "verified_regular_files": len(verified),
                "regular_files": regular, "symlink_metadata": links,
                "archive_metadata": "Regular bytes preserved; tar uid/gid/mtime normalized; links represented as metadata only."}
(OUT / "raw-manifest.json").write_text(json.dumps(raw_manifest, indent=2) + "\n")

original = json.loads((ROOT / "evidence/original-cancellation-v2/receipt.json").read_text())
red = json.loads((ROOT / "evidence/current-baseline-focused/receipt.json").read_text())
green = json.loads((ROOT / "evidence/candidate-sandbox-gate/receipt.json").read_text())
cli = json.loads((ROOT / "evidence/candidate-cli-composition.json").read_text())
if (sum(original["checks"].values()), len(original["checks"])) != (3, 4):
    raise ValueError("Original CLI negative changed")
if [c["status"] for c in red["cases"]].count("failure") != 3:
    raise ValueError("Current-parent negative changed")
if [c["status"] for c in green["cases"]].count("passed") != 17 or any(c["status"] in ("failure", "error") for c in green["cases"]):
    raise ValueError("Candidate pytest result changed")
if not all(cli["checks"].values()) or not cli["source_unchanged"]:
    raise ValueError("Candidate CLI result changed")
qualification = {
    "repository": "Jacob-Met/testpilot", "issue": "https://github.com/Jacob-Met/testpilot/issues/35",
    "base_ref": "main", "base_sha": "7f44c4f134f4d56d37dd14c7c2d2aaa3c8c8749e",
    "base_tree": "ea3f7b4170f1515abb7188d31dc269623b9e0738",
    "full_parent_blob_count": 1063,
    "source_commit": "649dc7d1fd02493af298876eea0697849404bba9",
    "original_evidence_commit": "8aaacedf99c888d27971e7d1cf9751f777961d4d",
    "current_parent_commit": "6f81b28a1ccdd09983cc5180595868ed27d4ab3a",
    "test_freeze_commit": "d017324348fba8035646b77426aa3b94497d6d89",
    "current_red_commit": "fe6adc337ada4421a1e978d58998eec3e8478d43",
    "source_paths": source_paths,
    "original_cli": {"actions": 2, "predicates_passed": 3, "predicates_total": 4, "head": original["canonical_head"]},
    "current_focused": {"cases": len(red["cases"]), "failed": 3, "passed": 1, "errors": 0},
    "candidate_pytest": {"cases": len(green["cases"]), "passed": 17, "skipped": 1,
                         "skip_reason": "existing coverage test: coverage not installed"},
    "candidate_cli": {"actions": 2, "predicates_passed": 4, "predicates_total": 4},
    "python": green["python"], "platform": green["platform"], "pytest": green["pytest"],
    "device_id": "0e3d582f-e25b-44b2-8418-9639fc4e4e33",
    "native_root": str(ROOT),
    "production_inverse_reconstruction": freeze["timeout_and_remaining_module_reconstruction_matches_original"],
    "all_gate_source_bytes_unchanged": red["source_unchanged"] and green["source_unchanged"] and cli["source_unchanged"],
    "ownership_evidence_archive_path": "evidence/current-head-ownership.json",
    "current_parent_distinction": "f3 discovery and7f current-parent executions are separate; candidate composition sidecar is authoritative over the frozen driver's historical raw f3 labels.",
    "preserved_receiver_error": "v1 aggregate ledger.calls KeyError, after both native flows, is retained; v2 fixes only metadata access and exposes paths.",
    "scope_limits": ["Native macOS POSIX KeyboardInterrupt during initial communication only",
                     "No escaped-session containment, Windows, SIGTERM/SIGKILL or pre-Popen claim",
                     "No optimized-Python or whole-repository-suite claim",
                     "No dependencies installed, live providers, real developer outputs or GitHub writes",
                     "Publication is a delta over the complete canonical parent tree"],
    "raw_archive_sha256": raw_manifest["archive_sha256"], "raw_regular_files_verified": len(verified),
}
(OUT / "qualification.json").write_text(json.dumps(qualification, indent=2) + "\n")

for row in freeze["files"]:
    if sha((ROOT / "candidate" / row["path"]).read_bytes()) != row["sha256"]:
        raise ValueError("Packaging changed frozen candidate bytes")
subprocess.run(["git", "add", "publication", "evidence/candidate-cli", "evidence/candidate-cli-composition.json",
                "evidence/candidate-cli.stdout", "evidence/candidate-cli.stderr", "evidence/candidate-sandbox-gate",
                "receiving/run_cli_gate.py", "receiving/packet-readme.md", "receiving/package_publication.py"],
               cwd=ROOT, check=True)
subprocess.run(["git", "commit", "-m", "Bind cancellation repair to preserved native red-green receiving"],
               cwd=ROOT, check=True)
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
status = subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True)
if status:
    raise ValueError(f"Unexpected uncommitted native state: {status}")
files = []
for path in sorted(p for p in PUB.rglob("*") if p.is_file()):
    data = path.read_bytes()
    rel = str(path.relative_to(PUB))
    is_binary = path.name.endswith(".tar.gz")
    files.append({"path": rel, "mode": "100644", "type": "blob",
                  "encoding": "base64" if is_binary else "utf-8",
                  "content": base64.b64encode(data).decode() if is_binary else data.decode("utf-8"),
                  "bytes": len(data), "sha256": sha(data), "git_blob": blob(data)})
packet = {"repository": "Jacob-Met/testpilot", "base_ref": "main",
          "base_sha": qualification["base_sha"], "base_tree": qualification["base_tree"],
          "source_commit": qualification["source_commit"], "evidence_commit": commit,
          "source_paths": source_paths, "file_count": len(files), "files": files,
          "integration": "Apply only this whitelist over the complete maintained parent; preserve all other files. Root owns publication and independent receiving."}
transport = Path("/Users/me/testpilot-cancellation-18a24bf0c281-publication")
transport.mkdir(exist_ok=False)
packet_path = transport / "publication-packet.json"
packet_path.write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n")
manifest = {key: value for key, value in packet.items() if key != "files"}
manifest["files"] = [{key: value for key, value in item.items() if key != "content"} for item in files]
manifest["packet_bytes"] = packet_path.stat().st_size
manifest["packet_sha256"] = sha(packet_path.read_bytes())
(transport / "publication-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"packet": str(packet_path), "bytes": manifest["packet_bytes"],
                  "sha256": manifest["packet_sha256"], "evidence_commit": commit,
                  "source_commit": qualification["source_commit"], "files": len(files),
                  "regular_archive_files": len(verified), "symlinks_as_metadata": len(links),
                  "archive_bytes": raw_manifest["archive_bytes"], "working_tree": "clean"}))
