"""Freeze exact current-main receiving inputs without altering the original source."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("/Users/me/testpilot-cancellation-18a24bf0c281")
payload = json.loads((ROOT / "receiving/current-parent-payload.json").read_text())
destination = ROOT / "current-baseline"
destination.mkdir(exist_ok=False)
rows = []
for item in payload["files"]:
    data = item["content"].encode("utf-8")
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    if blob != item["meta"]["sha"] or len(data) != item["meta"]["size"]:
        raise ValueError(f"upstream byte mismatch: {item['path']}")
    target = destination / item["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    target.chmod(0o444)
    rows.append({"path": item["path"], "mode": item["meta"]["mode"], "git_blob": blob,
                 "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
receipt = {
    "canonical_head": payload["canonical_head"],
    "canonical_tree": payload["canonical_tree"],
    "original_executed_head": payload["previous_executed_head"],
    "full_tree_blobs": 1063,
    "captured_files": rows,
    "scope": "Exact 14-file receiving closure and existing sandbox tests; not a full upstream clone. Original f3 baseline/evidence remain unchanged. Current loop.py preserves merged PR34 output staging.",
    "no_agents_in_recursive_current_tree": payload["no_agents"],
    "execution": "No current-main execution is claimed by this source capture.",
}
(ROOT / "evidence/current-parent-source.json").write_text(json.dumps(receipt, indent=2) + "\n")
subprocess.run(["git", "add", "current-baseline", "receiving/current-parent-payload.json",
                "receiving/capture_current_parent.py", "evidence/current-parent-source.json"],
               cwd=ROOT, check=True)
subprocess.run(["git", "commit", "-m", "Pin current TestPilot staging parent for cancellation receiving"],
               cwd=ROOT, check=True)
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
status = subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True)
print(json.dumps({"commit": commit, "canonical_head": payload["canonical_head"],
                  "captured_files": len(rows), "working_tree": status,
                  "production_changes": False}))
