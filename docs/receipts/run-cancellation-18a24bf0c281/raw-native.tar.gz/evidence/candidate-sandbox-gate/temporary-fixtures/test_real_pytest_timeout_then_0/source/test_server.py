def test_fresh():
    assert 6 * 7 == 42
