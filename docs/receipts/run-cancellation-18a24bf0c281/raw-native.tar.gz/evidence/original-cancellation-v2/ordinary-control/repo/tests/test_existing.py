import json, os, time
from pathlib import Path
from sample import double

def test_existing_work():
    root = Path('/Users/me/testpilot-cancellation-18a24bf0c281/evidence/original-cancellation-v2/ordinary-control/markers')
    (root / "ready.json").write_text(json.dumps({"pid": os.getpid(), "pgid": os.getpgrp()}))
    deadline = time.monotonic() + 5
    while not (root / "release").exists() and time.monotonic() < deadline:
        time.sleep(0.01)
    if (root / "release").exists():
        (root / "continued.json").write_text(json.dumps({"pid": os.getpid(), "work": "completed after release"}))
    assert double(2) == 4
