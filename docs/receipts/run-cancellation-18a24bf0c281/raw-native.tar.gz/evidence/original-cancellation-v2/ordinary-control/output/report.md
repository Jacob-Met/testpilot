# TestPilot report: **passed**

- Changed functions: sample.py::double
- Tests written: 1 in tests/test_testpilot_generated.py
- Repair rounds used: 0/0
- Final run: 2 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 1 passed of 1 collected in 0.202s
- Coverage: unavailable
- Tokens: 301 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 94 in / 14 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 160 in / 33 out

## Patch

```diff
diff --git a/tests/test_testpilot_generated.py b/tests/test_testpilot_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_testpilot_generated.py
@@ -0,0 +1,5 @@
+# tests/test_generated_double.py
+from sample import double
+
+def test_generated_double():
+    assert double(3) == 6
```
