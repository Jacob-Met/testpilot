```python
# tests/test_generated_double.py
from sample import double

def test_generated_double():
    assert double(3) == 6
```
