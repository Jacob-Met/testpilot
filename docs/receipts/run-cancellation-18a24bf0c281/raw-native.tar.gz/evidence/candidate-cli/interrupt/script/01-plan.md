Check that the changed function doubles positive input.
