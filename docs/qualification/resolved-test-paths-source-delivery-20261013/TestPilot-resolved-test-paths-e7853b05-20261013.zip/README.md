# TestPilot resolved test-path qualification

Source: https://github.com/Jacob-Met/testpilot/commit/e7853b0545b9938d1df14ba81706d1f5ad03f8ab
Parent: `478f68adf01658a94a3ede22526da00f580785bd`
Issue: https://github.com/Jacob-Met/testpilot/issues/93

This capsule carries the three exact changed files, an applicable source patch,
all six unchanged independent contract/receiver/receipt/review artifacts,
and the authored original/candidate logs. It is a change and qualification
capsule; the complete project is available at the pinned source commit.

## Result

An ordinary diff alias that resolves to test source is excluded by default
before source is opened. The existing lexical filters, repository confinement,
explicit test inclusion and ordinary source alias behavior remain intact.

The new 13 regression cases improve from 4 pass / 9 fail against original
production source to 13 pass in the candidate focused course. A separately
frozen independent 26-case receiver improves from 17 pass / 9 fail to 26 pass.
The exact source and guide received independent acceptance.

The full maintained run is not green: 648 pass, 7 fail, 1 skip and 40 passing
subtests. All seven failing tests reproduce on the clean detached original.
Three fail while creating raw-byte filenames with Mac errno 92. Four existing
collection/recheck failures preserve their assertion outcomes; their cause is
not diagnosed here. Existing tests and skips were not changed. The detailed
receipt distinguishes pytest exit 1 from the exit 0 of observer wrappers.

## Receiving and use

`MANIFEST.json` records every capsule member except itself by byte count and
SHA256. Compare those values after extraction. `RECEIVING.json` joins source,
runtimes, exact observed courses, original baseline and review limits.

For the complete project, fetch the published branch and select the pinned
source commit in a separate checkout. Run the maintained regression file with
the project's declared test dependencies:

```sh
python -m pytest -q tests/test_resolved_test_paths.py
```

Alternatively apply `source.patch` only to a clean checkout at the exact parent
after `git apply --check source.patch`. The `source/` files are the corresponding
byte-exact replacements/addition. No main integration, installed adoption,
Windows qualification, filesystem race protection or Drive delivery is claimed.
