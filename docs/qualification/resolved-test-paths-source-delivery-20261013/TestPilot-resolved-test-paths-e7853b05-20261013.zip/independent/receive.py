import pathlib,tempfile,json,hashlib,subprocess,sys,os,importlib.util,datetime
contract_path=pathlib.Path("/tmp/hamon-testpilot-resolved-test-independent-20261013-shared.json")
contract_bytes=contract_path.read_bytes()
assert len(contract_bytes)==8074 and hashlib.sha256(contract_bytes).hexdigest()=="8e5e47c337701681b6de34c324dde05f1820e5b0178308a6b01201377151bc3e"
contract=json.loads(contract_bytes)
repo=pathlib.Path(contract["source_root"])
label=sys.argv[1] if len(sys.argv)>1 else "original"
head=subprocess.run(["git","-C",str(repo),"rev-parse","HEAD"],capture_output=True,text=True,check=True).stdout.strip()
dirty=subprocess.run(["git","-C",str(repo),"diff","--no-ext-diff","--exit-code","HEAD","--",*contract["source_files"]],capture_output=True)
if label=="original":
 assert head==contract["original_head"],"Original head mismatch"
 assert dirty.returncode==0,"Original review files changed before baseline; no candidate read"
root=pathlib.Path(tempfile.mkdtemp(prefix="hamon-testpilot-resolved-test-"+label+"-20261013-"))
pins={p:{"bytes":len((repo/p).read_bytes()),"sha256":hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in contract["source_files"]}
spec=importlib.util.spec_from_file_location("independent_selected_diff",repo/"testpilot/diff.py")
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
source=contract["valid_source"]
def diff_for(name,deleted=False):
 if deleted:return "--- a/"+name+"\n+++ /dev/null\n@@ -1,2 +0,0 @@\n-def chosen():\n-    return \"before\"\n"
 return "--- a/"+name+"\n+++ b/"+name+"\n@@ -1,2 +1,2 @@\n def chosen():\n-    return \"before\"\n+    return \"FROZEN_LITERAL\"\n"
rows=[]
for case in contract["cases"]:
 case_root=root/case["id"];case_root.mkdir()
 target_repo=case_root/case.get("repo_name","repo");target_repo.mkdir()
 destination=(case_root/"outside" if case.get("outside") else target_repo)/case["target"]
 destination.parent.mkdir(parents=True,exist_ok=True)
 fixture=(contract["invalid_source"] if case.get("invalid_source") else source).encode()
 if not case.get("missing"):destination.write_bytes(fixture)
 link=target_repo/case["path"]
 if case.get("directory_alias"):
  link.parent.symlink_to(os.path.relpath(destination.parent,link.parent.parent),target_is_directory=True)
 else:
  link.parent.mkdir(parents=True,exist_ok=True)
  link.symlink_to(os.path.relpath(destination,link.parent))
 if case.get("mixed"):(target_repo/"normal.py").write_text(source,encoding="utf-8")
 selected_root=target_repo
 if case.get("root_alias"):
  selected_root=case_root/"root-alias";selected_root.symlink_to(target_repo,target_is_directory=True)
 patch=(diff_for("normal.py") if case.get("mixed") else "")+diff_for(case["path"],case.get("deleted",False))
 opened=[]
 original_open=module.tokenize.open
 def observed_open(path,*args,**kwargs):
  resolved=pathlib.Path(path).resolve()
  try:opened.append(resolved.relative_to(target_repo.resolve()).as_posix())
  except ValueError:opened.append("OUTSIDE:"+str(resolved))
  return original_open(path,*args,**kwargs)
 module.tokenize.open=observed_open
 actual=None;error=None
 try:
  actual=[f.to_dict() for f in module.changed_functions(selected_root,patch,include_tests=case.get("include_tests",False))]
 except Exception as exc:error=type(exc).__name__
 finally:module.tokenize.open=original_open
 expected=[dict(contract["selected_function_fields"],path=p,module=m) for p,m in case.get("expect",[])] if "expect" in case else None
 conserved=case.get("missing",False) or destination.read_bytes()==fixture
 passed=actual==expected and error==case.get("error") and opened==case["reads"] and conserved
 rows.append({"id":case["id"],"passed":passed,"actual":actual,"expected":expected,"error":error,"expectedError":case.get("error"),"reads":opened,"expectedReads":case["reads"],"fixtureConserved":conserved})
after={p:{"bytes":len((repo/p).read_bytes()),"sha256":hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in contract["source_files"]}
assert pins==after,"Reviewed source changed during receiving"
report={"schema":"hamon-independent-selector-receiving/1","date":datetime.datetime.now(datetime.timezone.utc).isoformat(),"label":label,"originalContract":{"path":str(contract_path),"bytes":8074,"sha256":hashlib.sha256(contract_bytes).hexdigest()},"currentHead":head,"reviewFilesDirtyAtStart":dirty.returncode!=0,"python":sys.version,"sourcePins":pins,"sourceConserved":pins==after,"fixtureRoot":str(root),"cases":rows,"passed":sum(x["passed"] for x in rows),"failed":sum(not x["passed"] for x in rows),"scope":"Actual original/candidate selector module and synthetic native filesystem only; no provider, pipeline, CLI, model, pytest, installed app, source mutation or full suite.","contractLimitations":contract["scope_limits"]}
out=root/"RECEIVING.json";out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"receipt":str(out),"bytes":out.stat().st_size,"sha256":hashlib.sha256(out.read_bytes()).hexdigest(),"label":label,"currentHead":head,"sourcePins":pins,"passed":report["passed"],"failed":report["failed"],"failedIds":[x["id"] for x in rows if not x["passed"]]},indent=2))
sys.exit(0 if not report["failed"] else 1)
