"use strict";
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const assert = require("node:assert/strict");
const {pathToFileURL} = require("node:url");
const {chromium} = require("playwright");
const root = process.argv[2];
const fixtures = JSON.parse(fs.readFileSync(path.join(root,"fixture-manifest.json"),"utf8")).fixtures;
const evidence = path.join(root,"evidence");
fs.mkdirSync(path.join(evidence,"downloads"),{recursive:true});
const sha = bytes => crypto.createHash("sha256").update(bytes).digest("hex");
const view = value => String(value).replace(/\r/g,"\\u000d");
const receipt = {schema:"testpilot.recheck-html.independent-browser/1",cases:[],requests:[],pageErrors:[],dialogs:[],popups:[],limits:[
"Three authored native-schema vectors are consumer fixtures, not actual test execution.",
"The original oracle's CRLF source is checked using the documented visible Unicode escape for CR; the real JSON download must preserve every original byte.",
"Browser page execution is enabled; no application state is injected. DOM reads are observational."
]};
let browser;
async function facts(page, selector) {
  return await page.locator(selector).evaluate(el => Object.fromEntries(
    [...el.querySelectorAll("dt")].map(dt => [dt.textContent,dt.nextElementSibling?.textContent])
  ));
}
function assertFact(actual, key, expected) {
  if (expected === null) assert.equal(actual[key],"Unavailable",key);
  else if (typeof expected === "number") assert.equal(Number(actual[key]),expected,key);
  else assert.equal(actual[key],view(expected),key);
}
(async()=>{
 try {
  browser = await chromium.launch({executablePath:"/workspace/scratch/ae0a1ea0b247/browser-tools/runtime/chromium",headless:true,args:["--no-sandbox","--disable-dev-shm-usage"]});
  receipt.chromium=browser.version();
  for (const fixture of fixtures) {
   const context = await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true});
   await context.route(/^https?:\/\//,async route=>{receipt.requests.push({label:fixture.label,url:route.request().url(),blocked:true});await route.abort();});
   const page=await context.newPage();
   page.on("pageerror",error=>receipt.pageErrors.push({label:fixture.label,message:error.message}));
   page.on("dialog",async dialog=>{receipt.dialogs.push({label:fixture.label,type:dialog.type(),message:dialog.message()});await dialog.dismiss();});
   page.on("popup",async popup=>{receipt.popups.push({label:fixture.label,url:popup.url()});await popup.close();});
   const raw=fs.readFileSync(path.join(root,"fixtures",fixture.label+".json"));
   assert.equal(sha(raw),fixture.sha256);
   const input=JSON.parse(raw.toString("utf8"));
   const file=path.join(root,"reports",fixture.label+".html");
   await page.goto(pathToFileURL(file).href);
   await page.getByRole("heading",{name:"Current result",exact:true}).waitFor();
   assert.equal(await page.locator("#current-status").textContent(),input.status);
   const rf=await facts(page,"#result");
   for(const [key,value] of [
     ["Native success",input.ok],["Native run summary",input.final.summary],
     ["Return code",input.final.returncode],["Timed out",input.final.timed_out],
     ["Duration (seconds)",input.final.duration_s],["Timeout (seconds)",input.final.timeout_s],
     ["JUnit available",input.final.junit_available],["New model calls",input.model_calls]
   ]) assertFact(rf,key,value);
   const of=await facts(page,"#origin");
   for(const [key,value] of [
     ["Schema",input.schema],["Selected checkout path",input.repo],["Selected Python",input.python],
     ["Started at",input.started_at],["Finished at",input.finished_at],
     ["Source report path",input.source_report.path],["Source report SHA-256",input.source_report.sha256],
     ["Historical source status (not this result)",input.source_report.recorded_status],
     ["This recheck JSON SHA-256",sha(raw)],["Native scope",input.scope]
   ]) assertFact(of,key,value);
   assert(!Object.keys(rf).some(key=>/historical source status/i.test(key)));
   let recordedCounts=null;
   if(input.final.junit_available) {
     const columns=await page.locator("#result thead th").allTextContents();
     assert.deepEqual(columns,["Scope","Passed","Failed","Errors","Skipped","Collected"]);
     recordedCounts=await page.locator("#result tbody tr").evaluateAll(rows=>rows.map(row=>[...row.children].map(cell=>cell.textContent)));
     assert.deepEqual(recordedCounts,[
       ["Selected suite",...["passed","failed","errors","skipped"].map(k=>String(input.final[k])),String(input.final.cases.length)],
       ["Retained tests",...["passed","failed","error","skipped","collected"].map(k=>input.final.generated===null?"Unavailable":String(input.final.generated[k]))]
     ]);
     assert.equal(await page.locator("#unavailable-counts").count(),0);
   } else {
     assert.equal(await page.locator("#result table").count(),0);
     const unavailable=await page.locator("#unavailable-counts").innerText();
     assert.match(unavailable,/unavailable/i);assert.match(unavailable,/no complete JUnit/i);
     assert.match(unavailable,/not evidence/);assert.match(unavailable,/tests passed/);
   }
   if(fixture.label==="literal-mixed") {
     const first=page.locator("#cases details").first();
     await first.locator("summary").focus();await page.keyboard.press("Enter");
     assert.equal(await first.getAttribute("open"),"");
   }
   for(const details of await page.locator("details").all()) {
     if(await details.getAttribute("open")===null) await details.locator("summary").click();
   }
   const cases=page.locator("#cases details");
   assert.equal(await cases.count(),input.final.cases.length);
   const observedCases=[];
   for(let i=0;i<input.final.cases.length;i++) {
     const expected=input.final.cases[i],selector="#cases details:nth-of-type("+(i+1)+")";
     const actual=await facts(page,selector);
     assertFact(actual,"Recorded node ID",expected.nodeid);
     assertFact(actual,"Outcome",expected.outcome);
     assertFact(actual,"Retained-file attribution",expected.generated_file);
     const diagnostic=expected.message?await cases.nth(i).locator("pre").textContent():null;
     if(expected.message) assert.equal(diagnostic,view(expected.message));
     else assert.equal(await cases.nth(i).locator("pre").count(),0);
     observedCases.push({facts:actual,diagnostic});
   }
   const sources=page.locator("#retained details");
   assert.equal(await sources.count(),input.retained_tests.length);
   const observedSources=[];
   for(let i=0;i<input.retained_tests.length;i++) {
     const expected=input.retained_tests[i],selector="#retained details:nth-of-type("+(i+1)+")";
     const actual=await facts(page,selector);
     for(const [key,value] of [["Path",expected.path],["Placement",expected.placement],["UTF-8 bytes",expected.bytes],["SHA-256",expected.sha256]]) assertFact(actual,key,value);
     const content=input.test_files[expected.path];
     assert.equal(Buffer.byteLength(content,"utf8"),expected.bytes);
     assert.equal(sha(Buffer.from(content,"utf8")),expected.sha256);
     const reading=await sources.nth(i).locator("pre").textContent();
     assert.equal(reading,view(content),expected.path);
     observedSources.push({facts:actual,reading});
   }
   const tail=await page.locator("#output pre").textContent();
   assert.equal(tail,view(input.final.output));
   assert.match(await page.locator("#output h2").innerText(),/recorded.*tail/i);
   assert.match(await page.locator("#output").innerText(),/not a complete log/);
   assert.equal(await page.locator("script,iframe,img,object,embed,#recheck-injected").count(),0);
   assert.equal(await page.evaluate(()=>typeof globalThis.__RECHECK_INJECTED__),"undefined");
   const externalLinks=await page.locator("a").evaluateAll(links=>links.map(a=>a.getAttribute("href")).filter(h=>h&&!h.startsWith("#")&&!h.startsWith("data:application/json;base64,")));
   assert.deepEqual(externalLinks,[]);
   let layout=await page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth}));
   assert(layout.documentWidth<=layout.viewport,JSON.stringify(layout));
   let phone=null;
   if(fixture.label==="literal-mixed") {
     await page.setViewportSize({width:390,height:844});
     await page.getByRole("link",{name:"Current result",exact:true}).click();
     phone=await page.evaluate(()=>({
       viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,
       countsContainer:[...document.querySelectorAll(".table-scroll")].map(el=>({clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,left:el.getBoundingClientRect().left,right:el.getBoundingClientRect().right})),
       anchors:[...document.querySelectorAll("nav a,.download")].map(el=>({text:el.textContent,width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height,left:el.getBoundingClientRect().left,right:el.getBoundingClientRect().right}))
     }));
     assert(phone.documentWidth<=phone.viewport,JSON.stringify(phone));
     assert(phone.anchors.every(a=>a.left>=0&&a.right<=390&&a.height>=40));
     await page.screenshot({path:path.join(evidence,"phone-current-result.jpg"),type:"jpeg",quality:80});
     await page.getByRole("link",{name:"Retained source",exact:true}).click();
     await page.screenshot({path:path.join(evidence,"phone-retained-source.jpg"),type:"jpeg",quality:80});
   }
   await page.locator(".download").scrollIntoViewIfNeeded();
   const downloadPromise=page.waitForEvent("download");
   await page.getByRole("link",{name:"Download exact recheck JSON",exact:true}).click();
   const download=await downloadPromise;
   assert.equal(download.suggestedFilename(),"recheck.json");
   const downloadPath=path.join(evidence,"downloads",fixture.label+".json");
   await download.saveAs(downloadPath);
   assert.equal(await download.failure(),null);
   const saved=fs.readFileSync(downloadPath);
   assert.deepEqual(saved,raw);
   assert.equal(sha(fs.readFileSync(path.join(root,"fixtures",fixture.label+".json"))),fixture.sha256);
   const observed={label:fixture.label,origin:fixture.origin,currentStatus:input.status,currentFacts:rf,originFacts:of,recordedCounts,caseCount:observedCases.length,retainedFiles:observedSources.length,sourceDetails:observedSources,cases:observedCases,tail,layout,phone,download:{bytes:saved.length,sha256:sha(saved),suggestedFilename:download.suggestedFilename()},result:"PASS"};
   fs.writeFileSync(path.join(evidence,fixture.label+".dom.json"),JSON.stringify(observed,null,2)+"\n");
   receipt.cases.push({...observed,sourceDetails:undefined,cases:undefined,tail:undefined});
   console.log(JSON.stringify({label:fixture.label,result:"PASS",download:observed.download}));
   await context.close();
  }
  assert.deepEqual(receipt.requests,[]);
  assert.deepEqual(receipt.pageErrors,[]);
  assert.deepEqual(receipt.dialogs,[]);
  assert.deepEqual(receipt.popups,[]);
  receipt.result="PASS";
 } catch(error) {
  receipt.result="FAIL";receipt.error={message:error.message,stack:error.stack};process.exitCode=1;
 } finally {
  if(browser) await browser.close();
  fs.writeFileSync(path.join(evidence,"browser-receipt.json"),JSON.stringify(receipt,null,2)+"\n");
  console.log(JSON.stringify({result:receipt.result,groups:receipt.cases.length,pageErrors:receipt.pageErrors.length,requests:receipt.requests.length,error:receipt.error?.message}));
 }
})();
