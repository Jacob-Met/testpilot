from pathlib import Path
import time
p=Path(__file__).with_name('release')
deadline=time.monotonic()+10
while not p.exists() and time.monotonic()<deadline: time.sleep(.01)
