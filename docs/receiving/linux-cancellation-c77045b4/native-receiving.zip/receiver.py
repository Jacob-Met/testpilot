from pathlib import Path
import subprocess,os,sys,time,signal,json,hashlib,stat
root=Path(__file__).resolve().parent
def snapshot(p):
 b=p.read_bytes();s=p.stat()
 return {"sha256":hashlib.sha256(b).hexdigest(),"inode":s.st_ino,"mode":stat.S_IMODE(s.st_mode),"mtime_ns":s.st_mtime_ns,"ctime_ns":s.st_ctime_ns}
def procstate(info):
 try:
  rest=Path("/proc",str(info["pid"]),"stat").read_text().split(") ",1)[1].split()
  return {"pid":info["pid"],"state":rest[0],"same_identity":rest[19]==info["start_ticks"],"active":rest[19]==info["start_ticks"] and rest[0] not in ["Z","X"]}
 except FileNotFoundError:return {"pid":info["pid"],"state":"absent","same_identity":False,"active":False}
sentinels=root/"sentinels";sentinels.mkdir()
for i in range(4):
 p=sentinels/("output-"+str(i)+".txt");p.write_bytes(("prior synthetic output "+str(i)+"\n").encode());p.chmod(0o640);os.utime(p,ns=(1660000000123456789,1660000000123456789))
before={p.name:snapshot(p) for p in sentinels.iterdir()}
results=[];cleanup=[]
for variant in ["baseline","candidate"]:
 for mode in ["ordinary","same","escaped"]:
  case=root/"runs"/(variant+"-"+mode);case.mkdir(parents=True)
  source=root/(variant+"-sandbox.py")
  with (case/"runner.stdout.txt").open("w") as out,(case/"runner.stderr.txt").open("w") as err:
   parent=subprocess.Popen([sys.executable,str(root/"runner.py"),str(source),str(case),mode],stdout=out,stderr=err,start_new_session=True,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
   if mode=="ordinary":
    parent.wait(timeout=15)
    returned=json.loads((case/"returned.json").read_text())
    ok=parent.returncode==0 and returned["result"]==[7,"out-control\nerr-control\n",False]
    results.append({"variant":variant,"mode":mode,"ok":ok,"returncode":parent.returncode,"returned":returned});continue
   ready_until=time.monotonic()+12
   while not all((case/(role+".json")).exists() for role in ["leader","leaf"]):
    if parent.poll() is not None:raise RuntimeError("runner exited before ready")
    if time.monotonic()>ready_until:raise TimeoutError("helpers did not become ready")
    time.sleep(.01)
   infos={role:json.loads((case/(role+".json")).read_text()) for role in ["leader","leaf"]}
   assert infos["leader"]["pgid"]==infos["leader"]["pid"]
   assert (infos["leaf"]["pgid"]==infos["leader"]["pgid"])==(mode=="same")
   sent=time.monotonic();os.kill(parent.pid,signal.SIGINT)
   try:parent.wait(timeout=6)
   except subprocess.TimeoutExpired:
    cleanup.append({"kind":"receiver-parent-timeout","pid":parent.pid});os.kill(parent.pid,signal.SIGKILL);parent.wait()
   elapsed=time.monotonic()-sent
   at_exit={role:procstate(info) for role,info in infos.items()}
   caught=(case/"caught-interrupt.json").exists()
   (case/"release").write_text("released only after runner exit\n")
   released=time.monotonic()
   until=released+5
   while any(procstate(info)["active"] for info in infos.values()) and time.monotonic()<until:time.sleep(.01)
   markers={role:(case/(role+"-after.txt")).exists() for role in infos}
   final={role:procstate(info) for role,info in infos.items()}
   for role,info in infos.items():
    if final[role]["active"]:
     cleanup.append({"kind":"finite-helper-cleanup","role":role,"pid":info["pid"]})
     os.kill(info["pid"],signal.SIGKILL)
   if mode=="same":
    semantic=all(not v["active"] for v in at_exit.values()) and not any(markers.values())
   else:
    semantic=not at_exit["leader"]["active"] and at_exit["leaf"]["active"] and not markers["leader"] and markers["leaf"]
   ok=parent.returncode==130 and caught and elapsed<5 and semantic and all(not x["active"] for x in final.values())
   result={"variant":variant,"mode":mode,"ok":ok,"returncode":parent.returncode,"caught_keyboard_interrupt":caught,"interrupt_to_parent_exit_seconds":elapsed,"barrier_released_after_parent_exit":True,"helpers":infos,"at_parent_exit":at_exit,"post_barrier_markers":markers,"final":final}
   (case/"case-receipt.json").write_text(json.dumps(result,indent=2)+"\n");results.append(result)
after={p.name:snapshot(p) for p in sentinels.iterdir()}
receipt={"schema":"testpilot.independent.linux.receiving.v1","python":sys.version,"platform":sys.platform,"source_head":"95a3116c175debdf97fd9dc1c984a587a90a5d3b","current_base":"cec50d8df4499ba509615e179d82ef3861379bd2","source_sha256":{v:hashlib.sha256((root/(v+"-sandbox.py")).read_bytes()).hexdigest() for v in ["baseline","candidate"]},"results":results,"sentinels_before":before,"sentinels_after":after,"sentinels_exact":before==after,"receiver_cleanup":cleanup,"scope":"Complete sandbox module actual POSIX process boundary; no full CLI/provider/full suite gate claimed"}
receipt["accepted"]=all(x["ok"] for x in results if x["variant"]=="candidate") and any(not x["ok"] for x in results if x["variant"]=="baseline" and x["mode"]=="same") and before==after and not cleanup
(root/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"accepted":receipt["accepted"],"results":[{k:v for k,v in x.items() if k in ["variant","mode","ok","returncode","interrupt_to_parent_exit_seconds","post_barrier_markers"]} for x in results],"sentinels_exact":before==after,"cleanup":cleanup}))
