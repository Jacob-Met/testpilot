from pathlib import Path
import os,sys,time,json,subprocess
case=Path(sys.argv[1]);role=sys.argv[2];mode=sys.argv[3]
def info():
 raw=Path("/proc/self/stat").read_text().split(") ",1)[1].split()
 return {"pid":os.getpid(),"pgid":os.getpgrp(),"sid":os.getsid(0),"start_ticks":raw[19]}
child=None
if role=="leader":
 child=subprocess.Popen([sys.executable,__file__,str(case),"leaf",mode],start_new_session=(mode=="escaped"))
(case/(role+".json")).write_text(json.dumps(info()))
deadline=time.monotonic()+20
while not (case/"release").exists() and time.monotonic()<deadline:time.sleep(.01)
if (case/"release").exists():(case/(role+"-after.txt")).write_text("work performed after receiver released barrier\n")
else:(case/(role+"-deadline.txt")).write_text("finite safety deadline reached\n")
if child:
 try:child.wait(timeout=3)
 except subprocess.TimeoutExpired:pass
