from pathlib import Path
import sys,os,json,importlib.util,time
source=Path(sys.argv[1]);case=Path(sys.argv[2]);mode=sys.argv[3]
spec=importlib.util.spec_from_file_location("received_sandbox",source)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
if mode=="ordinary":
 result=module._run([sys.executable,"-c","import sys; print('out-control',flush=True); print('err-control',file=sys.stderr,flush=True); sys.exit(7)"],case,module.clean_env(case),10)
 (case/"returned.json").write_text(json.dumps({"result":result}))
else:
 try:
  result=module._run([sys.executable,str(Path(__file__).with_name("worker.py")),str(case),"leader",mode],case,module.clean_env(case),30)
  (case/"unexpected-return.json").write_text(json.dumps(result))
 except KeyboardInterrupt:
  (case/"caught-interrupt.json").write_text(json.dumps({"kind":"KeyboardInterrupt","at":time.monotonic()}))
  sys.exit(130)
