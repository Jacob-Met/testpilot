# TestPilot accepted wheel — Windows receiving

This companion records one actual installed-wheel run on original MSI device edc358ed-5ad6-4036-b7aa-8667bf0e14e0, user jacob, Windows 11 build 26200, C:\Python314\python.exe 3.14.3. It qualifies the unchanged source d2596c1a4be11072344c4ea98752cce789865ec4, tree 3b6d270f655310fa2f98cab9bccffca23ec146cf, from Jacob-Met/testpilot. It makes no current-main or maintained-suite claim.

## Accepted input

Use the previously delivered TestPilot-Scripted-Review-d2596c1a-20261013-v2.zip: 107,866 bytes, SHA256 8b3c856751ae9bd24b74474b68624e38e97d9157429aafc6c9d671676be00a4d. All 31 extracted members, 30 manifest payloads and CRC were checked before use. The original ZIP remains immutable in this receiving capsule as kit-v2.zip; it is not duplicated inside this evidence companion.

The contained testpilot-0.1.0-py3-none-any.whl is 75,206 bytes, SHA256 c471d961e1b26051209b2d8bdcf0629b1f0185b25ae6c0d0d733bacca344d246. Its version alone does not identify the accepted source. Every one of the 14 installed modules matched its published Git blob and SHA256 before and after execution.

## Windows prerequisites and commands

The existing pytest 9.0.2 is in Jacob's Python314 user site. The ordinary new virtual environment with --system-site-packages can import it. Python -I hides that user site on this machine, so these Windows commands deliberately omit -I. No dependency copying, .pth addition or dependency download was needed. Stop if the pytest check fails; this companion does not install missing dependencies.

In Command Prompt, from a fresh complete extraction of the accepted kit, choose a new environment and output directory:

```bat
set PYTHONPATH=
set PYTHONHOME=
set PYTHONNOUSERSITE=
set PYTHONDONTWRITEBYTECODE=1
set PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
C:\Python314\python.exe -B -m venv --system-site-packages testpilot-review
testpilot-review\Scripts\python.exe -B -c "import pytest; print(pytest.__version__); assert int(pytest.__version__.split('.')[0]) >= 8"
testpilot-review\Scripts\python.exe -B -m pip install --no-index --no-deps --no-cache-dir --no-compile testpilot-0.1.0-py3-none-any.whl
testpilot-review\Scripts\python.exe -B -m testpilot --help
testpilot-review\Scripts\python.exe -B -m testpilot targets --repo sample/repo --diff sample/change.diff --json
testpilot-review\Scripts\python.exe -B -m testpilot run --repo sample/repo --diff sample/change.diff --backend scripted --script sample/script --out sample-result --no-coverage
```

The actual receiving controller invoked these interpreter/CLI operations with argument lists rather than through Command Prompt. Its full commands, working directory, raw streams and PIDs are retained. It cleared inherited Python path, TestPilot/provider and credential-like environment overrides without recording their values, disabled unrelated pytest plugin autoload, and directed temporary work into the new capsule. No live backend or provider was used.

## Observed outcome

The seven operations exited 0, 0, 0, 0, 0, 0, 1: environment creation, pytest import, wheel installation, installed-module location check, help, target preview, scripted sample. The final exit 1 is the expected demonstration result: suspected_code_bug, 3 failed and 3 passed cases, including 4 generated cases (1 passed, 3 failed). JUnit was available; no timeout occurred. No proposed patch was applied.

The target preview JSON and generated test contents match the recorded cloud case. Patch text matches after normal native newline decoding; the raw Windows patch bytes are retained separately. Runtime timings, platform diagnostics and native newlines differ, so the full native reports are not claimed byte-identical to cloud outputs.

All four actual outputs are included under sample-result/: report.html, report.json, report.md and testpilot.patch. Open the HTML as a saved report or inspect the JSON and patch. No browser rendering was performed in this receiving course.

All 36 input guards (31 kit members, original ZIP, transport text, controller, accepted-source pins and base interpreter) and all 14 installed-module byte/metadata guards were unchanged. Temporary fixtures were cleaned by the completed course. The venv and reports remain in C:\Users\jacob\hamon-testpilot-wheel-windows-1caa1d8e028a.

## Evidence and bounds

receiving/receipt.json binds every raw operation, exact native paths and source guards. controller.py is the as-run receiver. routing.json preserves the connected device, staging and completed controller PID 145988. source manifests retain the accepted historical pins. The outer MANIFEST.json binds every evidence payload.

This is isolated native qualification of an accepted wheel and its original synthetic example. It does not establish installed estate adoption, current-source compatibility, live model quality, timeout/interrupt behavior, browser usability or a full test-suite pass. Publication/disposition belongs to the existing project delivery handoff; this receipt changes no source, workflow, shared Python installation or review gate.
