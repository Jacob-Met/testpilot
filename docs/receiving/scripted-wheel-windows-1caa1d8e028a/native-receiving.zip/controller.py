from pathlib import Path, PurePosixPath
import base64,collections,datetime,hashlib,io,json,os,platform,subprocess,sys,time,traceback,zipfile
root=Path(__file__).parent
logs=root/'receiving'; logs.mkdir()
tmp=root/'tmp'; tmp.mkdir()
packet=root/'packet'; packet.mkdir()
env=dict(os.environ)
for key in list(env):
 if key in ['PYTHONPATH','PYTHONHOME','PYTHONNOUSERSITE','PYTEST_ADDOPTS','PYTEST_PLUGINS','COVERAGE_PROCESS_START','COVERAGE_FILE'] or key.startswith('TESTPILOT_') or any(mark in key.upper() for mark in ['KEY','TOKEN','SECRET','NEBIUS','OPENAI','NVIDIA']):
  env.pop(key,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',TMP=str(tmp),TEMP=str(tmp))
receipt={'device_id':'edc358ed-5ad6-4036-b7aa-8667bf0e14e0','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_pid':os.getpid(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'capsule':str(root),'calls':[],'scope':'Unchanged accepted wheel and original scripted sample only; no provider, dependency downloads, maintained suite or installed estate project.'}
def snap(p):
 s=p.stat();b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mtime_ns':s.st_mtime_ns,'mode':s.st_mode,'inode':s.st_ino}
def save():
 (logs/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
def run(label,cmd,expected):
 out=logs/(label+'.stdout');err=logs/(label+'.stderr')
 started=time.monotonic()
 with out.open('xb') as o,err.open('xb') as e:
  proc=subprocess.Popen(cmd,cwd=packet,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e)
  item={'label':label,'command':[str(x) for x in cmd],'cwd':str(packet),'pid':proc.pid,'expected_exit':expected};receipt['calls'].append(item);save()
  rc=proc.wait(timeout=180)
 item.update(exit=rc,duration_s=round(time.monotonic()-started,6),stdout=snap(out),stderr=snap(err));save()
 assert rc==expected,(label,rc,expected,err.read_bytes().decode(errors='replace'))
 return out.read_bytes()
guarded=[];modules=[]
try:
 b=b''.join(base64.b64decode(line,validate=True) for line in (root/'kit.base64').read_text().splitlines() if line)
 assert len(b)==107866 and hashlib.sha256(b).hexdigest()=='8b3c856751ae9bd24b74474b68624e38e97d9157429aafc6c9d671676be00a4d'
 with (root/'kit-v2.zip').open('xb') as f:f.write(b)
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  names=z.namelist();assert len(names)==31 and len(set(names))==31 and z.testzip() is None
  manifest=json.loads(z.read('MANIFEST.json'));assert len(manifest['files'])==30
  assert set(names)=={'MANIFEST.json'}|{r['path'] for r in manifest['files']}
  for r in manifest['files']:
   v=z.read(r['path']);assert len(v)==r['bytes'] and hashlib.sha256(v).hexdigest()==r['sha256']
  for name in names:
   rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in name
   dest=packet.joinpath(*rel.parts);dest.parent.mkdir(parents=True,exist_ok=True)
   with dest.open('xb') as f:f.write(z.read(name))
 source=json.loads((packet/'SOURCE_MANIFEST.json').read_text())
 assert source['source_commit']=='d2596c1a4be11072344c4ea98752cce789865ec4' and source['source_tree']=='3b6d270f655310fa2f98cab9bccffca23ec146cf'
 pins={r['path']:r for r in json.loads((root/'accepted-source-pins.json').read_text())['files']}
 for r in source['files']:
  assert pins[r['path']]['sha']==r['sha'] and pins[r['path']]['size']==r['bytes']
 wheel=packet/'testpilot-0.1.0-py3-none-any.whl'
 assert len(wheel.read_bytes())==75206 and hashlib.sha256(wheel.read_bytes()).hexdigest()=='c471d961e1b26051209b2d8bdcf0629b1f0185b25ae6c0d0d733bacca344d246'
 guarded=sorted(p for p in packet.rglob('*') if p.is_file())+[root/'kit-v2.zip',root/'kit.base64',Path(__file__),root/'accepted-source-pins.json',Path(sys.executable)]
 receipt['input_guards_before']=[snap(p) for p in guarded];save()
 venv=root/'venv';assert not venv.exists()
 run('create-venv',[sys.executable,'-B','-m','venv','--system-site-packages',str(venv)],0)
 py=venv/'Scripts/python.exe'
 info="import sys,site,json,pytest; print(json.dumps({'exe':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'pytest_version':pytest.__version__,'pytest_file':pytest.__file__,'user_site_enabled':site.ENABLE_USER_SITE})); assert int(pytest.__version__.split('.')[0])>=8"
 capability=json.loads(run('venv-pytest',[str(py),'-B','-c',info],0))
 assert Path(capability['prefix'])==venv and capability['prefix']!=capability['base_prefix']
 receipt['venv_capability']=capability;save()
 run('install-wheel',[str(py),'-B','-m','pip','install','--no-index','--no-deps','--no-cache-dir','--no-compile',str(wheel)],0)
 installed=json.loads(run('installed-location',[str(py),'-B','-c',"import json,testpilot,sys; print(json.dumps({'module':testpilot.__file__,'exe':sys.executable}))"],0))
 site_packages=venv/'Lib/site-packages'
 assert Path(installed['module']).resolve()==(site_packages/'testpilot/__init__.py').resolve()
 for r in source['files']:
  if r['path'].startswith('testpilot/') and r['path'].endswith('.py'):
   p=site_packages/r['path'];v=p.read_bytes()
   assert len(v)==r['bytes'] and hashlib.sha256(v).hexdigest()==r['sha256']
   assert hashlib.sha1(b'blob '+str(len(v)).encode()+bytes([0])+v).hexdigest()==r['sha']
   modules.append(p)
 assert len(modules)==14
 receipt['installed_modules_before']=[snap(p) for p in modules];receipt['installed_identity']=installed;save()
 run('help',[str(py),'-B','-m','testpilot','--help'],0)
 target=run('targets',[str(py),'-B','-m','testpilot','targets','--repo','sample/repo','--diff','sample/change.diff','--json'],0)
 assert json.loads(target)==json.loads((packet/'receiving/targets.stdout.txt').read_bytes())
 run('scripted',[str(py),'-B','-m','testpilot','run','--repo','sample/repo','--diff','sample/change.diff','--backend','scripted','--script','sample/script','--out',str(root/'sample-result'),'--no-coverage'],1)
 result=root/'sample-result';report=json.loads((result/'report.json').read_bytes())
 assert report['status']=='suspected_code_bug' and report['tests_written']==4
 final=report['final'];assert final['returncode']==1 and not final['timed_out'] and final['junit_available']
 assert (final['passed'],final['failed'],final['errors'],final['skipped'])==(3,3,0,0)
 assert final['generated']=={'collected':4,'passed':1,'failed':3,'error':0,'skipped':0}
 assert {p.name for p in result.iterdir()}=={'report.html','report.md','report.json','testpilot.patch'}
 assert report['test_files']==json.loads((packet/'recorded-result/report.json').read_bytes())['test_files']
 receipt['result']={'status':report['status'],'tests_written':report['tests_written'],'passed':final['passed'],'failed':final['failed'],'generated':final['generated'],'junit_available':final['junit_available'],'target_json_exact_cloud':True,'generated_files_exact_cloud':True,'patch_text_exact_cloud':(result/'testpilot.patch').read_text()==(packet/'recorded-result/testpilot.patch').read_text(),'files':[snap(p) for p in sorted(result.iterdir())]}
 receipt['outcome']='PASS'
except Exception:
 receipt['outcome']='INCOMPLETE_OR_FAILED';receipt['error']=traceback.format_exc()
finally:
 if guarded:
  receipt['input_guards_after']=[snap(p) for p in guarded]
  receipt['inputs_unchanged']=receipt['input_guards_before']==receipt['input_guards_after']
 if modules:
  receipt['installed_modules_after']=[snap(p) for p in modules]
  receipt['installed_modules_unchanged']=receipt.get('installed_modules_before')==receipt['installed_modules_after']
 receipt['temporary_entries']=[p.name for p in tmp.iterdir()]
 receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps({'receipt':str(logs/'receipt.json'),'sha256':hashlib.sha256((logs/'receipt.json').read_bytes()).hexdigest(),'outcome':receipt['outcome'],'calls':[{k:r.get(k) for k in ['label','pid','exit']} for r in receipt['calls']],'inputs_unchanged':receipt.get('inputs_unchanged'),'installed_modules_unchanged':receipt.get('installed_modules_unchanged'),'result':receipt.get('result'),'error':receipt.get('error')}))
sys.exit(0 if receipt['outcome']=='PASS' and receipt.get('inputs_unchanged') and receipt.get('installed_modules_unchanged') else 1)
