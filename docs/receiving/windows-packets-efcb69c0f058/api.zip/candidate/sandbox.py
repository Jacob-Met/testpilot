"""Run pytest against a throwaway copy of a repo, with a wall-clock timeout.

Isolation is process-level only: a temp copy of the repo, a fresh process
group killed on timeout, and an environment with credential-looking variables
removed. It is NOT a security boundary against hostile code — run TestPilot in
a container/VM for untrusted repos.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path, PurePosixPath

IGNORE = shutil.ignore_patterns(".git", "__pycache__", ".pytest_cache", ".venv", "venv",
                                "*.pyc", ".coverage", "node_modules", ".mypy_cache")
_SECRET_MARKERS = ("KEY", "TOKEN", "SECRET", "PASSWORD", "CREDENTIAL")
_OMIT = "*/tests/*,*/test_*.py,*_test.py,*/conftest.py"
_COVERAGE_PROBE_TIMEOUT_S = 5.0


@dataclass
class CaseResult:
    nodeid: str
    outcome: str  # passed | failed | error | skipped
    message: str = ""
    generated_file: str | None = None


@dataclass
class CoverageReport:
    percent_total: float
    files: dict[str, dict[str, list[int]]] = field(default_factory=dict)

    def executed(self, path: str) -> set[int]:
        return set(self.files.get(path, {}).get("executed", []))

    def executable(self, path: str) -> set[int]:
        f = self.files.get(path, {})
        return set(f.get("executed", [])) | set(f.get("missing", []))


@dataclass
class SandboxResult:
    returncode: int | None
    timed_out: bool
    duration_s: float
    timeout_s: float
    output: str
    cases: list[CaseResult] = field(default_factory=list)
    coverage: CoverageReport | None = None
    generated_files: list[str] = field(default_factory=list)
    junit_available: bool = False

    def _count(self, outcome: str) -> int:
        return sum(1 for c in self.cases if c.outcome == outcome)

    @property
    def passed(self) -> int:
        return self._count("passed")

    @property
    def failed(self) -> int:
        return self._count("failed")

    @property
    def errors(self) -> int:
        return self._count("error")

    @property
    def skipped(self) -> int:
        return self._count("skipped")

    @property
    def generated_cases(self) -> list[CaseResult]:
        return [c for c in self.cases if c.generated_file in self.generated_files]

    def generated_counts(self) -> dict[str, int] | None:
        if not self.generated_files:
            return None
        cases = self.generated_cases
        return {"collected": len(cases),
                **{outcome: sum(c.outcome == outcome for c in cases)
                   for outcome in ("passed", "failed", "error", "skipped")}}

    @property
    def ok(self) -> bool:
        return (not self.timed_out and self.returncode == 0 and self.failed == 0
                and self.errors == 0 and self.passed > 0
                and (not self.generated_files
                     or any(c.outcome == "passed" for c in self.generated_cases)))

    def summary(self) -> str:
        if self.timed_out:
            return f"TIMEOUT after {self.timeout_s:g}s"
        text = (f"{self.passed} passed, {self.failed} failed, {self.errors} errors, "
                f"{self.skipped} skipped (rc={self.returncode})")
        generated = self.generated_counts()
        if generated is not None:
            text += (f"; generated: {generated['passed']} passed of "
                     f"{generated['collected']} collected")
        return text

    def failure_report(self, limit: int = 4000) -> str:
        parts = [self.summary()]
        generated = self.generated_counts()
        if generated is not None and generated["passed"] == 0:
            parts.append("No generated test case passed. Existing-suite passes cannot verify "
                         "the generated files. Write runnable tests and check project collection "
                         "rules, deselection and skip conditions.")
        if self.timed_out:
            parts.append("The test run exceeded the time limit and was killed. "
                         "Look for infinite loops, blocking I/O, or very slow tests.")
        for c in self.cases:
            if c.outcome in ("failed", "error"):
                parts.append(f"--- {c.outcome.upper()}: {c.nodeid}\n{c.message.strip()}")
        if not any(c.outcome in ("failed", "error") for c in self.cases):
            parts.append("--- pytest output (tail)\n" + self.output[-2000:])
        text = "\n".join(parts)
        return text if len(text) <= limit else text[: limit - 20] + "\n...[truncated]"

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(passed=self.passed, failed=self.failed, errors=self.errors,
                 skipped=self.skipped, ok=self.ok, summary=self.summary())
        d["generated"] = self.generated_counts()
        d["output"] = self.output[-3000:]
        return d


@lru_cache(maxsize=None)
def coverage_available(python: str) -> bool:
    """Detect optional coverage without waiting indefinitely before pytest starts."""
    try:
        result = subprocess.run(
            [python, "-c", "import coverage"], stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=_COVERAGE_PROBE_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        return False
    return result.returncode == 0


def clean_env(root: Path) -> dict[str, str]:
    env = {k: v for k, v in os.environ.items() if not any(m in k.upper() for m in _SECRET_MARKERS)}
    for k in ("PYTEST_ADDOPTS", "PYTEST_PLUGINS", "COVERAGE_PROCESS_START", "COVERAGE_FILE"):
        env.pop(k, None)
    paths = [str(root / "src")] if (root / "src").is_dir() else []
    env.update(PYTHONPATH=os.pathsep.join(paths + [str(root)]), PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    return env


def _run(cmd: list[str], cwd: Path, env: dict, timeout: float) -> tuple[int | None, str, bool]:
    """Collect output; bound POSIX cleanup and Windows leader cancellation."""
    proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, errors="replace", start_new_session=True)
    try:
        out, _ = proc.communicate(timeout=timeout)
        return proc.returncode, out, False
    except KeyboardInterrupt:
        if os.name == "posix":
            try:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                # Reap the leader without draining an escaped helper's pipe.
                proc.wait(timeout=1.0)
            except (OSError, subprocess.TimeoutExpired):
                # Cleanup failure must not replace the caller's cancellation.
                pass
            finally:
                proc.stdout.close()
        elif os.name == "nt":
            try:
                # Reap only the launched leader; an active reader may retain the pipe.
                proc.kill()
                proc.wait(timeout=1.0)
            except (OSError, subprocess.TimeoutExpired):
                # Cleanup failure must not replace the caller's cancellation.
                pass
        raise
    except subprocess.TimeoutExpired:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, AttributeError, PermissionError):
            proc.kill()
        try:
            # A detached helper may retain stdout after the target group dies.
            # POSIX communicate uses synchronous reads that we can stop and close;
            # preserve the existing Windows reader-thread cleanup behavior.
            out, _ = proc.communicate(timeout=1.0 if os.name == "posix" else None)
        except subprocess.TimeoutExpired as exc:
            # TimeoutExpired.output is bytes even in text mode. Preserve complete
            # diagnostics plus a replacement for a character cut off by the kill.
            out = (exc.output or b"").decode(proc.stdout.encoding, errors="replace")
            out = out.replace("\r\n", "\n").replace("\r", "\n")
            proc.stdout.close()
            proc.poll()  # Reap the killed leader without waiting for escaped helpers.
        return None, out or "", True


def parse_junit(path: Path) -> list[CaseResult]:
    root = ET.parse(path).getroot()
    cases: list[CaseResult] = []
    for tc in root.iter("testcase"):
        cls, name = tc.get("classname", ""), tc.get("name", "")
        nodeid = f"{cls}::{name}" if cls else name
        outcome, msg = "passed", ""
        for tag, label in (("failure", "failed"), ("error", "error"), ("skipped", "skipped")):
            el = tc.find(tag)
            if el is not None:
                outcome = label
                msg = (el.get("message") or "") + ("\n" + el.text if el.text else "")
                break
        generated_file = None
        for prop in tc.findall("./properties/property"):
            if prop.get("name") == "testpilot.generated_file":
                generated_file = prop.get("value")
                break
        cases.append(CaseResult(nodeid, outcome, msg, generated_file))
    return cases


def _parse_coverage(path: Path, work: Path) -> CoverageReport:
    data = json.loads(path.read_text())
    files = {}
    resolved = work.resolve()
    for name, info in data.get("files", {}).items():
        p = Path(name)
        if p.is_absolute():
            try:
                name = p.resolve().relative_to(resolved).as_posix()
            except ValueError:
                continue
        files[PurePosixPath(name).as_posix()] = {"executed": info.get("executed_lines", []),
                                                 "missing": info.get("missing_lines", [])}
    return CoverageReport(float(data.get("totals", {}).get("percent_covered", 0.0)), files)


def _safe_join(root: Path, rel: str) -> Path:
    p = (root / rel).resolve()
    if root.resolve() not in p.parents:
        raise ValueError(f"refusing to write outside sandbox: {rel}")
    return p


def run_pytest(repo: str | Path, extra_files: dict[str, str] | None = None, *, timeout: float = 60.0,
               python: str | None = None, coverage: bool | None = None,
               pytest_args: tuple[str, ...] = (), exact_files: bool = False) -> SandboxResult:
    """Copy repo, add tests, run pytest and collect native results.

    exact_files admits retained UTF-8 bytes: matching copied files are reused,
    different copied files refuse, and new files use binary output. The default
    generation path retains its existing text-write behavior.
    """
    python = python or sys.executable
    use_cov = coverage_available(python) if coverage is None else coverage
    with tempfile.TemporaryDirectory(prefix="testpilot-") as td:
        tdp = Path(td)
        work = tdp / "repo"
        shutil.copytree(repo, work, ignore=IGNORE)
        for rel, content in (extra_files or {}).items():
            dest = _safe_join(work, rel)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if exact_files:
                data = content.encode("utf-8")
                if dest.exists():
                    if not dest.is_file() or dest.stat().st_size != len(data):
                        raise ValueError(f"copied retained test differs: {rel}")
                    with dest.open("rb") as stream:
                        if stream.read(len(data) + 1) != data:
                            raise ValueError(f"copied retained test differs: {rel}")
                else:
                    with dest.open("xb") as stream:
                        stream.write(data)
            else:
                dest.write_text(content, encoding="utf-8")
        junit = tdp / "junit.xml"
        options = ["-q", "-p", "no:cacheprovider", "--rootdir", str(work), "-o", "addopts=",
              "-o", "junit_family=xunit2", f"--junitxml={junit}", *pytest_args]
        generated_files = sorted(extra_files or {})
        pt = ["-m", "pytest", *options]
        if generated_files:
            runner = tdp / "generated_pytest.py"
            manifest = tdp / "generated_files.json"
            shutil.copyfile(Path(__file__).with_name("_pytest_generated.py"), runner)
            manifest.write_text(json.dumps({str(_safe_join(work, rel)): rel for rel in generated_files}),
                                encoding="utf-8")
            pt = [str(runner), str(manifest), *options]
        data_file = tdp / ".coverage"
        if use_cov:
            cmd = [python, "-m", "coverage", "run", f"--data-file={data_file}", f"--source={work}",
                   f"--omit={_OMIT}", *pt]
        else:
            cmd = [python, *pt]
        env = clean_env(work)
        t0 = time.monotonic()
        rc, out, timed_out = _run(cmd, work, env, timeout)
        dur = time.monotonic() - t0
        junit_available = junit.exists() and not timed_out
        cases = parse_junit(junit) if junit_available else []
        cov = None
        if use_cov and not timed_out:
            # Reserve the report destination after pytest so a failed report
            # command cannot reuse a file left by the test run.
            with tempfile.TemporaryDirectory(prefix="coverage-report-", dir=tdp) as report_dir:
                cov_json = Path(report_dir) / "cov.json"
                crc, _, _ = _run([python, "-m", "coverage", "json", f"--data-file={data_file}", "-o", str(cov_json), "-q"],
                                 work, env, 60)
                # Exit 2 can mean a complete report is below configured fail_under.
                cov = _parse_coverage(cov_json, work) if crc in (0, 2) and cov_json.exists() else None
        return SandboxResult(rc, timed_out, round(dur, 3), timeout, out, cases, cov,
                             generated_files, junit_available)
