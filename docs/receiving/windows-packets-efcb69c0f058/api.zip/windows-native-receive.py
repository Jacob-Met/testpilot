"""Qualify the retained Windows cancellation arm with owned real processes."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import threading
import time

ROOT = Path(sys.argv[1]).resolve()
RECEIPT = ROOT / 'native-receipt.json'
RECEIPT_DATA = {
    'schema': 'testpilot.windows-composition-native-receiving/1',
    'executor': 'runtime_consumer', 'started_at': time.time(),
    'hostname': platform.node(), 'platform': sys.platform,
    'python': sys.version, 'root': str(ROOT), 'cases': [],
    'scope': 'Controlled KeyboardInterrupt during real Windows communication; no hardware Ctrl-C or process-tree claim',
    'base': '52275f50e672c145d8f69e90cf40948ab28a7d79',
    'retained_offer': '8a5571dd43ea8077c07cb4d7dec8b5b5e3967d1a',
    'repository': 'Jacob-Met/testpilot',
    'candidate_commit': '067cf4597c067aad41216ba39c8c29fe3ecd9f3a',
}
REAL_POPEN = subprocess.Popen
EXPECTED_SHA256 = {
    'baseline': 'a3bae551058fc6524dc363bfe8a39c0c0c1cf081779a7e3dadd9d5ae8d33ae34',
    'candidate': '899a454dea73c988645b04cba887b13f7770b824b00f0c0f8be5c179903577e0',
}


def persist():
    RECEIPT.write_text(json.dumps(RECEIPT_DATA, indent=2) + '\n', encoding='utf-8')


def await_condition(fn, label, timeout=5.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        value = fn()
        if value:
            return value
        time.sleep(0.01)
    raise AssertionError('Timed out: ' + label)


def load_source(label):
    source = ROOT / label / 'sandbox.py'
    data = source.read_bytes()
    RECEIPT_DATA[label + '_sha256'] = hashlib.sha256(data).hexdigest()
    assert RECEIPT_DATA[label + '_sha256'] == EXPECTED_SHA256[label], label + ' source differs'
    spec = importlib.util.spec_from_file_location('native_sandbox_' + label, source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


HELPER = r'''import os, pathlib, sys, time
root = pathlib.Path(sys.argv[1])
(root / 'helper.pid').write_text(str(os.getpid()))
print('owned helper ready', flush=True)
end = time.monotonic() + 15
while not (root / 'release').exists() and time.monotonic() < end:
    time.sleep(0.02)
'''

LEADER = r'''import os, pathlib, subprocess, sys, time
root, mode = pathlib.Path(sys.argv[1]), sys.argv[2]
if mode in ('retained-pipe', 'already-exited'):
    subprocess.Popen([sys.executable, '-c', sys.argv[3], str(root)],
                     stdin=subprocess.DEVNULL, stdout=sys.stdout, stderr=sys.stderr)
    end = time.monotonic() + 5
    while not (root / 'helper.pid').exists() and time.monotonic() < end:
        time.sleep(0.01)
    if not (root / 'helper.pid').exists():
        raise SystemExit(97)
(root / 'leader.ready').write_text(str(os.getpid()))
print('owned leader ready', flush=True)
if mode == 'already-exited':
    raise SystemExit(23)
end = time.monotonic() + 15
while not (root / 'release').exists() and time.monotonic() < end:
    time.sleep(0.02)
'''


def run_interrupt(module, label, mode, expect_cleanup):
    work = ROOT / (label + '-' + mode)
    work.mkdir()
    cancellation = KeyboardInterrupt('native receiving owned cancellation')
    state = {'source': label, 'mode': mode, 'expected_product_leader_cleanup': expect_cleanup}
    proc = None
    reader = None
    helper_handle = None
    communication = {}

    class ObservedPopen(REAL_POPEN):
        def communicate(self, *args, **kwargs):
            nonlocal proc, reader, helper_handle
            proc = self
            state['leader_pid'] = self.pid

            def native_reader():
                try:
                    communication['returned'] = REAL_POPEN.communicate(self, *args, **kwargs)
                except BaseException as error:
                    communication['error'] = type(error).__name__ + ': ' + str(error)

            reader = threading.Thread(target=native_reader, daemon=True)
            reader.start()
            await_condition(lambda: (work / 'leader.ready').exists(), 'owned leader ready')
            await_condition(lambda: hasattr(self, 'stdout_thread') and self.stdout_thread.is_alive(), 'real Windows output reader')
            if mode != 'live-leader':
                pid = int((work / 'helper.pid').read_text())
                state['helper_pid'] = pid
                helper_handle = kernel32.OpenProcess(0x00100000, False, pid)
                assert helper_handle, 'Cannot observe owned helper handle'
                state['helper_alive_at_injection'] = kernel32.WaitForSingleObject(helper_handle, 0) == 258
                assert state['helper_alive_at_injection']
            if mode == 'already-exited':
                await_condition(lambda: self.poll() is not None, 'already-exited owned leader')
                assert self.returncode == 23
            state['reader_alive_at_injection'] = reader.is_alive()
            state['injected_at'] = time.monotonic()
            raise cancellation

    original_popen = module.subprocess.Popen
    try:
        module.subprocess.Popen = ObservedPopen
        try:
            module._run([sys.executable, '-c', LEADER, str(work), mode, HELPER],
                        work, os.environ.copy(), 10.0)
            raise AssertionError('Cancellation was swallowed')
        except KeyboardInterrupt as caught:
            state['original_exception_preserved'] = caught is cancellation
            state['cleanup_elapsed_s'] = time.monotonic() - state['injected_at']
            assert state['original_exception_preserved']
            assert state['cleanup_elapsed_s'] < 2.0, 'Cancellation waited on an owned retained pipe'
        state['leader_returncode_after_product'] = proc.poll()
        state['leader_alive_after_product'] = state['leader_returncode_after_product'] is None
        if mode == 'already-exited':
            assert state['leader_returncode_after_product'] == 23
        else:
            assert state['leader_alive_after_product'] is not expect_cleanup
        if helper_handle:
            state['helper_alive_after_product'] = kernel32.WaitForSingleObject(helper_handle, 0) == 258
            state['reader_alive_after_product'] = reader.is_alive()
            assert state['helper_alive_after_product']
            assert state['reader_alive_after_product']
        state['passed'] = True
    finally:
        module.subprocess.Popen = original_popen
        # Release only this receiver's helper and terminate only its own leader.
        (work / 'release').write_text('receiver cleanup\n')
        if proc and proc.poll() is None:
            state['observer_killed_owned_leader'] = True
            proc.kill()
            proc.wait(timeout=3.0)
        else:
            state['observer_killed_owned_leader'] = False
        if helper_handle:
            state['helper_exit_observed'] = kernel32.WaitForSingleObject(helper_handle, 5000) == 0
            kernel32.CloseHandle(helper_handle)
        if reader:
            reader.join(timeout=5.0)
            state['reader_joined_after_observer_release'] = not reader.is_alive()
            if not reader.is_alive() and proc.stdout:
                proc.stdout.close()
        state['communication'] = communication
        RECEIPT_DATA['cases'].append(state)
        persist()
    assert state.get('reader_joined_after_observer_release')
    assert state.get('helper_exit_observed', True)
    assert 'error' not in communication
    print(json.dumps(state), flush=True)


try:
    assert sys.platform == 'win32', 'Native Windows is required'
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    for label, expect_cleanup in [('baseline', False), ('candidate', True)]:
        module = load_source(label)
        finite = module._run([sys.executable, '-c', "print('finite native'); raise SystemExit(7)"],
                             ROOT, os.environ.copy(), 5.0)
        assert finite == (7, 'finite native\n', False), finite
        RECEIPT_DATA['cases'].append({'source': label, 'mode': 'finite', 'result': finite, 'passed': True})
        for mode in ('live-leader', 'retained-pipe', 'already-exited'):
            run_interrupt(module, label, mode, expect_cleanup)
    assert RECEIPT_DATA['candidate_sha256'] == '899a454dea73c988645b04cba887b13f7770b824b00f0c0f8be5c179903577e0'
    RECEIPT_DATA['passed'] = True
except BaseException as error:
    RECEIPT_DATA['passed'] = False
    RECEIPT_DATA['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    RECEIPT_DATA['finished_at'] = time.time()
    persist()
    print(json.dumps({'passed': RECEIPT_DATA.get('passed'), 'receipt': str(RECEIPT), 'cases': len(RECEIPT_DATA['cases'])}), flush=True)
