from pathlib import Path
Path(__file__).with_name("source_imported").write_text("unexpected")
raise RuntimeError("preview must not import the project")

def add(a, b):
    return a + b

class Arithmetic:
    @staticmethod
    def scale(value):
        return value * 3
