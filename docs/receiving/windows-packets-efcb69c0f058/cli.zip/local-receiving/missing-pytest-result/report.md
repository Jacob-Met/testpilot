# TestPilot report: **failed**

baseline pytest run did not produce a complete test report; fix the runner or project setup before generation

- Changed functions: calc.py::add
- Tests written: 0 in -
- Repair rounds used: 0/0
- Final run: 0 passed, 0 failed, 0 errors, 0 skipped (rc=1) in 0.011s
- Coverage: unavailable
- Tokens: 0; cost: $0.000000
