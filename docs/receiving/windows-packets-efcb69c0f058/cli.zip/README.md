# TestPilot combined branch: isolated Windows CLI receiving

This packet prepares a private virtual environment for the exact published
[combined source at a1fb8acc52a678d887548fe1606132c3a808009c](https://github.com/Jacob-Met/testpilot/tree/a1fb8acc52a678d887548fe1606132c3a808009c).
The published tree is `5cc89d6653b828bc9867f60931504296274e072f`.
Its source, the two original source offers, and the separately reviewed Windows
cancellation receiver remain unchanged.

The wheel build, isolated local install, and all five product CLI invocations
passed on Linux with Python 3.12.14 and pytest 9.1.1 at 2026-10-12 22:35:13 UTC.
Native Windows installation and this CLI course are pending the runtime owner's
device receiving. No Windows result is inferred from the local pass.

## Exact installation contract

The branch's [pyproject.toml](https://github.com/Jacob-Met/testpilot/blob/a1fb8acc52a678d887548fe1606132c3a808009c/pyproject.toml)
and the built wheel's metadata agree:

| Item | Declared value |
|---|---|
| Package | `testpilot==0.1.0` |
| Python | `>=3.12` |
| Runtime dependency | `pytest>=8` |
| Optional coverage extra | `coverage>=7` |
| Console entry point | `testpilot = testpilot.__main__:main` |
| Source build backend | `setuptools.build_meta`, declared `setuptools>=69` |

The source has one packaging caveat: its SPDX string `license = "Apache-2.0"`
uses support that the [current setuptools documentation](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)
dates to 77.0.0. The declared lower bound is wider than that documented support.
This packet's wheel was successfully built with the already installed
setuptools 84.0.0, using `pip wheel --no-index --no-deps --no-build-isolation`
against a fresh Git archive copy. No frozen checkout files were used for build
writes. Installing this wheel does not run the source build backend.

The wheel is `py3-none-any`; all twelve packaged Python source files match the
published source manifest exactly. Its pytest helper is included. Source identity
is established with the commit, tree and hashes, since `0.1.0` alone does not
identify this branch.

The offline wheelhouse contains pytest 9.1.1, iniconfig 2.3.1, packaging 26.3,
pluggy 1.6.0, Pygments 2.21.0 and colorama 0.4.6 alongside TestPilot. Pytest's wheel
metadata requires colorama on Windows; it was added explicitly because Linux
dependency resolution does not request that conditional dependency. All seven
wheel files have byte counts and SHA-256 hashes in `wheelhouse-manifest.json`.
Coverage is unnecessary for this receiving course.

## Receive into a new user-owned environment

Use the Windows broker route whose account, device and Python identity have
already been verified. Set the first two variables to that route's actual
received packet and Python executable. Keep the packet's `receive_cli.py`,
`source-manifest.json`, `wheelhouse-manifest.json` and `wheelhouse/` together.

The following uses normal Python virtual environments, pip's supported local
wheel installation, and explicit executable paths. It requires no environment
activation or PowerShell execution-policy change. See the official
[Python venv documentation](https://docs.python.org/3.12/library/venv.html) and
[pip installation documentation](https://pip.pypa.io/en/stable/topics/local-project-installs/).

```powershell
$TestPilotPacket = 'C:\path\to\received\windows-cli-readiness'
$TestPilotBasePython = 'C:\path\to\verified\python.exe'
$TestPilotStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$TestPilotRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) "HAMON\TestPilot-receiving\a1fb8acc-$TestPilotStamp"
if (Test-Path -LiteralPath $TestPilotRoot) { throw 'Receiving root already exists' }
New-Item -ItemType Directory -Path $TestPilotRoot -ErrorAction Stop | Out-Null

$TestPilotWheelManifest = Join-Path $TestPilotPacket 'wheelhouse-manifest.json'
if ((Get-FileHash -LiteralPath $TestPilotWheelManifest -Algorithm SHA256).Hash.ToLowerInvariant() -ne '8aaac6434d1eb82a8149c27421e2b04713af5227323c30c0cdb7c8fe2bb9d858') { throw 'Wheel manifest identity differs' }
$TestPilotWheelData = Get-Content -Raw -LiteralPath $TestPilotWheelManifest | ConvertFrom-Json
foreach ($TestPilotWheel in $TestPilotWheelData.wheels.psobject.Properties) {
    $TestPilotWheelPath = Join-Path (Join-Path $TestPilotPacket 'wheelhouse') $TestPilotWheel.Name
    if ((Get-Item -LiteralPath $TestPilotWheelPath).Length -ne $TestPilotWheel.Value.bytes) { throw 'Wheel size differs' }
    if ((Get-FileHash -LiteralPath $TestPilotWheelPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $TestPilotWheel.Value.sha256) { throw 'Wheel hash differs' }
}
$TestPilotReceiver = Join-Path $TestPilotPacket 'receive_cli.py'
if ((Get-FileHash -LiteralPath $TestPilotReceiver -Algorithm SHA256).Hash.ToLowerInvariant() -ne '3a58e97438150d984eb997977e0b14eab55b626b4f9bc77341482f1c54d5ce71') { throw 'Receiver identity differs' }

$TestPilotVenv = Join-Path $TestPilotRoot 'venv'
& $TestPilotBasePython -I -B -m venv $TestPilotVenv
if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed' }
$TestPilotPython = Join-Path $TestPilotVenv 'Scripts\python.exe'
& $TestPilotPython -m pip --isolated install --no-index --no-cache-dir --disable-pip-version-check --find-links (Join-Path $TestPilotPacket 'wheelhouse') 'testpilot==0.1.0'
if ($LASTEXITCODE -ne 0) { throw 'Offline installation failed' }
& $TestPilotPython -B $TestPilotReceiver --python $TestPilotPython --platform nt --out (Join-Path $TestPilotRoot 'course')
if ($LASTEXITCODE -ne 0) { throw 'Read the retained receiving receipt before continuing' }
```

The receiver checks the installed distribution's metadata, isolated environment
and every source file before it invokes `Scripts\testpilot.exe`. It also runs
`pip check`. The source-manifest hash is fixed inside the receiver. All paths
passed to product processes are argument-list elements; the authored project and
input paths deliberately contain spaces. One source filename is `café.py`.

The packet is not an environment image: create the virtual environment on the
destination machine. Python documents that virtual environments are not movable.
This procedure only creates the new receiving environment and its owned fixture
and result directories. It performs no Git write, workflow dispatch, service
installation, default-branch change or system Python installation.

## Five product CLI controls

| Invocation | Authored expectation |
|---|---|
| Installed console `targets`, saved CRLF diff | Two exact ordered whole-function records, including decorated method boundaries and source |
| Installed console `targets`, LF stdin diff | Byte-identical stdout to saved-file preview |
| Installed interpreter `-I -B -m testpilot targets` | Same records and stdout, with no source checkout on `PYTHONPATH` |
| Installed console `run`, separate no-pytest interpreter | Exit 1; original missing-pytest diagnostics; empty ledger, test files, rounds and patch; four saved outputs |
| Installed console `recheck`, prepared interpreter | Real pytest: one existing and one retained case pass; retained-case attribution; saved input's historical failure preserved; zero model calls |

The target preview source raises if imported, and its pytest configuration raises
if collected. The preview backend environment is deliberately invalid, so a
successful preview cannot depend on constructing that backend. The failed run
explicitly selects the scripted backend and stops at baseline admission, before
any response is consumed. The recheck command uses one small authored retained
test rather than model generation. Its prior report says `failed`; the current
passing result is established by actual execution.

Every fixture file's bytes and mtime are compared after its course. The original
project never receives the retained test file. Installed package bytes and
metadata are read again at the end. Per-process stdout, stderr, return codes,
arguments and hashes are retained in the fresh output directory along with
`receipt.json`; the product's own reports stay there too.

This is five focused product CLI invocations, not a maintained-suite replay or
timing benchmark. The subprocess environment explicitly uses UTF-8; other
console encodings are outside this receipt. It does not inject interruption,
broadcast Ctrl-C or establish a process-tree cleanup contract. The separate
Windows receiver at SHA-256
`84555629146d016784a6b857dc476a93ee1b2cbd99b170f5ecb06bf4359eaab9`
retains that lane's independently reviewed scope and native evidence.

## Evidence identities

| Artifact | SHA-256 |
|---|---|
| TestPilot wheel, 63,256 bytes | `35071ae562ff8b17150aaffb03af5d77f9c86c690c95d0468a031ba72997b2b4` |
| Receiver, 15,968 bytes | `3a58e97438150d984eb997977e0b14eab55b626b4f9bc77341482f1c54d5ce71` |
| Source manifest | `e4c17e4e6d60c91b443a7feccc2d2a4c6722363dd1f7e6ec741acf81f09c5d36` |
| Seven-wheel manifest | `8aaac6434d1eb82a8149c27421e2b04713af5227323c30c0cdb7c8fe2bb9d858` |
| Local installed receiving receipt | `00b8dc327a6d1f81d5904a2fb271ddae32d3a3a871ac309f262f35cc662de081` |

Build and install receipts record their actual commands. Dependency acquisition
used ordinary downloads from PyPI; build and local installation subsequently
used `--no-index`. Local receiving accepted the original frozen expectations on
the first run; no receiver or expected result was adjusted after observing it.

The independent context/adoption worker accepted the frozen receiver and source
manifest by read-only contract review. Its exact receipt is retained as
`independent-contract-review.json`, SHA-256
`b2b534ec2e683a04d2814b9f9826f89d5671b2d5ec5ff0b6cc94e0ffbc9857d3`.
All twelve source files and pyproject were joined to local commit 65b537bc,
whose tree is the exact published 5cc89d66 tree. That review neither reran the
local course nor claimed a Windows result.
