"""Receive the exact installed TestPilot branch in a fresh owned directory.

Standard library controller; no source injection, Git commands, provider calls,
activation, global installation, console signals, or device discovery. Invoke
with a prepared virtual environment's Python and an absent --out directory.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


MANIFEST_SHA256 = "e4c17e4e6d60c91b443a7feccc2d2a4c6722363dd1f7e6ec741acf81f09c5d36"
PREVIEW_SOURCE = (
    "from pathlib import Path\n"
    'Path(__file__).with_name("source_imported").write_text("unexpected")\n'
    'raise RuntimeError("preview must not import the project")\n\n'
    "def add(a, b):\n    return a + b\n\n"
    "class Arithmetic:\n    @staticmethod\n"
    "    def scale(value):\n        return value * 3\n"
)
PREVIEW_DIFF = (
    "diff --git a/src/caf\u00e9.py b/src/caf\u00e9.py\n"
    "--- a/src/caf\u00e9.py\n+++ b/src/caf\u00e9.py\n"
    "@@ -5,7 +5,7 @@\n def add(a, b):\n"
    "-    return a - b\n+    return a + b\n \n"
    " class Arithmetic:\n     @staticmethod\n"
    "     def scale(value):\n-        return value * 2\n"
    "+        return value * 3\n"
)
# Authored whole-record expectations, frozen before executing this receiver.
EXPECTED_TARGETS = {"changed_functions": [
    {"path": "src/caf\u00e9.py", "module": "caf\u00e9", "qualname": "add",
     "lineno": 5, "end_lineno": 6, "changed_lines": [6],
     "source": "def add(a, b):\n    return a + b", "is_method": False},
    {"path": "src/caf\u00e9.py", "module": "caf\u00e9", "qualname": "Arithmetic.scale",
     "lineno": 9, "end_lineno": 11, "changed_lines": [11],
     "source": "    @staticmethod\n    def scale(value):\n        return value * 3",
     "is_method": True},
]}
PROJECT_SOURCE = "def add(a, b):\n    return a + b\n"
PROJECT_DIFF = (
    "--- a/calc.py\n+++ b/calc.py\n@@ -1,2 +1,2 @@\n"
    " def add(a, b):\n-    return a - b\n+    return a + b\n"
)
EXISTING_TEST = "from calc import add\n\ndef test_zero():\n    assert add(0, 0) == 0\n"
RETAINED_TEST = (
    "from calc import add\n\ndef test_add():\n"
    "    assert add(2, 3) == 5\n    assert add(-3, 2) == -1\n"
)
INSPECT = r'''
import hashlib, importlib.metadata as m, json, os, pathlib, sys
import testpilot
d=m.distribution("testpilot")
root=pathlib.Path(testpilot.__file__).resolve().parent
prefix=pathlib.Path(sys.prefix).resolve()
files={"testpilot/"+p.relative_to(root).as_posix():
       {"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
       for p in sorted(root.rglob("*.py"))}
print(json.dumps({"platform":os.name,"python":sys.version.split()[0],
 "python_version":list(sys.version_info[:3]),"executable":sys.executable,
 "prefix":str(prefix),"base_prefix":str(pathlib.Path(sys.base_prefix).resolve()),
 "package_root":str(root),"package_under_prefix":root.is_relative_to(prefix),
 "source_files":files,"version":d.version,
 "requires_python":d.metadata.get("Requires-Python"),
 "requires_dist":sorted(d.metadata.get_all("Requires-Dist") or []),
 "entry_points":[[e.name,e.value] for e in d.entry_points if e.group=="console_scripts"],
 "pytest_version":m.version("pytest")}))
'''


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(value: object, message: str) -> None:
    if not value:
        raise RuntimeError(message)


def inventory(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): {
        "bytes": p.stat().st_size, "sha256": digest(p.read_bytes()),
        "mtime_ns": p.stat().st_mtime_ns,
    } for p in sorted(root.rglob("*")) if p.is_file()}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--python", required=True, help="prepared venv Python; use an absolute path")
    ap.add_argument("--out", required=True, help="absent owned receiving directory")
    ap.add_argument("--platform", choices=("nt", "posix"), default="nt")
    args = ap.parse_args()
    supplied = Path(args.python).expanduser().absolute()
    # Preserve the executable's final symlink, hence its virtual environment.
    python = supplied.parent.resolve() / supplied.name
    launcher = python.parent / ("testpilot.exe" if args.platform == "nt" else "testpilot")
    require(python.is_file() and launcher.is_file(), "prepared Python or installed launcher is missing")
    manifest_bytes = Path(__file__).with_name("source-manifest.json").read_bytes()
    require(digest(manifest_bytes) == MANIFEST_SHA256, "source manifest identity differs")
    manifest = json.loads(manifest_bytes)
    out = Path(args.out).expanduser().absolute()
    out.mkdir(exist_ok=False)
    (out / "processes").mkdir()
    # Keep only ordinary process-launch variables. Do not inherit credentials,
    # PYTHONPATH, backend routing, pytest injection, or the user's Python site.
    wanted = {"PATH", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "TEMP", "TMP", "LANG", "LC_ALL"}
    env = {k: v for k, v in os.environ.items() if k.upper() in wanted}
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1",
               PYTHONIOENCODING="utf-8", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
               TESTPILOT_BACKEND="receiver-must-not-construct-a-provider")
    receipt = {"started_at": datetime.now(timezone.utc).isoformat(),
               "receiver_sha256": digest(Path(__file__).read_bytes()),
               "published_commit": manifest["published_commit"],
               "published_tree": manifest["published_tree"],
               "expected_platform": args.platform, "commands": [], "checks": []}

    def run(name: str, command: list[str | Path], *, data: bytes | None = None) -> subprocess.CompletedProcess:
        argv = [str(x) for x in command]
        r = subprocess.run(argv, cwd=out, env=env, input=data,
                           capture_output=True, timeout=30)
        (out / "processes" / (name + ".stdout")).write_bytes(r.stdout)
        (out / "processes" / (name + ".stderr")).write_bytes(r.stderr)
        receipt["commands"].append({"name": name, "argv": argv, "returncode": r.returncode,
                                    "stdout_sha256": digest(r.stdout), "stderr_sha256": digest(r.stderr),
                                    "stdin_sha256": digest(data) if data is not None else None})
        return r

    def inspect(name: str) -> dict:
        r = run(name, [python, "-I", "-B", "-c", INSPECT])
        require(r.returncode == 0 and not r.stderr, "installed package inspection failed")
        result = json.loads(r.stdout)
        require(result["platform"] == args.platform, "platform identity differs")
        require(result["python_version"] >= [3, 12, 0], "Python is older than the package requirement")
        require(result["prefix"] != result["base_prefix"] and result["package_under_prefix"],
                "package is not installed inside the selected isolated venv")
        require(result["source_files"] == manifest["source_files"], "installed package bytes differ")
        require(result["version"] == "0.1.0" and result["requires_python"] == ">=3.12",
                "installed package identity or Python metadata differs")
        require(result["requires_dist"] == ['coverage>=7; extra == "coverage"', "pytest>=8"],
                "installed dependency metadata differs")
        require(result["entry_points"] == [["testpilot", "testpilot.__main__:main"]],
                "installed entry-point metadata differs")
        return result

    try:
        receipt["installed_before"] = inspect("installed-before")
        r = run("dependency-check", [python, "-I", "-B", "-m", "pip", "check"])
        require(r.returncode == 0, "installed dependency check failed")
        receipt["checks"].append("isolated installed package, all twelve source files, entry point and dependencies")
        fixtures = out / "fixtures with spaces"
        fixtures.mkdir()
        preview = fixtures / "preview project"
        (preview / "src").mkdir(parents=True)
        (preview / "src" / "caf\u00e9.py").write_bytes(PREVIEW_SOURCE.encode())
        (preview / "conftest.py").write_bytes(b'raise RuntimeError("preview must not start pytest")\n')
        crlf_diff = fixtures / "preview change.diff"
        crlf_diff.write_bytes(PREVIEW_DIFF.replace("\n", "\r\n").encode())
        original_preview = inventory(preview)
        preview_outputs = []
        for name, prefix, diff_args, data in (
            ("console-saved-targets", [launcher], ["--diff", crlf_diff], None),
            ("console-stdin-targets", [launcher], ["--diff", "-"], PREVIEW_DIFF.encode()),
            ("module-saved-targets", [python, "-I", "-B", "-m", "testpilot"], ["--diff", crlf_diff], None),
        ):
            r = run(name, [*prefix, "targets", "--repo", preview, *diff_args, "--json"], data=data)
            require(r.returncode == 0 and not r.stderr, name + " failed")
            require(json.loads(r.stdout) == EXPECTED_TARGETS, name + " differs from frozen whole records")
            preview_outputs.append(r.stdout)
        require(len(set(preview_outputs)) == 1, "saved/stdin/module output bytes differ on this platform")
        require(inventory(preview) == original_preview, "preview modified its source fixture")
        receipt["checks"].append("three real CLI previews: exact ordered records, Unicode filename, CRLF/LF inputs, unchanged bytes and mtimes")

        project = fixtures / "run project"
        (project / "tests").mkdir(parents=True)
        (project / "calc.py").write_bytes(PROJECT_SOURCE.encode())
        (project / "tests" / "test_existing.py").write_bytes(EXISTING_TEST.encode())
        change = fixtures / "run change.diff"
        change.write_bytes(PROJECT_DIFF.encode())
        script = fixtures / "unused responses"
        script.mkdir()
        (script / "01.md").write_bytes(b"Unused response: no generation call is permitted.\n")
        original_inputs = inventory(fixtures)
        no_pytest_env = out / "python without pytest"
        r = run("create-missing-pytest-environment", [python, "-I", "-B", "-m", "venv", "--without-pip", no_pytest_env])
        require(r.returncode == 0, "negative-control venv creation failed")
        no_pytest = no_pytest_env / ("Scripts/python.exe" if args.platform == "nt" else "bin/python")
        failed_out = out / "missing-pytest-result"
        r = run("console-missing-pytest", [launcher, "run", "--repo", project, "--diff", change,
                "--backend", "scripted", "--script", script, "--python", no_pytest,
                "--no-coverage", "--rounds", "0", "--timeout", "5", "--out", failed_out])
        require(r.returncode == 1 and not r.stderr, "missing-pytest CLI did not return a controlled failed result")
        failure = json.loads((failed_out / "report.json").read_bytes())
        require(failure["status"] == "failed" and "complete test report" in failure["message"],
                "missing-pytest admission diagnosis differs")
        require(failure["ledger"]["entries"] == [] and failure["ledger"]["total_tokens"] == 0,
                "missing-pytest control consumed a model call")
        require(failure["test_files"] == {} and failure["rounds"] == [], "missing-pytest control generated tests")
        require(failure["final"]["returncode"] == 1 and not failure["final"]["junit_available"]
                and not failure["final"]["timed_out"] and "No module named pytest" in failure["final"]["output"],
                "original missing-pytest runner diagnostics were not retained")
        require((failed_out / "testpilot.patch").read_bytes() == b"", "negative control emitted a patch")
        require({p.name for p in failed_out.iterdir()} == {"report.json", "report.md", "report.html", "testpilot.patch"},
                "negative-control saved outputs differ")
        require(inventory(fixtures) == original_inputs, "negative control modified its input fixture")
        receipt["checks"].append("installed run CLI: selected interpreter without pytest, exit one, original diagnostics, zero calls, empty patch")

        retained = fixtures / "authored saved report.json"
        retained.write_bytes((json.dumps({"status": "failed", "test_files": {"tests/test_add.py": RETAINED_TEST}}, indent=2) + "\n").encode())
        before_recheck = inventory(fixtures)
        recheck_out = out / "retained-test-result"
        r = run("console-retained-recheck", [launcher, "recheck", "--repo", project,
                "--report", retained, "--python", python, "--timeout", "5", "--out", recheck_out])
        require(r.returncode == 0 and not r.stderr, "installed retained-test CLI failed")
        result = json.loads((recheck_out / "recheck.json").read_bytes())
        require(result["schema"] == "testpilot.recheck/1" and result["status"] == "passed" and result["ok"],
                "retained-test current result did not pass")
        require(result["model_calls"] == 0, "retained-test control recorded model calls")
        require(result["source_report"]["sha256"] == digest(retained.read_bytes())
                and result["source_report"]["recorded_status"] == "failed", "saved-report identity was not retained")
        require(result["test_files"] == {"tests/test_add.py": RETAINED_TEST}, "retained test bytes differ")
        require(result["retained_tests"] == [{"path": "tests/test_add.py", "bytes": len(RETAINED_TEST.encode()),
                "sha256": digest(RETAINED_TEST.encode()), "placement": "temporary"}], "retained placement differs")
        final = result["final"]
        require(final["junit_available"] and not final["timed_out"] and final["returncode"] == 0
                and final["passed"] == 2 and final["failed"] == 0 and final["errors"] == 0,
                "real pytest did not receive both the existing and retained cases")
        require(final["generated"] == {"collected": 1, "passed": 1, "failed": 0, "error": 0, "skipped": 0},
                "retained generated-case attribution differs")
        require({p.name for p in recheck_out.iterdir()} == {"recheck.json", "recheck.md", "recheck.html"},
                "retained-test saved outputs differ")
        require(inventory(fixtures) == before_recheck, "recheck modified original project or saved inputs")
        receipt["checks"].append("installed recheck CLI: real pytest, existing plus retained pass, exact temporary retained bytes, zero calls, unchanged inputs")
        receipt["installed_after"] = inspect("installed-after")
        require(receipt["installed_before"] == receipt["installed_after"], "installed source identity changed during receiving")
        receipt["accepted"] = True
    except Exception as exc:
        receipt["accepted"] = False
        receipt["error"] = type(exc).__name__ + ": " + str(exc)
    receipt["finished_at"] = datetime.now(timezone.utc).isoformat()
    receipt["limits"] = [
        "This is a package/CLI receiving course on the recorded platform, not a full suite or performance study.",
        "Five product CLI invocations; scripted run stops before any generation, recheck uses only authored saved tests.",
        "No provider request, Git command, workflow execution, console interruption, process-tree claim or installed service change.",
        "UTF-8 process environment is explicit; this course does not qualify every native console encoding.",
        "The separate reviewed Windows cancellation receiver and its native qualification retain their own identities.",
    ]
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"accepted": receipt["accepted"], "checks": len(receipt["checks"]),
                      "receipt": str(out / "receipt.json"), "error": receipt.get("error")}))
    return 0 if receipt["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
