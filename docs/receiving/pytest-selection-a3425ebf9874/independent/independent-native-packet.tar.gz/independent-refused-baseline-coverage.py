#!/usr/bin/env python3
"""A refused single pytest baseline must not become a coverage comparison."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys
import traceback
from datetime import datetime, timezone

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(root):
    return {str(p.relative_to(root)):sha(p.read_bytes()) for p in sorted(root.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts and ".git" not in p.parts}

parser=argparse.ArgumentParser()
parser.add_argument("--source",type=pathlib.Path,required=True)
parser.add_argument("--out",type=pathlib.Path,required=True)
parser.add_argument("--python",required=True)
args=parser.parse_args()
args.out.mkdir(parents=True,exist_ok=False)
before=snapshot(args.source/"testpilot")
project=args.out/"project"
(project/"tests").mkdir(parents=True)
(project/"subject.py").write_text("def twice(value):\n    return value * 2\n")
(project/"tests/test_plain.py").write_text(
    "from subject import twice\n\ndef test_plain():\n    assert twice(3) == 6\n")
audit=args.out/"actual-pytest-sessions.jsonl"
hook="""import json
from pathlib import Path
from subject import twice
assert twice(7) == 14
AUDIT=Path(__AUDIT__)
def note(data):
    with AUDIT.open("a",encoding="utf-8") as stream:
        stream.write(json.dumps(data)+"\\n")
def pytest_sessionstart(session):
    note({"event":"start","keyword":session.config.getoption("-k")})
def pytest_sessionfinish(session,exitstatus):
    note({"event":"finish","exitstatus":int(exitstatus)})
"""
(project/"conftest.py").write_text(hook.replace("__AUDIT__",repr(str(audit))))
project_before=snapshot(project)
diff=args.out/"change.diff"
diff.write_text("--- a/subject.py\n+++ b/subject.py\n@@ -1,2 +1,2 @@\n"
                " def twice(value):\n-    return value + value\n+    return value * 2\n")
script=args.out/"script"
script.mkdir()
(script/"01-plan.txt").write_text("This response must never be requested.")
result_dir=args.out/"result"
command=[args.python,"-m","testpilot","run","--repo",str(project),"--diff",str(diff),
         "--backend","scripted","--script",str(script),"--out",str(result_dir),
         "--rounds","0","--timeout","30","--python",args.python,"--pytest-k","("]
env={"PATH":"/usr/bin:/bin","PYTHONIOENCODING":"utf-8","PYTHONDONTWRITEBYTECODE":"1",
     "PYTEST_DISABLE_PLUGIN_AUTOLOAD":"1"}
receipt={"schema":"testpilot.independent-refused-baseline-coverage/1",
         "started_at":datetime.now(timezone.utc).isoformat(),"source":str(args.source),
         "control_sha256":sha(pathlib.Path(__file__).read_bytes()),
         "source_before":before,"command":command,"checks":{}}
try:
    run=subprocess.run(command,cwd=args.source,env=env,stdin=subprocess.DEVNULL,
                       capture_output=True,timeout=120)
    (args.out/"stdout.txt").write_bytes(run.stdout)
    (args.out/"stderr.txt").write_bytes(run.stderr)
    data=json.loads((result_dir/"report.json").read_bytes())
    events=[json.loads(line) for line in audit.read_text().splitlines()]
    native=data["final"]
    checks=receipt["checks"]
    checks["failed_native_usage"]=run.returncode==1 and data["status"]=="failed" and native["returncode"]==4
    checks["single_pytest_execution"]=sum(e["event"]=="start" for e in events)==1 and sum(e["event"]=="finish" for e in events)==1
    checks["no_model_or_generated_execution"]=not data["ledger"]["entries"] and not data["rounds"] and not data["test_files"] and not data["patch"]
    checks["actual_final_coverage_retained"]=native["coverage"] is not None and native["coverage"]["percent_total"]==100
    checks["no_before_after_comparison"]=data["coverage"] is None
    checks["project_unchanged"]=snapshot(project)==project_before
    receipt["observed"]={"returncode":run.returncode,"status":data["status"],
                        "native_returncode":native["returncode"],
                        "native_coverage":native["coverage"],"coverage_comparison":data["coverage"],
                        "model_calls":len(data["ledger"]["entries"]),"rounds":len(data["rounds"]),
                        "pytest_events":events}
except Exception as exc:
    receipt["error"]={"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
after=snapshot(args.source/"testpilot")
receipt["source_after"]=after
receipt["checks"]["source_unchanged"]=after==before
receipt["status"]="PASS" if not receipt.get("error") and all(receipt["checks"].values()) else "FAIL"
receipt["completed_at"]=datetime.now(timezone.utc).isoformat()
raw=(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n").encode()
(args.out/"receipt.json").write_bytes(raw)
print(json.dumps({"status":receipt["status"],"checks":receipt["checks"],
                  "receipt_sha256":sha(raw),"observed":receipt.get("observed"),
                  "error":receipt.get("error")}),flush=True)
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
