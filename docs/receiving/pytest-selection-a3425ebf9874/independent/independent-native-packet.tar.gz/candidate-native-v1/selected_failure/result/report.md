# TestPilot report: **failed**

still failing after 0 repair round(s): 1 passed, 1 failed, 0 errors, 0 skipped (rc=1); generated: 0 passed of 1 collected

- Changed functions: subject.py::twice
- Tests written: 1 in tests/test_receiver_generated.py
- Repair rounds used: 0/0
- Final run: 1 passed, 1 failed, 0 errors, 0 skipped (rc=1); generated: 0 passed of 1 collected in 1.729s
- Coverage: unavailable
- Tokens: 436 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 160 in / 11 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 223 in / 42 out

## Pytest execution selection

These native filters are configured for baseline, generation and every repair. Unselected tests were not verified. Saved-test recheck does not inherit these filters.

```json
{
  "keyword": "focus",
  "marker": null
}
```

## Patch

```diff
diff --git a/tests/test_receiver_generated.py b/tests/test_receiver_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_receiver_generated.py
@@ -0,0 +1,6 @@
+import pytest
+from subject import twice
+@pytest.mark.fast
+def test_focus_generated():
+    assert twice(4) == 999
+
```
