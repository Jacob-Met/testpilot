# TestPilot report: **no_tests**

no generated test case passed; existing-suite passes do not qualify the generated patch: 1 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 0 passed of 0 collected

- Changed functions: subject.py::twice
- Tests written: 0 in tests/test_receiver_generated.py
- Repair rounds used: 0/0
- Final run: 1 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 0 passed of 0 collected in 1.022s
- Coverage: unavailable
- Tokens: 437 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 160 in / 11 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 223 in / 43 out

## Pytest execution selection

These native filters are configured for baseline, generation and every repair. Unselected tests were not verified. Saved-test recheck does not inherit these filters.

```json
{
  "keyword": "focus",
  "marker": null
}
```

## Patch

```diff
diff --git a/tests/test_receiver_generated.py b/tests/test_receiver_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_receiver_generated.py
@@ -0,0 +1,6 @@
+import pytest
+from subject import twice
+@pytest.mark.fast
+def test_unselected_generated():
+    assert twice(4) == 8
+
```
