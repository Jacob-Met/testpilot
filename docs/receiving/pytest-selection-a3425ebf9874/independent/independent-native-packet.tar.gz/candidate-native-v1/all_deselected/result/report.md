# TestPilot report: **no_tests**

no generated test case passed; existing-suite passes do not qualify the generated patch: 0 passed, 0 failed, 0 errors, 0 skipped (rc=5); generated: 0 passed of 0 collected

- Changed functions: subject.py::twice
- Tests written: 0 in tests/test_receiver_generated.py
- Repair rounds used: 0/0
- Final run: 0 passed, 0 failed, 0 errors, 0 skipped (rc=5); generated: 0 passed of 0 collected in 4.041s
- Coverage: unavailable
- Tokens: 467 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 167 in / 11 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 229 in / 60 out

## Pytest execution selection

These native filters are configured for baseline, generation and every repair. Unselected tests were not verified. Saved-test recheck does not inherit these filters.

```json
{
  "keyword": "no_case_has_this_receiver_name",
  "marker": null
}
```

## Patch

```diff
diff --git a/tests/test_receiver_generated.py b/tests/test_receiver_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_receiver_generated.py
@@ -0,0 +1,10 @@
+import pytest
+from subject import twice
+@pytest.mark.fast
+def test_focus_generated():
+    assert twice(4) == 8
+
+@pytest.mark.slow
+def test_outside_generated():
+    assert twice(4) == 999
+
```
