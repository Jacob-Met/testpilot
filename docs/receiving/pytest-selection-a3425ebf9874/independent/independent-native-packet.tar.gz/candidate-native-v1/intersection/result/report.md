# TestPilot report: **passed**

- Changed functions: subject.py::twice
- Tests written: 1 in tests/test_receiver_generated.py
- Repair rounds used: 0/0
- Final run: 2 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 1 passed of 1 collected in 3.279s
- Coverage: unavailable
- Tokens: 479 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 161 in / 11 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 224 in / 83 out

## Pytest execution selection

These native filters are configured for baseline, generation and every repair. Unselected tests were not verified. Saved-test recheck does not inherit these filters.

```json
{
  "keyword": "focus",
  "marker": "fast"
}
```

## Patch

```diff
diff --git a/tests/test_receiver_generated.py b/tests/test_receiver_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_receiver_generated.py
@@ -0,0 +1,14 @@
+import pytest
+from subject import twice
+@pytest.mark.fast
+def test_focus_fast_generated():
+    assert twice(4) == 8
+
+@pytest.mark.slow
+def test_focus_slow_generated():
+    assert twice(4) == 999
+
+@pytest.mark.fast
+def test_outside_fast_generated():
+    assert twice(4) == 999
+
```
