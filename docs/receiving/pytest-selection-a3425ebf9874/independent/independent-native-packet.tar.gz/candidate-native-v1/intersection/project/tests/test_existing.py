import pytest
from subject import twice
@pytest.mark.fast
def test_focus_fast_existing():
    assert twice(4) == 8

@pytest.mark.slow
def test_focus_slow_existing():
    assert twice(4) == 999

@pytest.mark.fast
def test_outside_fast_existing():
    assert twice(4) == 999

