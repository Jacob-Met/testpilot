# TestPilot recheck: **failed**

- Current run: 2 passed, 2 failed, 0 errors, 0 skipped (rc=1); generated: 1 passed of 2 collected
- Retained test files: 1
- Project Python: "/srv/hamon-estate/receivers/estate-a3425ebf9874-testpilot-pytest-selection/venv/bin/python"
- New model calls: 0
- Source report SHA-256: eaa3036e762ac92f23e666e479a159bc68130f022edd7c11bcdf2534f3e9f8e9

This result reruns the saved tests against the current checkout. It does not
reaffirm the original model diagnosis or compare historical coverage.
The source report and repository are not written by the recheck command.

## Retained files

- "tests/test_receiver_generated.py": temporary; SHA-256 21457b1fb3140624dbacdc02e46c2e7d99c5e6eea9a16eef338c58ddb78eb77e
