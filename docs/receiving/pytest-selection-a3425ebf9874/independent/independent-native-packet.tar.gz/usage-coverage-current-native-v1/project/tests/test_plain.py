from subject import twice

def test_plain():
    assert twice(3) == 6
