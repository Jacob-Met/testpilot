import json
from pathlib import Path
from subject import twice
assert twice(7) == 14
AUDIT=Path('/srv/hamon-estate/receivers/estate-a3425ebf9874-testpilot-pytest-selection-root-review/usage-coverage-current-native-v1/actual-pytest-sessions.jsonl')
def note(data):
    with AUDIT.open("a",encoding="utf-8") as stream:
        stream.write(json.dumps(data)+"\n")
def pytest_sessionstart(session):
    note({"event":"start","keyword":session.config.getoption("-k")})
def pytest_sessionfinish(session,exitstatus):
    note({"event":"finish","exitstatus":int(exitstatus)})
