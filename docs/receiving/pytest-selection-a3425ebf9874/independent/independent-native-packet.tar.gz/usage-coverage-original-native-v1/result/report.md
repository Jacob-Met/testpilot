# TestPilot report: **failed**

pytest refused the selected baseline run; inspect its diagnostics

- Changed functions: subject.py::twice
- Tests written: 0 in -
- Repair rounds used: 0/0
- Final run: 0 passed, 0 failed, 0 errors, 0 skipped (rc=4) in 2.066s
- Coverage (total): 100.0% -> 100.0% (+0.0 pts)
- Coverage (changed lines, n=1): 100.0% -> 100.0%
- Tokens: 0; cost: $0.000000

## Pytest execution selection

These native filters are configured for baseline, generation and every repair. Unselected tests were not verified. Saved-test recheck does not inherit these filters.

```json
{
  "keyword": "(",
  "marker": null
}
```
