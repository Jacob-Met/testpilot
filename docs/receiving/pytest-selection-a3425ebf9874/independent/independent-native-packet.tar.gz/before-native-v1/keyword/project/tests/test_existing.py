import pytest
from subject import twice
@pytest.mark.fast
def test_focus_existing():
    assert twice(4) == 8

@pytest.mark.slow
def test_outside_existing():
    assert twice(4) == 999

