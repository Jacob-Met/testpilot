import json
from pathlib import Path
AUDIT = Path('/srv/hamon-estate/receivers/estate-a3425ebf9874-testpilot-pytest-selection-root-review/before-native-v1/default/pytest-observations.jsonl')
def note(value):
    with AUDIT.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + "\n")
def pytest_sessionstart(session):
    note({"event":"start", "keyword":session.config.getoption("-k"),
          "marker":session.config.getoption("-m"),
          "generated_present":(session.config.rootpath / "tests/test_receiver_generated.py").is_file()})
def pytest_runtest_logreport(report):
    if report.when == "call":
        note({"event":"call", "nodeid":report.nodeid, "outcome":report.outcome})
def pytest_sessionfinish(session, exitstatus):
    note({"event":"finish", "exitstatus":int(exitstatus),
          "items":[item.nodeid for item in session.items]})
