import pytest
from subject import twice
@pytest.mark.fast
def test_existing():
    assert twice(4) == 8

