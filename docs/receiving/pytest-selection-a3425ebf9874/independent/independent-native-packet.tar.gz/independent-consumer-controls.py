#!/usr/bin/env python3
"""Independent native consumer controls for TestPilot pytest selection.

Written from public baseline interfaces and the declared contract, before
receiving selector implementation. Projects and model replies are synthetic.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import pathlib
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from html.parser import HTMLParser

def stamp():
    return datetime.now(timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(root):
    return {str(p.relative_to(root)): sha(p.read_bytes())
            for p in sorted(root.rglob("*")) if p.is_file()
            and "__pycache__" not in p.parts and ".git" not in p.parts}

class ReadingHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text = []
        self.downloads = {}
        self.active_tags = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and "download" in attrs:
            self.downloads[attrs["download"]] = attrs.get("href", "")
        if tag in ("script", "iframe", "object", "embed", "img"):
            self.active_tags.append(tag)
    def handle_data(self, data):
        self.text.append(data)

def cases_source(rows):
    chunks = ["import pytest\nfrom subject import twice\n"]
    for name, marker, good in rows:
        if marker:
            chunks.append("@pytest.mark." + marker + "\n")
        chunks.append("def " + name + "():\n    assert twice(4) == " +
                      ("8" if good else "999") + "\n\n")
    return "".join(chunks)

FOCUS_EXISTING = [("test_focus_existing", "fast", True),
                  ("test_outside_existing", "slow", False)]
FOCUS_GENERATED = [("test_focus_generated", "fast", True),
                   ("test_outside_generated", "slow", False)]

class Receiver:
    def __init__(self, source, out, python):
        self.source = source.resolve()
        self.out = out.resolve()
        self.python = str(python)
        self.out.mkdir(parents=True, exist_ok=False)
        self.env = {"PATH": "/usr/bin:/bin", "PYTHONIOENCODING": "utf-8",
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1"}
        self.before = snapshot(self.source / "testpilot")
        self.records = []
        self.saved = {}

    def fixture(self, name, existing, generated, repair=None):
        root = self.out / name
        repo = root / "project"
        (repo / "tests").mkdir(parents=True)
        (repo / "subject.py").write_text("def twice(value):\n    return value * 2\n")
        (repo / "tests" / "test_existing.py").write_text(cases_source(existing))
        (repo / "pytest.ini").write_text(
            "[pytest]\nmarkers =\n    fast: receiver marker\n    slow: receiver marker\n")
        audit = root / "pytest-observations.jsonl"
        hook = """import json
from pathlib import Path
AUDIT = Path(__AUDIT__)
def note(value):
    with AUDIT.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + "\\n")
def pytest_sessionstart(session):
    note({"event":"start", "keyword":session.config.getoption("-k"),
          "marker":session.config.getoption("-m"),
          "generated_present":(session.config.rootpath / "tests/test_receiver_generated.py").is_file()})
def pytest_runtest_logreport(report):
    if report.when == "call":
        note({"event":"call", "nodeid":report.nodeid, "outcome":report.outcome})
def pytest_sessionfinish(session, exitstatus):
    note({"event":"finish", "exitstatus":int(exitstatus),
          "items":[item.nodeid for item in session.items]})
"""
        (repo / "conftest.py").write_text(hook.replace("__AUDIT__", repr(str(audit))))
        diff = root / "change.diff"
        diff.write_text("--- a/subject.py\n+++ b/subject.py\n@@ -1,2 +1,2 @@\n"
                        " def twice(value):\n-    return value + value\n+    return value * 2\n")
        script = root / "script"
        script.mkdir()
        (script / "01-plan.txt").write_text("Check twice with the requested pytest scope.")
        (script / "02-generate.txt").write_text(self.reply(generated))
        if repair is not None:
            (script / "03-repair.txt").write_text(self.reply(repair))
        return {"root":root, "repo":repo, "audit":audit, "script":script,
                "diff":diff, "before":snapshot(repo), "report_dir":root / "result"}

    @staticmethod
    def reply(rows):
        fence = chr(96) * 3
        return fence + "python path=tests/test_receiver_generated.py\n" + cases_source(rows) + fence + "\n"

    def command(self, fx, args, label="run"):
        command = [self.python, "-m", "testpilot"] + args
        completed = subprocess.run(command, cwd=self.source, env=self.env,
                                   stdin=subprocess.DEVNULL, capture_output=True, timeout=180)
        (fx["root"] / (label + ".stdout")).write_bytes(completed.stdout)
        (fx["root"] / (label + ".stderr")).write_bytes(completed.stderr)
        record = {"command":command, "returncode":completed.returncode,
                  "stdout_sha256":sha(completed.stdout), "stderr_sha256":sha(completed.stderr)}
        (fx["root"] / (label + ".command.json")).write_text(json.dumps(record, indent=2) + "\n")
        assert snapshot(fx["repo"]) == fx["before"], "consumer project changed"
        return completed

    def run(self, fx, keyword=None, marker=None, repairs=0):
        args = ["run", "--repo",str(fx["repo"]), "--diff",str(fx["diff"]),
                "--backend","scripted", "--script",str(fx["script"]),
                "--out",str(fx["report_dir"]), "--rounds",str(repairs),
                "--timeout","30", "--no-coverage", "--python",self.python]
        if keyword is not None:
            args += ["--pytest-k",keyword]
        if marker is not None:
            args += ["--pytest-m",marker]
        completed = self.command(fx, args)
        report_path = fx["report_dir"] / "report.json"
        assert report_path.is_file(), (
            "actual CLI wrote no report: rc=" + str(completed.returncode) + "; stderr=" +
            completed.stderr.decode("utf-8", "replace")[-1600:])
        report = json.loads(report_path.read_bytes())
        self.report(fx, report, keyword, marker)
        return completed.returncode, report


    def report(self, fx, report, keyword, marker):
        active = keyword is not None or marker is not None
        if active:
            assert report.get("pytest_selection") == {"keyword":keyword, "marker":marker}
        else:
            assert "pytest_selection" not in report, "default report gained selector context"
        files = fx["report_dir"]
        json_bytes = (files / "report.json").read_bytes()
        patch_bytes = (files / "testpilot.patch").read_bytes()
        md = (files / "report.md").read_text()
        parser = ReadingHTML()
        parser.feed((files / "report.html").read_text())
        assert not parser.active_tags, parser.active_tags
        for name, expected in (("report.json",json_bytes), ("testpilot.patch",patch_bytes)):
            uri = parser.downloads[name]
            assert ";base64," in uri
            assert base64.b64decode(uri.split(",",1)[1], validate=True) == expected
        if active:
            for rendered in (md, "".join(parser.text)):
                lowered = rendered.lower()
                assert "pytest" in lowered, "selection has no readable pytest scope"
                assert ("unselected" in lowered or "not selected" in lowered), (
                    "report omits the unselected-test boundary")
                for literal in (keyword,marker):
                    if literal is not None:
                        assert literal in rendered or json.dumps(literal) in rendered, (
                            "literal selector absent from reading text", literal)
        assert report.get("coverage") is None, "--no-coverage result changed"

    def audit(self, fx, keyword, marker, counts):
        events = [json.loads(line) for line in fx["audit"].read_text().splitlines()]
        sessions = []
        for event in events:
            if event["event"] == "start":
                sessions.append({"start":event,"calls":[]})
            elif event["event"] == "call":
                sessions[-1]["calls"].append(event)
            elif event["event"] == "finish":
                sessions[-1]["finish"] = event
        assert len(sessions) == len(counts), sessions
        for index,(session,count) in enumerate(zip(sessions,counts)):
            assert session["start"]["keyword"] == (keyword if keyword is not None else "")
            assert session["start"]["marker"] == (marker if marker is not None else "")
            assert session["start"]["generated_present"] == (index > 0)
            assert len(session["finish"]["items"]) == count, session
            assert len(session["calls"]) == count, session
        return sessions

    @staticmethod
    def final(report, status, passed, failed, generated_passed, generated_collected):
        assert report["status"] == status, report.get("message")
        assert report["ok"] == (status == "passed")
        final = report["final"]
        assert final["junit_available"] and not final["timed_out"], final
        assert (final["passed"],final["failed"],final["errors"]) == (passed,failed,0)
        assert final["generated"]["passed"] == generated_passed
        assert final["generated"]["collected"] == generated_collected
        assert report["tests_written"] == generated_collected

    def keyword(self):
        fx = self.fixture("keyword",FOCUS_EXISTING,FOCUS_GENERATED)
        code,report = self.run(fx,keyword="focus")
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,"focus",None,[1,2])
        self.saved["keyword"] = (fx,report)
        return {"selected_cases":2,"generated_passed":1,"native_sessions":2}

    def marker(self):
        fx = self.fixture("marker",FOCUS_EXISTING,FOCUS_GENERATED)
        code,report = self.run(fx,marker="fast")
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,None,"fast",[1,2])
        return {"selected_cases":2,"generated_passed":1,"native_sessions":2}

    def intersection(self):
        existing = [("test_focus_fast_existing","fast",True),
                    ("test_focus_slow_existing","slow",False),
                    ("test_outside_fast_existing","fast",False)]
        generated = [(name.replace("existing","generated"),mark,good)
                     for name,mark,good in existing]
        fx = self.fixture("intersection",existing,generated)
        code,report = self.run(fx,keyword="focus",marker="fast")
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,"focus","fast",[1,2])
        return {"excluded_deliberate_failures":4,"native_sessions":2}

    def selected_failure(self):
        generated = [("test_focus_generated","fast",False)]
        fx = self.fixture("selected_failure",FOCUS_EXISTING,generated)
        code,report = self.run(fx,keyword="focus")
        assert code == 1
        self.final(report,"failed",1,1,0,1)
        self.audit(fx,"focus",None,[1,2])
        return {"selected_failure_retained":True}

    def repair(self):
        first = [("test_focus_generated","fast",False),
                 ("test_outside_generated","slow",False)]
        fx = self.fixture("repair",FOCUS_EXISTING,first,FOCUS_GENERATED)
        code,report = self.run(fx,keyword="focus",marker="fast",repairs=1)
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,"focus","fast",[1,2,2])
        assert report["repair_rounds_used"] == 1
        assert [r["kind"] for r in report["rounds"]] == ["generate","repair"]
        assert report["rounds"][0]["result"]["failed"] == 1
        assert report["rounds"][1]["result"]["failed"] == 0
        return {"native_sessions":3,"first_selected_failure":True}

    def generated_deselected(self):
        fx = self.fixture("generated_deselected",FOCUS_EXISTING,
                          [("test_unselected_generated","fast",True)])
        code,report = self.run(fx,keyword="focus")
        assert code == 1
        self.final(report,"no_tests",1,0,0,0)
        self.audit(fx,"focus",None,[1,1])
        assert report["patch"], "unqualified authored patch was lost"
        return {"existing_pass_did_not_qualify_generated":True}

    def all_deselected(self):
        fx = self.fixture("all_deselected",FOCUS_EXISTING,FOCUS_GENERATED)
        literal = "no_case_has_this_receiver_name"
        code,report = self.run(fx,keyword=literal)
        assert code == 1
        self.final(report,"no_tests",0,0,0,0)
        self.audit(fx,literal,None,[0,0])
        assert report["final"]["returncode"] == 5
        return {"empty_native_selection_did_not_pass":True}


    def literals(self):
        keyword,marker = "  focus and not absent  ", " fast "
        fx = self.fixture("literals",FOCUS_EXISTING,FOCUS_GENERATED)
        code,report = self.run(fx,keyword=keyword,marker=marker)
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,keyword,marker,[1,2])
        return {"leading_and_trailing_whitespace_preserved":True}

    def empty_literal(self):
        existing = [("test_existing","fast",True)]
        generated = [("test_generated","slow",True)]
        fx = self.fixture("empty_literal",existing,generated)
        code,report = self.run(fx,keyword="",marker="")
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,"","",[1,2])
        return {"empty_strings_are_explicit_context":True}

    def default(self):
        fx = self.fixture("default",[("test_existing","fast",True)],
                          [("test_generated","slow",True)])
        code,report = self.run(fx)
        assert code == 0
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,None,None,[1,2])
        return {"no_selector_context_in_default_json":True}

    def recheck(self):
        assert "keyword" in self.saved, "keyword case is a prerequisite"
        fx,original = self.saved["keyword"]
        original_path = fx["report_dir"] / "report.json"
        before = sha(original_path.read_bytes())
        out = fx["root"] / "full-recheck"
        completed = self.command(fx,[
            "recheck","--repo",str(fx["repo"]),"--report",str(original_path),
            "--out",str(out),"--timeout","30","--python",self.python],label="recheck")
        assert completed.returncode == 1, completed.stderr.decode("utf-8","replace")
        result = json.loads((out / "recheck.json").read_bytes())
        assert result["status"] == "failed", result
        assert result["model_calls"] == 0
        native = result.get("result", result.get("final"))
        assert native is not None, "missing native recheck result"
        assert (native["passed"],native["failed"],native["errors"]) == (2,2,0),native
        assert native["generated"]["passed"] == 1
        assert native["generated"]["failed"] == 1
        assert sha(original_path.read_bytes()) == before
        events = [json.loads(line) for line in fx["audit"].read_text().splitlines()]
        starts = [event for event in events if event["event"] == "start"]
        assert len(starts) == 3
        assert starts[-1]["keyword"] == "" and starts[-1]["marker"] == ""
        assert starts[-1]["generated_present"]
        return {"original_filtered_status":original["status"],"recheck_status":result["status"],
                "unselected_failures_exposed":2,"model_calls":0}

    def invalid_expression(self):
        literal = "("
        fx = self.fixture("invalid_expression",FOCUS_EXISTING,FOCUS_GENERATED)
        code,report = self.run(fx,keyword=literal)
        assert code != 0 and not report["ok"]
        assert report["status"] == "failed", report
        native = report["final"]
        assert native is not None and native["returncode"] == 4, native
        assert not native["ok"]
        assert not any(c["outcome"] == "passed" for c in native["cases"])
        assert "expression" in (native["output"] + report.get("message","")).lower()
        return {"native_usage_refusal":4,"verified_success":False}

    def api_context(self):
        first = [("test_focus_generated","fast",False),
                 ("test_outside_generated","slow",False)]
        fx = self.fixture("api_context",FOCUS_EXISTING,first,FOCUS_GENERATED)
        keyword,marker = "focus", "fast"
        data = {"repo":str(fx["repo"]), "diff":str(fx["diff"]),
                "script":str(fx["script"]), "out":str(fx["report_dir"]),
                "python":self.python,"keyword":keyword,"marker":marker}
        api_code = r"""
import json, pathlib, sys
from testpilot.loop import TestPilot, write_outputs
from testpilot.model import ScriptedModel
data=json.loads(sys.argv[1])
client=ScriptedModel.from_dir(data["script"])
pilot=TestPilot(client,pytest_k=data["keyword"],pytest_m=data["marker"],
                max_repair_rounds=1,timeout_s=30,coverage=False,python=data["python"])
result=pilot.run(data["repo"],pathlib.Path(data["diff"]).read_text())
assert result.ok
assert len(client.calls)==3
for model,messages in client.calls:
    text="\n".join(message["content"] for message in messages)
    for key in ("keyword","marker"):
        assert data[key] in text, (key,text)
    assert "pytest" in text.lower()
refusals=[]
for name in ("pytest_k","pytest_m"):
    for value in (0,False,[],{},b"focus","focus\x00"):
        other=ScriptedModel([])
        try:
            TestPilot(other,**{name:value})
        except (TypeError,ValueError) as exc:
            assert not other.calls
            refusals.append({"parameter":name,"value_type":type(value).__name__,
                             "error_type":type(exc).__name__,"message":str(exc)})
        else:
            raise AssertionError((name,repr(value),"invalid selector accepted"))
write_outputs(result,data["out"])
payload={"calls":[{"model":model,"messages":messages} for model,messages in client.calls],
         "constructor_refusals":refusals}
pathlib.Path(data["out"]).parent.joinpath("api-observations.json").write_text(
    json.dumps(payload,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"status":"PASS","model_calls":len(client.calls),"constructor_refusals":len(refusals)}))
"""
        completed = subprocess.run([self.python,"-c",api_code,json.dumps(data)],
                                   cwd=self.source,env=self.env,capture_output=True,timeout=180)
        (fx["root"] / "api.stdout").write_bytes(completed.stdout)
        (fx["root"] / "api.stderr").write_bytes(completed.stderr)
        (fx["root"] / "api-child.py.txt").write_text(api_code)
        assert completed.returncode == 0, completed.stderr.decode("utf-8","replace")
        assert snapshot(fx["repo"]) == fx["before"]
        report = json.loads((fx["report_dir"] / "report.json").read_bytes())
        self.report(fx,report,keyword,marker)
        self.final(report,"passed",2,0,1,1)
        self.audit(fx,keyword,marker,[1,2,2])
        observed = json.loads((fx["root"] / "api-observations.json").read_bytes())
        assert len(observed["constructor_refusals"]) == 12
        return {"actual_prompt_contexts":3,"constructor_refusals":12,"native_sessions":3}


    def execute(self, names):
        receipt = {"schema":"testpilot.independent-pytest-selection-receiving/1",
                   "started_at":stamp(),"python":sys.version,"source":str(self.source),
                   "source_before":self.before,"control_sha256":sha(pathlib.Path(__file__).read_bytes()),
                   "status":"RUNNING","cases":self.records}
        version = subprocess.run([self.python,"-m","pytest","--version"],
                                 env=self.env,capture_output=True,text=True,timeout=30)
        receipt["pytest_version"] = version.stdout.strip()
        receipt["pytest_version_exit"] = version.returncode
        def save():
            target = self.out / "receipt.json"
            temporary = self.out / "receipt-writing.tmp"
            temporary.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
            temporary.replace(target)
        save()
        for name in names:
            record = {"name":name,"started_at":stamp()}
            try:
                record.update(status="PASS",details=getattr(self,name)())
            except Exception as exc:
                record.update(status="FAIL",error_type=type(exc).__name__,error=str(exc),
                              traceback=traceback.format_exc())
            record["completed_at"] = stamp()
            self.records.append(record)
            save()
            print(json.dumps({"case":name,"status":record["status"]}),flush=True)
        after = snapshot(self.source / "testpilot")
        receipt["source_after"] = after
        receipt["source_unchanged"] = after == self.before
        receipt["status"] = ("PASS" if receipt["source_unchanged"] and
                             all(c["status"]=="PASS" for c in self.records) else "FAIL")
        receipt["completed_at"] = stamp()
        save()
        print(json.dumps({"status":receipt["status"],"cases":len(self.records),
                          "passed":sum(c["status"]=="PASS" for c in self.records),
                          "source_unchanged":receipt["source_unchanged"]}),flush=True)
        return 0 if receipt["status"] == "PASS" else 1

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--source",type=pathlib.Path,required=True)
    parser.add_argument("--out",type=pathlib.Path,required=True)
    parser.add_argument("--python",required=True)
    parser.add_argument("--only")
    args=parser.parse_args()
    names=(args.only.split(",") if args.only else [
        "keyword","marker","intersection","selected_failure","repair",
        "generated_deselected","all_deselected","literals","empty_literal",
        "default","recheck","invalid_expression","api_context"])
    allowed={"keyword","marker","intersection","selected_failure","repair",
             "generated_deselected","all_deselected","literals","empty_literal",
             "default","recheck","invalid_expression","api_context"}
    assert names and all(name in allowed for name in names)
    raise SystemExit(Receiver(args.source,args.out,args.python).execute(names))
