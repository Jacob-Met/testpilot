import pathlib,json,hashlib
from testpilot.loop import TestPilot,write_outputs
from testpilot.model import ScriptedModel
r=pathlib.Path('/srv/hamon-estate/receivers/estate-a3425ebf9874-testpilot-pytest-selection/receiving/usage-coverage-corrected');r.mkdir(exist_ok=False)
p=r/'project';(p/'tests').mkdir(parents=True)
(p/'answer.py').write_text('def answer():\n    return 2\n')
(p/'tests/test_existing.py').write_text('from answer import answer\nIMPORTED = answer()\ndef test_focus():\n    assert IMPORTED == 2\n')
model=ScriptedModel([])
result=TestPilot(model,coverage=True,pytest_k='focus and (',timeout_s=15,max_repair_rounds=0).run(p,'--- a/answer.py\n+++ b/answer.py\n@@ -1,2 +1,2 @@\n def answer():\n-    return 1\n+    return 2\n')
write_outputs(result,r/'output')
d={'source':'68ab472099e3b42c5d6c11e8736569b86432c83c','status':result.status,'returncode':result.final['returncode'],'model_calls':len(model.calls),'rounds':len(result.rounds),'coverage_comparison':result.coverage,'final_coverage':result.final.get('coverage'),'expected':'One refused baseline may retain native coverage diagnostics, but must not claim a before/after comparison without a second execution.'}
b=(json.dumps(d,indent=2)+'\n').encode();(r/'receipt.json').write_bytes(b)
print('USAGE_COVERAGE_ORIGINAL '+json.dumps(d))