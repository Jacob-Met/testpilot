from __future__ import annotations
import pathlib,json,hashlib,subprocess,os,datetime
root=pathlib.Path('/srv/hamon-estate/receivers/estate-a3425ebf9874-testpilot-pytest-selection')
src=root/'source-current';out=root/'receiving/current-composition/cli-controls';out.mkdir(exist_ok=False)
freeze=json.loads((out.parent/'source-freeze.json').read_text())
repo=out/'project';(repo/'tests').mkdir(parents=True)
(repo/'answer.py').write_text('def answer():\n    return 2\n')
(repo/'pytest.ini').write_text('[pytest]\nmarkers =\n    unit: local cases\n    external: deliberate offline failing stand-in\n')
(repo/'tests/test_existing.py').write_text('import pytest\nfrom answer import answer\n@pytest.mark.unit\ndef test_focus_existing():\n    assert answer() == 2\n@pytest.mark.external\ndef test_outside():\n    assert False\n')
script=out/'responses';script.mkdir()
(script/'01.txt').write_text('Check the local unit answer.')
(script/'02.txt').write_text('~~~unused~~~\n'+chr(96)*3+'python path=tests/test_generated.py\nimport pytest\nfrom answer import answer\n@pytest.mark.unit\ndef test_focus_generated():\n    assert answer() == 2\n'+chr(96)*3+'\n')
diff=out/'valid.diff';diff.write_text('--- a/answer.py\n+++ b/answer.py\n@@ -1,2 +1,2 @@\n def answer():\n-    return 1\n+    return 2\n')
bad=out/'invalid.diff';bad.write_text(diff.read_text().replace('+1,2','+1,3'))
result=out/'result';env=dict(os.environ,PYTHONPATH=str(src),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(root/'receiving/producer-v1/tmp'))
def snap(p):return {str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in p.rglob('*') if x.is_file()}
original=snap(repo);events=[]
def run(name,args):
 argv=[str(root/'venv/bin/python'),'-B','-m','testpilot',*map(str,args)]
 r=subprocess.run(argv,cwd=out,env=env,capture_output=True,text=True,timeout=60)
 (out/(name+'.stdout.txt')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr)
 events.append({'name':name,'argv':argv,'exit':r.returncode})
 (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
 return r
common=['--pytest-k','focus','--pytest-m','unit']
r=run('selected',['run','--repo',repo,'--diff',diff,'--backend','scripted','--script',script,'--rounds','0','--timeout','15','--python',root/'venv/bin/python','--no-coverage','--out',result,*common])
assert r.returncode==0,(r.stdout,r.stderr)
d=json.loads((result/'report.json').read_text())
assert d['status']=='passed' and d['final']['passed']==2 and d['final']['generated']['passed']==1
assert d['pytest_selection']=={'keyword':'focus','marker':'unit'}
assert snap(repo)==original
saved=snap(result)
r=run('invalid-timeout',['run','--repo',out/'missing-project','--diff',out/'missing.diff','--backend','scripted','--script',out/'missing-script','--out',result,'--timeout=nan',*common])
assert r.returncode==2 and 'positive finite' in r.stderr and 'Traceback' not in r.stderr
assert not r.stdout and snap(result)==saved
r=run('invalid-diff',['run','--repo',repo,'--diff',bad,'--backend','scripted','--script',out/'missing-script','--out',result,*common])
assert r.returncode==2 and 'invalid diff format' in r.stderr and 'Traceback' not in r.stderr
assert not r.stdout and snap(result)==saved and snap(repo)==original
assert all(hashlib.sha256((src/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in freeze['files'])
receipt={'schema':'hamon.testpilot-current-composition-cli.v1','candidate':freeze['candidate'],'actual_current_parent':freeze['actual_current_parent'],'groups':3,'passed':3,'source_files_unchanged':len(freeze['files']),'source_selection':d['pytest_selection'],'events':events,'retained_output_sha256':saved,'project_unchanged':True,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boundary':'Bounded composition controls only. Original broad13+13 gates and coverage correction stay tied to their original frozen sources. No broad native suite rerun.'}
b=(json.dumps(receipt,indent=2)+'\n').encode();(out/'receipt.json').write_bytes(b)
print('COMPOSITION_CONTROLS '+json.dumps({'candidate':freeze['candidate'],'passed':3,'source_unchanged':True,'receipt_sha256':hashlib.sha256(b).hexdigest()}))
