import pytest
from answer import answer
@pytest.mark.unit
def test_focus_existing():
    assert answer() == 2
@pytest.mark.external
def test_outside():
    assert False
