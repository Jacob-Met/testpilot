"""Authored, model-free witness for the current native pytest-selection boundary."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "baseline"
OUT = ROOT / "receiving" / "baseline-witness"
OUT.mkdir(exist_ok=False)
TMP = OUT / "tmp"
TMP.mkdir()
os.environ["TMPDIR"] = str(TMP)
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE))

from testpilot.sandbox import run_pytest
import testpilot

assert Path(testpilot.__file__).resolve().is_relative_to(SOURCE)

DIFF = """diff --git a/calc.py b/calc.py
--- a/calc.py
+++ b/calc.py
@@ -1,2 +1,2 @@
 def add(a, b):
-    return a - b
+    return a + b
"""
GENERATED = """import pytest
from calc import add

@pytest.mark.unit
def test_generated_unit():
    assert add(4, 7) == 11
"""
EXISTING = """import pytest
from calc import add

@pytest.mark.unit
def test_existing_unit():
    assert add(2, 3) == 5
"""
SLOW = """
@pytest.mark.slow
def test_authored_external_fixture():
    assert False, 'Authored unselected fixture; no external service exists or is called.'
"""


def digest_project(project: Path) -> dict[str, str]:
    return {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(project.rglob("*")) if p.is_file()}


def project(name: str, slow: bool) -> Path:
    path = OUT / name
    (path / "tests").mkdir(parents=True)
    (path / "calc.py").write_text("def add(a, b):\n    return a + b\n")
    (path / "tests/test_existing.py").write_text(EXISTING + (SLOW if slow else ""))
    (path / "pytest.ini").write_text("[pytest]\nmarkers =\n    unit: authored fast checks\n    slow: authored excluded fixture\n")
    return path


script = OUT / "script"
script.mkdir()
(script / "01_plan.md").write_text("Exercise the addition function with an authored unit check.\n")
(script / "02_tests.md").write_text("```python path=tests/test_generated.py\n" + GENERATED + "```\n")
diff_path = OUT / "change.diff"
diff_path.write_text(DIFF)
mixed = project("mixed-project", True)
ordinary = project("ordinary-project", False)
before = {str(p.name): digest_project(p) for p in (mixed, ordinary)}
env = os.environ.copy()
env.update(PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE="1", PYTEST_ADDOPTS="", PYTEST_PLUGINS="")
records = []


def cli(name: str, repo: Path, extra: list[str]) -> dict:
    dest = OUT / (name + "-output")
    args = [sys.executable, "-m", "testpilot", "run", "--repo", str(repo),
            "--diff", str(diff_path), "--backend", "scripted", "--script", str(script),
            "--rounds", "0", "--timeout", "15", "--out", str(dest), *extra]
    process = subprocess.run(args, cwd=SOURCE, env=env, capture_output=True, text=True, timeout=50)
    (OUT / (name + ".stdout.txt")).write_text(process.stdout)
    (OUT / (name + ".stderr.txt")).write_text(process.stderr)
    report = json.loads((dest / "report.json").read_text()) if (dest / "report.json").exists() else None
    record = {"name": name, "argv": args, "exit": process.returncode,
              "output_exists": dest.exists(), "status": report["status"] if report else None,
              "final": report["final"] if report else None,
              "model_calls": len(report["ledger"]["entries"]) if report else None}
    records.append(record)
    return record


a = cli("ordinary-default", ordinary, [])
assert a["exit"] == 0 and a["status"] == "passed"
assert a["final"]["passed"] == 2 and a["final"]["generated"]["passed"] == 1
b = cli("mixed-default", mixed, [])
assert b["exit"] == 1 and b["status"] == "failed"
assert b["final"]["failed"] == 1 and b["final"]["passed"] == 2
for name, args in [("keyword-cli-missing", ["--pytest-k", "unit"]),
                   ("marker-cli-missing", ["--pytest-m", "unit"])]:
    got = cli(name, mixed, args)
    assert got["exit"] == 2 and not got["output_exists"]
    assert "unrecognized arguments" in (OUT / (name + ".stderr.txt")).read_text()

for name, args in [("native-keyword-control", ("-k", "unit")),
                   ("native-marker-control", ("-m", "unit"))]:
    result = run_pytest(mixed, {"tests/test_generated.py": GENERATED}, timeout=15,
                        coverage=False, pytest_args=args)
    data = result.to_dict()
    records.append({"name": name, "pytest_args": args, "native_result": data})
    assert result.ok and result.passed == 2 and result.failed == 0
    assert result.generated_counts()["passed"] == 1

after = {str(p.name): digest_project(p) for p in (mixed, ordinary)}
assert before == after
receipt = {"schema": "hamon.testpilot-selection-original-witness.v1",
           "upstream": "191cca4e416286a9e1fa4b5d5daf5fc30b936db6",
           "native_source_capture": subprocess.run(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip(),
           "scope": "Six authored original-source controls; all expected original behavior verified. Two requested CLI selection flows are unavailable, two lower-level selections and two default flows behave as recorded.",
           "python": sys.version, "executable": sys.executable,
           "project_inputs_before": before, "project_inputs_after": after,
           "records": records}
raw = (json.dumps(receipt, indent=2) + "\n").encode()
(OUT / "receipt.json").write_bytes(raw)
print(json.dumps({"groups": len(records), "original_cli_selection_flows_unavailable": 2,
                  "inputs_unchanged": before == after,
                  "receipt_sha256": hashlib.sha256(raw).hexdigest()}))
