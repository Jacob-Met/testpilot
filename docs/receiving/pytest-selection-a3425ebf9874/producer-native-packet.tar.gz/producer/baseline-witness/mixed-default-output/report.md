# TestPilot report: **failed**

still failing after 0 repair round(s): 2 passed, 1 failed, 0 errors, 0 skipped (rc=1); generated: 1 passed of 1 collected

- Changed functions: calc.py::add
- Tests written: 1 in tests/test_generated.py
- Repair rounds used: 0/0
- Final run: 2 passed, 1 failed, 0 errors, 0 skipped (rc=1); generated: 1 passed of 1 collected in 0.673s
- Coverage (total): 100.0% -> 100.0% (+0.0 pts)
- Coverage (changed lines, n=1): 100.0% -> 100.0%
- Tokens: 300 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 90 in / 15 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 157 in / 38 out

## Patch

```diff
diff --git a/tests/test_generated.py b/tests/test_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_generated.py
@@ -0,0 +1,6 @@
+import pytest
+from calc import add
+
+@pytest.mark.unit
+def test_generated_unit():
+    assert add(4, 7) == 11
```
