import pytest
from calc import add

@pytest.mark.unit
def test_existing_unit():
    assert add(2, 3) == 5
