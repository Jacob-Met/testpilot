```python path=tests/test_generated.py
import pytest
from calc import add

@pytest.mark.unit
def test_generated_unit():
    assert add(4, 7) == 11
```
