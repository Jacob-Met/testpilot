Exercise the addition function with an authored unit check.
