import pytest
from calc import add

@pytest.mark.unit
def test_existing_unit():
    assert add(2, 3) == 5

@pytest.mark.slow
def test_authored_external_fixture():
    assert False, 'Authored unselected fixture; no external service exists or is called.'
