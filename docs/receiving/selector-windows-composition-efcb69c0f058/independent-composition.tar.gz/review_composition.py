from pathlib import Path
import base64
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/efcb69c0f058')
REPO = ROOT / 'source_delivery/testpilot-combined'
OUT = ROOT / 'context_adoption/testpilot-composition-review'
HEAD = '3ae1e18d970878a1713a374b7e5fcd3587083a98'
TREE = '5f2c71beb723d911ef59b9d28cb179bddc0f378e'
BASE = '86617fc90becf79b20d9cf5212b848bff8227147'
OLD = '52275f50e672c145d8f69e90cf40948ab28a7d79'
OFFERS = ['57ea98545a22974d73d712cf9ae6290bc0f4bbe6', '067cf4597c067aad41216ba39c8c29fe3ecd9f3a']
EXTRA = 'docs/receiving/selector-windows-composition-efcb69c0f058/'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not row:
            continue
        meta, name = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        result[name.decode()] = {'mode': mode, 'kind': kind, 'blob': blob}
    return result

def payload(p, item):
    if item['mode'] == '120000':
        return os.readlink(p).encode()
    assert p.is_file() and not p.is_symlink(), str(p)
    return p.read_bytes()

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert git('show', '--no-patch', '--format=%P', HEAD).decode().strip().split() == [BASE, *OFFERS]
before_status = git('status', '--porcelain=v1', '--untracked-files=all')
assert before_status == b''
base, old, candidate = tree(BASE), tree(OLD), tree(HEAD)
expected = dict(base)
deltas = []
for offer in OFFERS:
    proposed = tree(offer)
    delta = {p for p in old.keys() | proposed.keys() if old.get(p) != proposed.get(p)}
    deltas.append(delta)
    for p in delta:
        assert base.get(p) == old.get(p), 'New main changed offered path: ' + p
        if p in proposed:
            expected[p] = proposed[p]
        else:
            expected.pop(p, None)
assert not (deltas[0] & deltas[1])
extra = sorted(set(candidate) - set(expected))
assert extra == sorted(EXTRA + n for n in ['README.md', 'focused-receipt.json', 'focused.stderr.log', 'focused.stdout.log', 'source-scope.json', 'windows-offer-review.json'])
assert {p: v for p, v in candidate.items() if p not in extra} == expected
changed = sorted(p for p in base if candidate.get(p) != base[p])
assert changed == ['testpilot/diff.py', 'testpilot/sandbox.py']
assert len(base) == 1517

working = {}
for p, item in candidate.items():
    full = REPO / p
    data = payload(full, item)
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert blob == item['blob'], p
    if item['mode'] != '120000':
        assert bool(full.stat().st_mode & 0o111) == (item['mode'] == '100755'), p
    working[p] = {'mode': item['mode'], 'git_blob': blob, 'sha256': sha(data), 'bytes': len(data), 'mtime_ns': full.lstat().st_mtime_ns}

pins = {'testpilot/diff.py': '60255ce91ded605323ad6d58608ba4681c7c70a1478f1e6da9e89a7675034977', 'testpilot/sandbox.py': '899a454dea73c988645b04cba887b13f7770b824b00f0c0f8be5c179903577e0'}
for p, expected_sha in pins.items():
    assert working[p]['sha256'] == expected_sha
remote = []
for label, p in [('baseline-guide', 'docs/BASELINE_RUNNER_ADMISSION.md'), ('baseline-loop', 'testpilot/loop.py'), ('baseline-tests', 'tests/test_baseline_runner_admission.py')]:
    response = json.loads((OUT / (label + '-response.json')).read_text())
    assert response['encoding'] == 'base64'
    data = base64.b64decode(response['content'])
    assert data == (REPO / p).read_bytes()
    assert response['sha'] == candidate[p]['blob'] == base[p]['blob']
    remote.append({'path': p, 'url': response['display_url'], **working[p]})

receipt = json.loads((REPO / EXTRA / 'focused-receipt.json').read_text())
assert receipt['returncode'] == 0
assert receipt['cwd'] == str(REPO)
assert receipt['source_and_test_bytes_preserved'] is True
for p, pin in receipt['source_and_test_sha256'].items():
    assert pin == working[p]['sha256'], p
for module, full in receipt['identity']['modules'].items():
    assert Path(full).is_relative_to(REPO)
for stream in ['stdout', 'stderr']:
    assert receipt[stream + '_sha256'] == sha((REPO / EXTRA / ('focused.' + stream + '.log')).read_bytes())
stdout = (REPO / EXTRA / 'focused.stdout.log').read_text()
assert '40 passed, 13 subtests passed in 4.49s' in stdout
assert receipt['full_suite_rerun'] is False and receipt['native_windows_execution'] is False
assert (REPO / EXTRA / 'windows-offer-review.json').read_bytes() == (ROOT / 'source_delivery/windows-composition-review.json').read_bytes()
readme = (REPO / EXTRA / 'README.md').read_text()
for phrase in ['two complete-suite detached-helper observation failures', 'A complete suite was not rerun', 'No new benchmark or installed latency result', 'Default-branch adoption remains with']:
    assert phrase in readme

for p, record in working.items():
    assert sha(payload(REPO / p, candidate[p])) == record['sha256'], p
    assert (REPO / p).lstat().st_mtime_ns == record['mtime_ns'], p
assert git('status', '--porcelain=v1', '--untracked-files=all') == before_status
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
result = {'reviewer': 'estate-efcb69c0f058 / context_adoption', 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(), 'accepted': True, 'scope': 'Independent exact source-composition and retained-receipt review; no new tests, native run, benchmark, publication, or default-branch adoption.', 'candidate_head': HEAD, 'candidate_tree': TREE, 'parents': [BASE, *OFFERS], 'current_parent_received_from_connected_github': BASE, 'inherited_main_leaves': len(base), 'candidate_leaves': len(candidate), 'changed_inherited_paths': changed, 'exact_offer_delta_paths': [sorted(x) for x in deltas], 'offer_deltas_disjoint': True, 'complete_source_union_exact': True, 'new_receiving_only_paths': extra, 'working_tree_files_and_modes_match_every_git_blob': True, 'working_tree_bytes_and_modification_times_unchanged': True, 'whole_source_pins': pins, 'direct_connected_github_main_files_received': remote, 'qualification_log_received': {'passed_tests': 40, 'passed_subtests': 13, 'pytest_seconds': 4.49, 'receipt_elapsed_seconds': receipt['elapsed_seconds'], 'stdout_sha256': receipt['stdout_sha256'], 'stderr_sha256': receipt['stderr_sha256'], 'all_nine_source_and_test_hashes_match': len(receipt['source_and_test_sha256']) == 9, 'modules_resolve_to_candidate': True, 'replayed_by_this_reviewer': False}, 'retained_windows_review_byte_identical': True, 'limits': ['Original source-offer qualifications retain their own exact source scope.', 'Current baseline-runner admission files are byte-identical to connected main 86617fc.', 'Native Windows and all descendant/POSIX acceptance remain separate.', 'The original full-suite observation failures are preserved, not relabeled as resolved.', 'No publication or Actions execution was attempted by this reviewer.']}
(OUT / 'independent-composition-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'complete-source-inventory.json').write_text(json.dumps(working, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['exact_offer_delta_paths','direct_connected_github_main_files_received']}))
