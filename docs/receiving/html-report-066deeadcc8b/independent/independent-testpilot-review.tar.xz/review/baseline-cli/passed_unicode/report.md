# TestPilot report: **passed**

- Changed functions: sample.py::transform
- Tests written: 3 in tests/test_generated.py
- Repair rounds used: 0/0
- Final run: 3 passed, 0 failed, 0 errors, 1 skipped (rc=0); generated: 2 passed of 3 collected in 0.2s
- Coverage (total): 75.0% -> 100.0% (+25.0 pts)
- Coverage (changed lines, n=1): 100.0% -> 100.0%
- Tokens: 548 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `receiver-planner`: 1 calls, 140 in / 47 out
  - `receiver-editor`: 1 calls, 238 in / 123 out

## Patch

```diff
diff --git a/tests/test_generated.py b/tests/test_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_generated.py
@@ -0,0 +1,11 @@
+import pytest
+from sample import transform
+
+# Literal generated source: RECEIVER-λ-雪-café-🧭 </script><img id="receiver-injected" src="https://receiver.invalid/no-fetch"> & <details>literal</details>
+@pytest.mark.parametrize('value, expected', [(1, 2), (-1, 0)], ids=['café', '雪'])
+def test_values(value, expected):
+    assert transform(value) == expected
+
+@pytest.mark.skip(reason='Receiver skip λ <literal>')
+def test_skipped():
+    assert False
```
