# TestPilot report: **model_error**

scripted:script: script exhausted after 1 calls

- Changed functions: sample.py::transform
- Tests written: 0 in -
- Repair rounds used: 0/0
- Coverage: unavailable (install `coverage`)
- Tokens: 187 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `receiver-planner`: 1 calls, 140 in / 47 out
