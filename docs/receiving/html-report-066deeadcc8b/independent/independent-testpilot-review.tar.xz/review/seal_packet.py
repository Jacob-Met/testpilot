from pathlib import Path
import base64,hashlib,json,os,subprocess,tarfile,time
from datetime import datetime,timezone
root=Path("/Users/me/testpilot-html-review-066deeadcc8b")
transfer=Path("/Users/me/testpilot-html-review-066deeadcc8b-transfer")
transfer.mkdir()
receipt_path=root/"receipt.json"
if receipt_path.exists():raise RuntimeError("Refusing to replace a frozen receipt")
def digest(path):
 b=path.read_bytes()
 return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def payload_files():
 return [p for p in sorted(root.rglob("*")) if p.is_file()
         and p.relative_to(root).parts[0]!="tmp"
         and not (p.relative_to(root).parts[:2]==("final","tmp"))
         and p.name not in {".DS_Store","receipt.json"}]
files=payload_files()
receipt={"schema":"testpilot-html-independent-receiving-packet-v1","decision":"accepted","reviewer":"/root/research_execution","author":"/root/product_execution","repository":"Jacob-Met/testpilot","issue":17,"receiving_claim":"https://github.com/Jacob-Met/testpilot/issues/17#issuecomment-6059391380","baseline_commit":"d7c28b0ad261e78d681f40e355447dffa4d435ed","candidate_projection":"fe791af1a0908b2379dd7cbb87a9fb8f3cad87de","frozen_at":datetime.now(timezone.utc).isoformat(),"runtime_device":"0e3d582f-e25b-44b2-8418-9639fc4e4e33","original_native_root":str(root),"results":json.loads((root/"verification.json").read_text()),"boundaries":["Authored scripted-model cases; no model-provider call or general model-quality claim.","Actual private Chrome documents and downloads; no source application or production deployment.","Exact original reviewed 77-file projection; later current-main composition belongs to the author's separate supplement."],"files":[{"path":p.relative_to(root).as_posix(),**digest(p)} for p in files]}
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
argv=["/usr/local/bin/python3","-B",str(root/"verify_review.py")]
started=time.time()
with (transfer/"portable-verification.log").open("wb") as log:
 p=subprocess.Popen(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 code=p.wait(timeout=30)
if code!=0:raise RuntimeError("Frozen portable verification failed")
if (transfer/"portable-verification.log").read_bytes()!=(root/"verification.json").read_bytes():raise RuntimeError("Frozen recomputation changed")
archive=transfer/"independent-testpilot-review.tar.xz"
all_files=sorted(files+[receipt_path])
with tarfile.open(archive,"w:xz",preset=6) as t:
 for p in all_files:
  t.add(p,arcname="review/"+p.relative_to(root).as_posix(),recursive=False)
with tarfile.open(archive) as t:
 members=t.getmembers()
 if len(members)!=len(all_files) or any(not x.isfile() for x in members):raise RuntimeError("Archive member boundary differs")
 lookup={p.relative_to(root).as_posix():digest(p) for p in all_files}
 for member in members:
  name=member.name.removeprefix("review/")
  if name not in lookup:raise RuntimeError("Unknown archive member")
  b=t.extractfile(member).read()
  if {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}!=lookup[name]:raise RuntimeError("Archive content changed")
raw=archive.read_bytes()
encoded=base64.b64encode(raw).decode("ascii")
unit=32000
chunks=[encoded[i:i+unit] for i in range(0,len(encoded),unit)]
(transfer/"packet.b64lines").write_text("\n".join(chunks)+"\n")
metadata={"archive":str(archive),**digest(archive),"ordinary_members":len(all_files),"listed_files":len(files),"uncompressed_bytes":sum(x.stat().st_size for x in all_files),"receipt":digest(receipt_path),"verifier":digest(root/"verify_review.py"),"verification":digest(root/"verification.json"),"readme":digest(root/"README.md"),"portable_verification":{"argv":argv,"pid":p.pid,"exit_code":code,"started_utc_epoch":started,"elapsed_s":time.time()-started,"byte_identical":True},"base64_chunks":len(chunks),"base64_chunk_size":unit,"base64_final_length":len(chunks[-1])}
(transfer/"metadata.json").write_text(json.dumps(metadata,indent=2)+"\n")
print(json.dumps(metadata),flush=True)
