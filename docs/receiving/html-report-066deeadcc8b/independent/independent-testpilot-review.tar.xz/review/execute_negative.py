from pathlib import Path
import base64,hashlib,json,os,shutil,subprocess,time
root=Path("/Users/me/testpilot-html-review-066deeadcc8b")
final=root/"final"
negative=final/"negative-controls"
negative.mkdir()
inputs=json.loads((final/"inputs-manifest.json").read_text())
selected={"passed_unicode","timeout_tail"}
inputs["cases"]=[x for x in inputs["cases"] if x["name"] in selected]
(negative/"inputs-manifest.json").write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+"\n")
mutations=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for name in ["passed_unicode","timeout_tail"]:
    origin=final/"candidate-cli"/name
    dest=negative/"negative-cli"/name
    dest.mkdir(parents=True)
    for filename in ["report.json","report.md","testpilot.patch"]:
        shutil.copyfile(origin/filename,dest/filename)
    raw=(origin/"report.html").read_bytes()
    changed=raw
    if name=="passed_unicode":
        expected=(origin/"report.json").read_bytes()
        old=b"data:application/json;base64,"+base64.b64encode(expected)
        new=b"data:application/json;base64,"+base64.b64encode(expected+b"\n")
        if raw.count(old)!=1:raise RuntimeError("Expected one original JSON download")
        changed=raw.replace(old,new)
        reason="Append one valid-JSON whitespace byte only to the embedded download; visible report and exact sibling JSON remain unchanged."
        replacements=1
    else:
        old=b"The runner retains the last 3,000 characters in its report. This is the recorded tail, not a complete process log."
        replacements=raw.count(old)
        if replacements!=2:raise RuntimeError("Expected final and round tail qualifiers")
        changed=raw.replace(old,b"Recorded pytest output.")
        reason="Remove only the final and per-round visible retained-output qualifiers; exact JSON, patch, and printed output bytes remain unchanged."
    if changed==raw:raise RuntimeError("Negative control changed nothing")
    (dest/"report.html").write_bytes(changed)
    mutations.append({"case":name,"source":str(origin/"report.html"),"source_bytes":len(raw),"source_sha256":sha(raw),"mutant_bytes":len(changed),"mutant_sha256":sha(changed),"replacements":replacements,"reason":reason})
(negative/"mutations.json").write_text(json.dumps(mutations,indent=2)+"\n")
argv=["/opt/homebrew/bin/node",str(root/"receive_html.mjs"),str(negative),"negative-cli"]
log=negative/"browser.log"
started=time.time()
with log.open("wb") as f:
    p=subprocess.Popen(argv,cwd=root,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT)
    exit_code=p.wait(timeout=90)
b=log.read_bytes()
receipt={"argv":argv,"cwd":str(root),"pid":p.pid,"exit_code":exit_code,"started_utc_epoch":started,"elapsed_s":time.time()-started,"log":{"bytes":len(b),"sha256":sha(b)},"driver_sha256":sha((root/"receive_html.mjs").read_bytes())}
(negative/"execution.json").write_text(json.dumps(receipt,indent=2)+"\n")
report=json.loads((negative/"negative-cli-browser"/"summary.json").read_text())
failures={r["name"]:[k for k,v in r["checks"].items() if not v] for r in report["cases"]}
expected={"passed_unicode":["exact_download_report.json","javascript_disabled_exact_download"],"timeout_tail":["output_tail_qualified"]}
result={"expected_browser_exit":1,"actual_browser_exit":exit_code,"failures":failures,"expected_failures":expected,"detected_exactly":exit_code==1 and failures==expected}
(negative/"verification.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result),flush=True)
if not result["detected_exactly"]:raise RuntimeError("Negative receiver controls were not rejected exactly")
