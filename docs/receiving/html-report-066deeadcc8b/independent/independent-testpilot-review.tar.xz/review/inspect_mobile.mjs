import fs from "node:fs/promises";
import path from "node:path";
import {pathToFileURL} from "node:url";
import {createHash} from "node:crypto";
const {chromium}=await import("/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs");
const root="/Users/me/testpilot-html-review-066deeadcc8b";
const out=path.join(root,"final","visual-supplement");
await fs.mkdir(out);
const browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--disable-background-networking","--disable-component-update","--no-first-run"]});
const rows=[];
try{
 for(const [name,width] of [["repaired_partial",375],["passed_unicode",375],["timeout_tail",375]]){
  const context=await browser.newContext({viewport:{width,height:900}});
  const requests=[];
  await context.route("**/*",async route=>{if(/^https?:/.test(route.request().url())){requests.push(route.request().url());await route.abort();}else await route.continue();});
  const page=await context.newPage();
  const html=path.join(root,"final","candidate-cli-browser",name,"report.html");
  await page.goto(pathToFileURL(html).href,{waitUntil:"load"});
  await page.locator("details").evaluateAll(xs=>xs.forEach(x=>{x.open=true;}));
  await page.evaluate(async()=>{await document.fonts.ready;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));});
  const metrics=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollY,h1:document.querySelectorAll("h1").length,headers:document.querySelectorAll("header").length,firstSection:{y:document.querySelector("section").getBoundingClientRect().y,text:document.querySelector("section").innerText.slice(0,300)},text:document.body.innerText.slice(0,1200)}));
  const image=path.join(out,name+"-mobile-fresh.png");
  await page.screenshot({path:image});
  rows.push({name,width,requests,metrics,html_sha256:createHash("sha256").update(await fs.readFile(html)).digest("hex"),image_sha256:createHash("sha256").update(await fs.readFile(image)).digest("hex")});
  if(name==="repaired_partial"){
   await page.locator("#ledger").scrollIntoViewIfNeeded();
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const table=page.locator("#ledger .table-scroll");
   rows[rows.length-1].ledger=await table.evaluate(x=>({clientWidth:x.clientWidth,scrollWidth:x.scrollWidth,tabindex:x.tabIndex,role:x.getAttribute("role")}));
   await table.focus();
   await page.keyboard.press("ArrowRight");
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   rows[rows.length-1].ledger.scrollAfterKey=await table.evaluate(x=>x.scrollLeft);
   await page.screenshot({path:path.join(out,name+"-mobile-ledger.png")});
  }
  await context.close();
 }
}finally{await browser.close();}
const report={schema:"independent-fresh-mobile-visual-v1",browser:browser.version(),rows};
await fs.writeFile(path.join(out,"summary.json"),JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify(report));
