from sample import transform

def test_existing():
    assert transform(0) == 2
