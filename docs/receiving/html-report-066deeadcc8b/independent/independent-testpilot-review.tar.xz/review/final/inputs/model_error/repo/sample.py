def transform(value):
    """RECEIVER-λ-雪-café-🧭 </script><img id="receiver-injected" src="https://receiver.invalid/no-fetch"> & <details>literal</details>"""
    if value < 0:
        return 0
    return value + 1
