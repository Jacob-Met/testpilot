// Independent actual-document receiver. No candidate implementation imports.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {pathToFileURL} from "node:url";
const [root, phase] = process.argv.slice(2);
if (!root || !phase) throw new Error("Usage: receive_html.mjs ROOT PHASE");
const playwrightPath = process.env.TESTPILOT_REVIEW_PLAYWRIGHT ||
  "/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs";
const {chromium} = await import(pathToFileURL(playwrightPath));
const inputs = JSON.parse(await fs.readFile(path.join(root,"inputs-manifest.json"),"utf8"));
const output = path.join(root,phase+"-browser");
await fs.mkdir(output);
const sha = x => crypto.createHash("sha256").update(x).digest("hex");
const normalize = x => String(x).toLowerCase().replace(/[_\s-]+/g," ").trim();
const reports = [];
const browser = await chromium.launch({
  executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  headless:true,args:["--disable-background-networking","--disable-component-update","--no-first-run"]
});
const browserVersion = browser.version();
const startedAt = new Date().toISOString();
try {
  for (const spec of inputs.cases) {
    const name = spec.name;
    const original = path.join(root,phase,name);
    const row = {name,checks:{},errors:[],requests:[],downloads:[]};
    const folder = path.join(output,name);
    await fs.mkdir(folder);
    let context;
    try {
      let html;
      try {html = await fs.readFile(path.join(original,"report.html"));}
      catch(e) {if(e.code!=="ENOENT") throw e;}
      row.checks.actual_html_emitted = !!html;
      if (!html) {reports.push(row);continue;}
      const rawJson = await fs.readFile(path.join(original,"report.json"));
      const rawPatch = await fs.readFile(path.join(original,"testpilot.patch"));
      const data = JSON.parse(rawJson);
      // The browser receives only the unmodified HTML, with no sibling artifacts.
      const detached = path.join(folder,"report.html");
      await fs.writeFile(detached,html);
      row.html={original,bytes:html.length,sha256:sha(html),detached};
      context=await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true});
      await context.route("**/*", async route => {
        const url=route.request().url();
        if (/^https?:/i.test(url)) {row.requests.push(url);await route.abort();}
        else await route.continue();
      });
      const page=await context.newPage();
      page.on("pageerror",error=>row.errors.push(String(error)));
      page.on("popup",popup=>{row.errors.push("Unexpected popup: "+popup.url());void popup.close();});
      await page.goto(pathToFileURL(detached).href,{waitUntil:"load",timeout:15000});
      row.checks.title_present=(await page.title()).trim().length>0;
      row.checks.literal_markup_not_interpreted=await page.locator("#receiver-injected").count()===0;
      row.checks.no_active_embeds=await page.locator("iframe,object,embed").count()===0;
      row.checks.static_document=await page.locator("script").evaluateAll(nodes =>
        nodes.every(x=>["application/json","application/ld+json"].includes(x.type)));
      row.checks.no_inline_event_handlers=await page.locator("*").evaluateAll(nodes =>
        nodes.every(x=>Array.from(x.attributes).every(a=>!/^on/i.test(a.name))));
      await page.keyboard.press("Tab");
      row.first_keyboard_focus=await page.evaluate(()=>({
        tag:document.activeElement.tagName,text:document.activeElement.textContent?.trim().slice(0,150)
      }));
      row.checks.keyboard_reaches_control=["A","SUMMARY","BUTTON","INPUT"].includes(row.first_keyboard_focus.tag);
      const details=page.locator("details");
      row.details_count=await details.count();
      if (row.details_count) {
        const first=details.first();
        const before=await first.evaluate(x=>x.open);
        await first.locator("summary").first().focus();
        await page.keyboard.press("Enter");
        row.checks.native_disclosure_keyboard=await first.evaluate(x=>x.open)!==before;
      }
      await details.evaluateAll(nodes=>nodes.forEach(x=>{x.open=true;}));
      const dom=await page.evaluate(()=>{
        const pres=Array.from(document.querySelectorAll("pre,code")).map(x=>x.textContent);
        const outputs=Array.from(document.querySelectorAll("pre")).map(x=>{
          const container=x.closest("details,section,article")||x.parentElement;
          const copy=container.cloneNode(true);
          copy.querySelectorAll("pre,code").forEach(n=>n.remove());
          return {text:x.textContent,context:copy.textContent};
        });
        return {title:document.title,text:document.body.innerText,pres,outputs,
          headings:Array.from(document.querySelectorAll("h1,h2,h3,h4")).map(x=>({tag:x.tagName,text:x.textContent})),
          tables:Array.from(document.querySelectorAll("table")).map(t=>Array.from(t.rows).map(r=>Array.from(r.cells).map(c=>c.textContent))),
          links:Array.from(document.querySelectorAll("a")).map(a=>({text:a.textContent,href:a.getAttribute("href"),download:a.getAttribute("download")})),
          geometry:{width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight}};
      });
      await fs.writeFile(path.join(folder,"dom.json"),JSON.stringify(dom,null,2)+"\n");
      const text=dom.text, lower=normalize(text);
      row.checks.actual_status_visible=lower.includes(normalize(data.status));
      row.checks.changed_source_visible=data.changed_functions.every(f=>dom.pres.some(p=>p.includes(f.source.trimEnd())));
      row.checks.final_generated_source_visible=Object.values(data.test_files).every(c=>dom.pres.some(p=>p.includes(c.trimEnd())));
      row.checks.round_generated_source_visible=data.rounds.every(r=>Object.values(r.contents).every(c=>dom.pres.some(p=>p.includes(c.trimEnd()))));
      row.checks.round_warnings_visible=data.rounds.every(r=>r.warnings.every(w=>text.includes(w)));
      row.checks.plan_visible=!data.plan || text.includes(data.plan.trimEnd());
      row.checks.message_visible=!data.message || text.includes(data.message.trimEnd());
      if(data.ledger.entries.length) {
        row.checks.estimated_tokens_qualified=!data.ledger.tokens_estimated || /estimated/i.test(text);
        row.checks.unpriced_cost_qualified=data.ledger.cost_is_complete || /unpriced|not priced|pricing unavailable/i.test(text);
        row.checks.actual_models_visible=data.ledger.entries.every(e=>text.includes(e.model));
      }
      if(data.final) {
        row.final_summary_observed=text.includes(data.final.summary);
        row.checks.final_case_identities_visible=data.final.cases.every(c=>text.includes(c.nodeid));
        row.checks.final_failure_messages_visible=data.final.cases.filter(c=>c.outcome==="failed"||c.outcome==="error")
          .every(c=>!c.message || dom.pres.some(p=>p.includes(c.message.trimEnd())));
        if(!data.final.junit_available) row.checks.unavailable_junit_qualified=/junit/i.test(text)&&/unavailable|not available|not recorded/i.test(text);
        if(data.final.output) {
          row.checks.recorded_output_visible=dom.pres.some(p=>p.includes(data.final.output.trimEnd()));
          const relevant=dom.outputs.filter(p=>p.text.includes(data.final.output.trimEnd()));
          row.checks.output_tail_qualified=relevant.some(p=>/tail|truncat|last.{0,30}3000/is.test(p.context));
        }
      } else {
        row.checks.missing_final_qualified=/no[^\n]{0,80}(result|run)|unavailable|not recorded/i.test(text);
      }
      if(!data.coverage) row.checks.unavailable_coverage_qualified=/coverage/i.test(text)&&/unavailable|not available|not recorded/i.test(text);
      for(const [filename,expected] of [["report.json",rawJson],["testpilot.patch",rawPatch]]) {
        const anchors=page.locator("a[download]");
        const names=await anchors.evaluateAll(nodes=>nodes.map(x=>x.getAttribute("download")));
        const index=names.findIndex(x=>x===filename);
        row.checks["download_control_"+filename]=index>=0;
        if(index<0)continue;
        const wait=page.waitForEvent("download",{timeout:10000});
        await anchors.nth(index).click();
        const download=await wait;
        const saved=path.join(folder,"download-"+filename);
        await download.saveAs(saved);
        const actual=await fs.readFile(saved);
        row.downloads.push({name:filename,suggested:download.suggestedFilename(),bytes:actual.length,sha256:sha(actual)});
        row.checks["exact_download_"+filename]=actual.equals(expected);
      }
      await page.evaluate(()=>scrollTo(0,0));
      await page.screenshot({path:path.join(folder,"desktop.png")});
      await page.setViewportSize({width:375,height:900});
      await page.evaluate(()=>scrollTo(0,0));
      row.mobile=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,
        scrollHeight:document.documentElement.scrollHeight}));
      row.checks.mobile_no_page_overflow=row.mobile.scrollWidth<=376;
      await page.screenshot({path:path.join(folder,"mobile.png")});
      if(name==="repaired_partial") {
        await page.emulateMedia({media:"print"});
        await page.pdf({path:path.join(folder,"print.pdf"),format:"A4",printBackground:true});
        row.checks.print_artifact=(await fs.stat(path.join(folder,"print.pdf"))).size>1000;
      }
      const withoutScripts=await browser.newContext({viewport:{width:375,height:900},acceptDownloads:true,javaScriptEnabled:false});
      try {
        await withoutScripts.route("**/*",async route=>{
          const url=route.request().url();
          if(/^https?:/i.test(url)){row.requests.push("JS-disabled: "+url);await route.abort();}
          else await route.continue();
        });
        const staticPage=await withoutScripts.newPage();
        staticPage.on("pageerror",error=>row.errors.push("JS-disabled: "+String(error)));
        await staticPage.goto(pathToFileURL(detached).href,{waitUntil:"load",timeout:15000});
        row.checks.javascript_disabled_status=normalize(await staticPage.locator("body").innerText()).includes(normalize(data.status));
        const link=staticPage.locator('a[download="report.json"]');
        row.checks.javascript_disabled_download_control=await link.count()===1;
        if(await link.count()===1){
          const wait=staticPage.waitForEvent("download",{timeout:10000});
          await link.click();
          const download=await wait;
          const saved=path.join(folder,"javascript-disabled-report.json");
          await download.saveAs(saved);
          row.checks.javascript_disabled_exact_download=(await fs.readFile(saved)).equals(rawJson);
        }
      }finally{await withoutScripts.close();}
      row.checks.no_external_document_requests=row.requests.length===0;
      row.checks.no_application_errors=row.errors.length===0;
    } catch(e) {
      row.errors.push(String(e.stack||e));
      row.checks.receiver_completed=false;
    } finally {
      if(context)await context.close();
    }
    reports.push(row);
    await fs.writeFile(path.join(output,"partial.json"),JSON.stringify(reports,null,2)+"\n");
    console.log(JSON.stringify({name,failed:Object.keys(row.checks).filter(k=>!row.checks[k])}));
  }
} finally {
  await browser.close();
}
const report={schema:"testpilot-html-browser-receiving-v1",phase,
  driver:"receive_html.mjs",driver_sha256:sha(await fs.readFile(new URL(import.meta.url))),
  playwrightPath,browser:browserVersion,node:process.version,platform:process.platform,arch:process.arch,
  startedAt,finishedAt:new Date().toISOString(),
  cases:reports,case_count:reports.length,
  case_passed:reports.filter(r=>Object.values(r.checks).every(Boolean)).length,
  case_failed:reports.filter(r=>!Object.values(r.checks).every(Boolean)).length,
  checks:reports.reduce((n,r)=>n+Object.keys(r.checks).length,0)};
await fs.writeFile(path.join(output,"summary.json"),JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify({complete:true,cases:report.case_count,passed:report.case_passed,failed:report.case_failed,checks:report.checks}));
process.exitCode=report.case_failed?1:0;

