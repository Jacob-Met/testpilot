"""Actual CLI receiver; its inputs and expectations predate candidate inspection."""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

def digest(path):
    b = path.read_bytes()
    return {"bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def source_snapshot(source):
    return [{"path": p.relative_to(source).as_posix(), **digest(p)}
            for p in sorted(source.rglob("*")) if p.is_file()
            and not any(part in {"__pycache__", ".pytest_cache", ".git"} for part in p.parts)
            and p.name != ".coverage"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--python", required=True)
    ap.add_argument("--phase", required=True)
    args = ap.parse_args()
    args.root, args.source = args.root.resolve(), args.source.resolve()
    outroot = args.root / args.phase
    outroot.mkdir(parents=True, exist_ok=False)
    temp = args.root / "tmp" / args.phase
    temp.mkdir(parents=True, exist_ok=False)
    inputs = json.loads((args.root / "inputs-manifest.json").read_text())
    for row in inputs["files"]:
        if digest(args.root / row["path"]) != {k:row[k] for k in ("bytes","sha256")}:
            raise RuntimeError("Input changed: " + row["path"])
    before = source_snapshot(args.source)
    (outroot / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
    env = {k:v for k,v in os.environ.items() if not k.startswith("TESTPILOT_")}
    env.update(PYTHONPATH=str(args.source), PYTHONDONTWRITEBYTECODE="1",
               PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", TMPDIR=str(temp),
               TESTPILOT_PLANNER_MODEL="receiver-planner",
               TESTPILOT_EDITOR_MODEL="receiver-editor")
    env.pop("PYTEST_ADDOPTS", None)
    env.pop("PYTEST_PLUGINS", None)
    receipts = []
    for spec in inputs["cases"]:
        name = spec["name"]
        case = args.root / "inputs" / name
        out = outroot / name
        command = [args.python, "-B", "-m", "testpilot", "run",
                   "--backend", "scripted", "--repo", str(case / "repo"),
                   "--diff", str(case / "change.diff"), "--script", str(case / "script"),
                   "--rounds", str(spec["rounds"]), "--timeout", str(spec["timeout"]),
                   "--python", args.python, "--out", str(out)]
        started = time.time()
        child = subprocess.Popen(command, cwd=args.source, env=env,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            output, _ = child.communicate(timeout=max(30, spec["timeout"] * 4 + 10))
        except subprocess.TimeoutExpired:
            child.kill()
            output, _ = child.communicate()
            (outroot / (name + ".outer-timeout.log")).write_bytes(output)
            raise RuntimeError("Outer receiver timeout in " + name)
        log = outroot / (name + ".cli.log")
        log.write_bytes(output)
        record = {"name":name, "pid":child.pid, "argv":command, "cwd":str(args.source),
                  "started_utc_epoch":started, "elapsed_s":time.time()-started,
                  "exit_code":child.returncode, "log":digest(log), "checks":{}}
        checks = record["checks"]
        checks["expected_cli_exit"] = child.returncode == spec["expected_exit"]
        originals = ["report.json", "report.md", "testpilot.patch"]
        checks["three_original_artifacts"] = all((out / x).is_file() for x in originals)
        if checks["three_original_artifacts"]:
            data = json.loads((out / "report.json").read_text())
            record["status"] = data["status"]
            record["files"] = {x:digest(out/x) for x in originals}
            checks["expected_report_status"] = data["status"] == spec["expected_status"]
            checks["repair_count"] = data["repair_rounds_used"] == spec["expected_repairs"]
            checks["round_count"] = len(data["rounds"]) == spec["expected_rounds"]
            checks["scripted_ledger"] = all(x["estimated"] for x in data["ledger"]["entries"])
            if data["ledger"]["entries"]:
                checks["unpriced_ledger"] = data["ledger"]["cost_is_complete"] is False
            if "expected_generated" in spec:
                checks["generated_case_counts"] = data["final"]["generated"] == spec["expected_generated"]
            if spec.get("expected_final_none"):
                checks["final_not_invented"] = data["final"] is None
            if "expected_junit" in spec:
                checks["junit_availability"] = data["final"]["junit_available"] is spec["expected_junit"]
            if spec.get("expected_output_tail"):
                final = data["final"]
                checks["actual_timeout"] = final["timed_out"] is True and final["returncode"] is None
                checks["coverage_unavailable"] = final["coverage"] is None and data["coverage"] is None
                checks["stored_output_is_tail"] = (len(final["output"]) == 3000
                    and "RETAINED-TAIL-雪" in final["output"]
                    and "NOT-IN-RETAINED-OUTPUT-" not in final["output"])
            if spec.get("expected_collision"):
                mapped = spec["expected_collision"]
                checks["mapped_file_reported"] = mapped in data["test_files"]
                checks["partial_repair_history"] = (data["rounds"][0]["contents"][mapped]
                    != data["rounds"][1]["contents"][mapped]
                    and data["rounds"][0]["contents"]["tests/test_retained.py"]
                    == data["rounds"][1]["contents"]["tests/test_retained.py"])
                checks["collision_warning_retained"] = any(mapped in w for w in data["rounds"][0]["warnings"])
            checks["actual_html_emitted"] = (out / "report.html").is_file()
            if checks["actual_html_emitted"]:
                record["html"] = digest(out / "report.html")
        receipts.append(record)
        (outroot / "cli-receipt.json").write_text(json.dumps(receipts, indent=2) + "\n")
        print(json.dumps({"name":name, "status":record.get("status"), "exit":child.returncode,
                          "failed_checks":[k for k,v in checks.items() if not v]}), flush=True)
    after = source_snapshot(args.source)
    (outroot / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
    summary = {"schema":"testpilot-html-cli-receiving-v1", "phase":args.phase,
               "source":str(args.source), "python":sys.version, "platform":platform.platform(),
               "wrapper_executable":sys.executable, "pytest":importlib.metadata.version("pytest"),
               "coverage":importlib.metadata.version("coverage"),
               "source_unchanged":before == after, "cases":receipts,
               "case_count":len(receipts),
               "case_passed":sum(all(r["checks"].values()) for r in receipts),
               "case_failed":sum(not all(r["checks"].values()) for r in receipts)}
    (outroot / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    if before != after:
        raise RuntimeError("Source changed during receiver execution")
    print(json.dumps({"complete":True,"cases":len(receipts),"passed":summary["case_passed"],
                      "failed":summary["case_failed"],"source_unchanged":True}),flush=True)
    return 0 if summary["case_failed"] == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())

