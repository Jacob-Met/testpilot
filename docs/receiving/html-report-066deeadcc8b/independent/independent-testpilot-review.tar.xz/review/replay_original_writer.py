"""Replay the unchanged original writer on a result captured from an actual CLI."""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline-source", type=Path, required=True)
    ap.add_argument("--reference", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists():
        raise RuntimeError("Refusing to overwrite a prior writer replay")
    sys.path.insert(0, str(args.baseline_source.resolve()))
    from testpilot.loop import LoopResult, RoundRecord, write_outputs
    captured = json.loads((args.reference / "report.json").read_text())
    fields = dict(captured)
    fields.pop("ok")
    fields["rounds"] = [RoundRecord(**row) for row in fields["rounds"]]
    result = LoopResult(**fields)
    if result.to_dict() != captured:
        raise RuntimeError("Reference result was not reconstructed exactly")
    written = write_outputs(result, args.out)
    if set(written) != {"patch","json","md"}:
        raise RuntimeError("Original baseline writer interface changed")
    names = ["report.json","testpilot.patch","report.md"]
    comparisons = []
    for name in names:
        old, reference = (args.out/name).read_bytes(), (args.reference/name).read_bytes()
        comparisons.append({"path":name, "bytes":len(old), "equal":old==reference,
                            "sha256":hashlib.sha256(reference).hexdigest()})
    report = {"schema":"testpilot-html-original-writer-replay-v1",
              "baseline_source":str(args.baseline_source.resolve()),
              "reference":str(args.reference.resolve()), "files":comparisons}
    (args.out/"writer-verification.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report))
    if not all(row["equal"] for row in comparisons):
        raise RuntimeError("The original three artifact bytes changed")

if __name__ == "__main__":
    main()

