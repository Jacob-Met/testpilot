from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path("/Users/me/testpilot-html-review-066deeadcc8b")
expected=[{"name":"prepare_inputs.py","bytes":5965,"sha256":"ef4d5e61c5471a164eecb91a44f965ddb6d94f85a37b570184285a33ff45d366"},{"name":"prepare_inputs_v2.py","bytes":6000,"sha256":"e7b71e524efeaac61bf20b3fe3c2032495c4ed3131298f59145ef1d20758d8be"},{"name":"run_cli.py","bytes":7605,"sha256":"f23d84c0257222c89ee88f28b240f21b29f212a50e8bf6c994f07053e8120c42"},{"name":"replay_original_writer.py","bytes":2040,"sha256":"26c6399bc48269394433420aa2e32730f881085f37984747123af4cc4bdf1991"},{"name":"receive_html.mjs","bytes":12258,"sha256":"0ab5635f2b5fcfc76836f4abba7c689b65f0438864031797898c788a0e9dd7e1"}]
for row in expected:
    b=(root/row["name"]).read_bytes()
    if len(b)!=row["bytes"] or hashlib.sha256(b).hexdigest()!=row["sha256"]:
        raise RuntimeError("Control source mismatch: "+row["name"])
final=root/"final"
final.mkdir()
freeze={"schema":"independent-receiver-controls-v1","frozen_utc_epoch":time.time(),"candidate_source_inspected":False,"files":expected,"notes":["Original timeout fixture and baseline remain under the parent root.","The v2 fixture uses capfd.disabled because canonical sandbox resets pytest addopts."]}
(final/"controls-freeze.json").write_text(json.dumps(freeze,indent=2)+"\n")
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1")
python="/Users/me/testpilot-html-066deeadcc8b/venv/bin/python"
records=[]
def run(name,argv,allowed):
    log=final/(name+".log")
    started=time.time()
    with log.open("wb") as f:
        p=subprocess.Popen(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
        code=p.wait(timeout=180)
    b=log.read_bytes()
    row={"name":name,"argv":argv,"cwd":str(root),"pid":p.pid,"exit_code":code,"started_utc_epoch":started,"elapsed_s":time.time()-started,"log":{"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}}
    records.append(row)
    (final/"baseline-execution.json").write_text(json.dumps(records,indent=2)+"\n")
    print(json.dumps(row),flush=True)
    if code not in allowed: raise RuntimeError("Unexpected child exit: "+name)
run("prepare-inputs",[python,"-B",str(root/"prepare_inputs_v2.py"),str(final)],[0])
run("browser-syntax",["/opt/homebrew/bin/node","--check",str(root/"receive_html.mjs")],[0])
run("baseline-cli-launch",[python,"-B",str(root/"run_cli.py"),"--root",str(final),"--source",str(root/"baseline"),"--python",python,"--phase","baseline-cli"],[1])
run("baseline-browser-launch",["/opt/homebrew/bin/node",str(root/"receive_html.mjs"),str(final),"baseline-cli"],[1])
for name in ["baseline-cli","baseline-cli-browser"]:
    s=json.loads((final/name/"summary.json").read_text())
    print(json.dumps({"name":name,"cases":s["case_count"],"passed":s["case_passed"],"failed":s["case_failed"],"failed_checks":{r["name"]:[k for k,v in r["checks"].items() if not v] for r in s["cases"]}}),flush=True)
