from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path("/Users/me/testpilot-html-review-066deeadcc8b")
final=root/"final"
freeze=json.loads((final/"controls-freeze.json").read_text())
for row in freeze["files"]:
    b=(root/row["name"]).read_bytes()
    if len(b)!=row["bytes"] or hashlib.sha256(b).hexdigest()!=row["sha256"]: raise RuntimeError("Changed receiver: "+row["name"])
m=json.loads((root/"candidate-source-manifest.json").read_text())
original=Path("/Users/me/testpilot-html-066deeadcc8b/source")
source=root/"candidate"
source.mkdir()
custody=[]
for row in m["files"]:
    rel=row["path"]
    b=(original/rel).read_bytes()
    if len(b)!=row["bytes"] or hashlib.sha256(b).hexdigest()!=row["sha256"]:raise RuntimeError("Author source freeze mismatch: "+rel)
    if hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()!=row["git_blob"]:raise RuntimeError("Git blob mismatch: "+rel)
    p=source/rel
    if not p.resolve().is_relative_to(source.resolve()):raise RuntimeError("Unsafe path")
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b)
    if p.read_bytes()!=b:raise RuntimeError("Source copy mismatch")
    custody.append(row)
(final/"candidate-source-custody.json").write_text(json.dumps({"source":str(original),"receiver":str(source),"copied_utc_epoch":time.time(),"manifest_head":m["local_projection_head"],"files":custody},indent=2)+"\n")
python="/Users/me/testpilot-html-066deeadcc8b/venv/bin/python"
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1")
records=[]
def run(name,argv,timeout=240):
    log=final/(name+".log")
    started=time.time()
    with log.open("wb") as f:
        p=subprocess.Popen(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill();code=p.wait();raise
    b=log.read_bytes()
    row={"name":name,"argv":argv,"cwd":str(root),"pid":p.pid,"exit_code":code,"started_utc_epoch":started,"elapsed_s":time.time()-started,"log":{"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}}
    records.append(row)
    (final/"candidate-execution.json").write_text(json.dumps(records,indent=2)+"\n")
    print(json.dumps(row),flush=True)
    return code
run("candidate-cli-launch",[python,"-B",str(root/"run_cli.py"),"--root",str(final),"--source",str(source),"--python",python,"--phase","candidate-cli"])
inputs=json.loads((final/"inputs-manifest.json").read_text())
for spec in inputs["cases"]:
    name=spec["name"]
    run("original-writer-"+name,[python,"-B",str(root/"replay_original_writer.py"),"--baseline-source",str(root/"baseline"),"--reference",str(final/"candidate-cli"/name),"--out",str(final/"original-writer"/name)])
run("candidate-browser-launch",["/opt/homebrew/bin/node",str(root/"receive_html.mjs"),str(final),"candidate-cli"])
for row in custody:
    if hashlib.sha256((source/row["path"]).read_bytes()).hexdigest()!=row["sha256"]:raise RuntimeError("Candidate changed during review")
for name in ["candidate-cli","candidate-cli-browser"]:
    s=json.loads((final/name/"summary.json").read_text())
    print(json.dumps({"name":name,"cases":s["case_count"],"passed":s["case_passed"],"failed":s["case_failed"],"checks":s.get("checks"),"failed_checks":{r["name"]:[k for k,v in r["checks"].items() if not v] for r in s["cases"]}}),flush=True)
