"""Prepare authored receiver inputs; no TestPilot implementation imports."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path

LITERAL = 'RECEIVER-λ-雪-café-🧭 </script><img id="receiver-injected" src="https://receiver.invalid/no-fetch"> & <details>literal</details>'
PLAN = "Check the authored function and preserve this literal plan: " + LITERAL
FUNCTION = 'def transform(value):\n    """' + LITERAL + '"""\n    if value < 0:\n        return 0\n    return value + 1\n'
EXISTING = "from sample import transform\n\ndef test_existing():\n    assert transform(0) == 1\n"

def fence(path, source):
    return "```python path=" + path + "\n" + source + "```\n"

def put(root, rel, data):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(data, encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    args = ap.parse_args()
    target = args.root / "inputs"
    target.mkdir(parents=True, exist_ok=False)
    common = {
        "source": FUNCTION, "existing": EXISTING,
        "old": FUNCTION.replace("return value + 1", "return value + 0"),
        "rounds": 0, "timeout": 5.0,
    }
    cases = []
    def add(name, expected_status, replies, **overrides):
        entry = {**common, **overrides, "name": name, "expected_status": expected_status,
                 "expected_exit": 0 if expected_status == "passed" else 1, "replies": replies}
        cases.append(entry)

    unicode_tests = (
        "import pytest\nfrom sample import transform\n\n"
        "# Literal generated source: " + LITERAL + "\n"
        "@pytest.mark.parametrize('value, expected', [(1, 2), (-1, 0)], ids=['café', '雪'])\n"
        "def test_values(value, expected):\n    assert transform(value) == expected\n\n"
        "@pytest.mark.skip(reason='Receiver skip λ <literal>')\n"
        "def test_skipped():\n    assert False\n"
    )
    add("passed_unicode", "passed", [PLAN, fence("tests/test_generated.py", unicode_tests)],
        expected_generated={"collected": 3, "passed": 2, "failed": 0, "error": 0, "skipped": 1},
        expected_repairs=0, expected_rounds=1)

    wrong = "from sample import transform\n\ndef test_collision():\n    assert transform(2) == 99\n"
    corrected = wrong.replace("== 99", "== 3")
    retained = "from sample import transform\n\ndef test_retained():\n    assert transform(-3) == 0\n"
    add("repaired_partial", "passed",
        [PLAN, fence("tests/test_existing.py", wrong) + fence("tests/test_retained.py", retained),
         fence("tests/test_existing.py", corrected)],
        rounds=1, expected_generated={"collected": 2, "passed": 2, "failed": 0, "error": 0, "skipped": 0},
        expected_repairs=1, expected_rounds=2, expected_collision="tests/test_existing_testpilot.py")

    bug_source = FUNCTION.replace("return value + 1", "return value + 2")
    bug_existing = EXISTING.replace("== 1", "== 2")
    bug_test = "from sample import transform\n\ndef test_expected_increment():\n    assert transform(2) == 3\n"
    add("suspected_bug", "suspected_code_bug",
        [PLAN, fence("tests/test_bug.py", bug_test), "VERDICT: CODE_BUG\nReported suspicion only. " + LITERAL],
        source=bug_source, existing=bug_existing, old=FUNCTION, rounds=1,
        expected_generated={"collected": 1, "passed": 0, "failed": 1, "error": 0, "skipped": 0},
        expected_repairs=1, expected_rounds=2)

    waiting = (
        "import time\n\ndef test_waiting(capfd):\n"
        "    with capfd.disabled():\n"
        "        print('NOT-IN-RETAINED-OUTPUT-' + 'x' * 5200 + '-RETAINED-TAIL-雪', flush=True)\n"
        "        time.sleep(10)\n"
    )
    add("timeout_tail", "failed", [PLAN, fence("tests/test_waiting.py", waiting)],
        timeout=1.5, expected_repairs=0, expected_rounds=1,
        expected_junit=False, expected_output_tail=True)

    skipped = "import pytest\n\n@pytest.mark.skip(reason='Receiver all skipped <literal>')\ndef test_skip_only():\n    assert False\n"
    add("no_generated_pass", "no_tests", [PLAN, fence("tests/test_skip.py", skipped)],
        expected_generated={"collected": 1, "passed": 0, "failed": 0, "error": 0, "skipped": 1},
        expected_repairs=0, expected_rounds=1)

    add("no_changes", "no_changes", ["Unused receiver script"], empty_diff=True,
        expected_final_none=True, expected_repairs=0, expected_rounds=0)
    add("model_error", "model_error", [PLAN], expected_final_none=True,
        expected_repairs=0, expected_rounds=0)

    specs = []
    for c in cases:
        root = target / c["name"]
        put(root, "repo/sample.py", c["source"])
        put(root, "repo/tests/test_existing.py", c["existing"])
        if c.get("no_capture"):
            put(root, "repo/pytest.ini", "[pytest]\naddopts = -s\n")
        diff = "" if c.get("empty_diff") else "".join(difflib.unified_diff(
            c["old"].splitlines(True), c["source"].splitlines(True),
            fromfile="a/sample.py", tofile="b/sample.py"))
        put(root, "change.diff", diff)
        for i, reply in enumerate(c["replies"], 1):
            put(root, f"script/{i:02d}.md", reply + ("" if reply.endswith("\n") else "\n"))
        specs.append({k: v for k, v in c.items() if k not in {"source", "existing", "old", "replies"}})
    manifest = [{"path": p.relative_to(args.root).as_posix(), "bytes": p.stat().st_size,
                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                for p in sorted(target.rglob("*")) if p.is_file()]
    payload = {"schema": "testpilot-html-independent-inputs-v1", "literal": LITERAL,
               "cases": specs, "files": manifest}
    (args.root / "inputs-manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                                                  encoding="utf-8")
    print(json.dumps({"cases": len(specs), "input_files": len(manifest)}))

if __name__ == "__main__":
    main()

