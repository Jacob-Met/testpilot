from pathlib import Path
import hashlib, io, json, tarfile
root = Path('/Users/me/testpilot-html-066deeadcc8b')
entries = {}
for source_dir, prefix in [('pr20-source','source'),('evidence/pr20-cli','cli'),('evidence/pr20-browser','browser')]:
    for path in sorted((root/source_dir).rglob('*')):
        rel=path.relative_to(root/source_dir)
        if any(x in rel.parts for x in ['.git','__pycache__','.pytest_cache']):
            continue
        if path.is_symlink():
            raise ValueError(str(path))
        if path.is_file():
            entries[prefix+'/'+rel.as_posix()]=path.read_bytes()
for source_path,target in {
    'pr20-parent-loop.py':'upstream/testpilot/loop.py',
    'pr20-parent-README.md':'upstream/README.md',
    'pr20-source-manifest.json':'source-manifest.json',
    'pr20-current-tree-blobs.json':'current-tree-blobs.json',
    'capture_allocator_compatibility.py':'capture_allocator_compatibility.py',
    'check_browser-v2.mjs':'check_browser.mjs',
    'pr20-composition-run.py':'run_native.py',
    'pr20-package.py':'package_native.py',
    'evidence/pr20-html-tests.log':'commands/focused-tests.log',
    'evidence/pr20-cli.log':'commands/cli.log',
    'evidence/pr20-browser.log':'commands/browser.log',
    'evidence/pr20-composition-commands.json':'commands/invocations.json',
    'evidence/pr20-composition-custody.json':'commands/source-custody.json',
    'evidence/packaging-environment.json':'commands/environment.json',
    'own-suite-dependency-recovery.json':'commands/own-dependency-recovery.json',
}.items():
    entries[target]=(root/source_path).read_bytes()
manifest=json.loads(entries['source-manifest.json'])
tree=json.loads(entries['current-tree-blobs.json'])
leaves={x['path']:x for x in tree['tree']}
for row in manifest['files']:
    data=entries['source/'+row['path']]
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
for path in ['README.md','testpilot/loop.py']:
    data=entries['upstream/'+path]
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==leaves[path]['sha'],path
artifacts=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]
raw=(json.dumps({'schema':'testpilot.html_report.pr20_native_packet.v1','base':manifest['base'],'tree':manifest['tree'],'source_files':80,'artifacts':artifacts,'artifact_count':len(artifacts),'interpretation':'A bounded supplement to the frozen fe791af1/dc9735cb author and independent packets. Exact current allocator source and README text are preserved. Native 19 focused tests and two real ScriptedModel CLI cases pass; unchanged browser driver reports 39 checks. Source before/after is stable. No broader receiving suite or provider run is claimed.'},indent=2)+'\n').encode()
entries['native-manifest.json']=raw
archive_path=root/'pr20-native.tar.xz'
with tarfile.open(archive_path,'w:xz',preset=6) as archive:
    for name,data in sorted(entries.items()):
        m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;m.mtime=0;archive.addfile(m,io.BytesIO(data))
(root/'pr20-native-manifest.json').write_bytes(raw)
archive=archive_path.read_bytes()
out={'archive':{'path':str(archive_path),'bytes':len(archive),'sha256':hashlib.sha256(archive).hexdigest(),'members':len(entries)},'manifest':{'path':str(root/'pr20-native-manifest.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'artifacts':len(artifacts)}}
(root/'pr20-native-transfer.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
