import pytest

@pytest.fixture
def operand():
    return 3
