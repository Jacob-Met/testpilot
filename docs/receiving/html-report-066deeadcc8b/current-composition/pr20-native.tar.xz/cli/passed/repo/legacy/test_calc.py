from m import double

def test_existing():
    assert double(2) == 4
