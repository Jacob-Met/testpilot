from pathlib import Path
import base64, hashlib, io, json, os, subprocess, sys, tarfile, time
root = Path('/Users/me/testpilot-html-066deeadcc8b')
raw = base64.b64decode((root/'pr20-source.tar.gz.b64').read_bytes(), validate=True)
assert len(raw) == 75756 and hashlib.sha256(raw).hexdigest() == '4b0568408f24b941ecca9b2f8c4f30d5b257c14fb343d94f9449b20164844c6a'
manifest_bytes = (root/'pr20-source-manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == '510f4dc179c71970444e4e97389272b763b1ce3b1f6229d86e13c6a08769b29a'
manifest = json.loads(manifest_bytes)
source = root/'pr20-source'
source.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(manifest['files']) == 80
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    assert len({m.name for m in members}) == len(members)
    for member in members:
        target = source/member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.extractfile(member).read())
def verify():
    for row in manifest['files']:
        data = (source/row['path']).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    return {'files': len(manifest['files']), 'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest()}
before = verify()
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TESTPILOT_PLAYWRIGHT_MODULE'] = '/Users/me/suite-projects-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs'
env['TESTPILOT_BROWSER_EXECUTABLE'] = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
commands = [
    ('pr20-html-tests', [str(root/'venv/bin/python'), '-B', '-m', 'pytest', 'tests/test_html_report.py', '-q', '-p', 'no:cacheprovider']),
    ('pr20-cli', [str(root/'venv/bin/python'), '-B', str(root/'capture_allocator_compatibility.py'), '--source', str(source), '--python', str(root/'venv/bin/python'), '--output', str(root/'evidence/pr20-cli'), '--expect-html']),
    ('pr20-browser', ['/opt/homebrew/bin/node', str(root/'check_browser-v2.mjs'), str(root/'evidence/pr20-cli'), str(root/'evidence/pr20-browser')]),
]
receipts = []
for name, argv in commands:
    started = time.monotonic()
    with (root/'evidence'/f'{name}.log').open('wb') as log:
        result = subprocess.run(argv, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
    receipts.append({'name': name, 'argv': argv, 'cwd': str(source), 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-started})
    (root/'evidence/pr20-composition-commands.json').write_text(json.dumps(receipts, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
after = verify()
(root/'evidence/pr20-composition-custody.json').write_text(json.dumps({'before': before, 'after': after, 'base': manifest['base'], 'tree': manifest['tree'], 'source_files_unchanged': before==after, 'interpretation': manifest['interpretation']}, indent=2)+'\n')
print('80 source files unchanged; allocator/HTML composition completed', flush=True)
