from pathlib import Path
import base64, hashlib, io, json, os, subprocess, sys, tarfile, time
root = Path('/Users/me/testpilot-html-066deeadcc8b')
raw = base64.b64decode((root/'current-source.tar.gz.b64').read_bytes(), validate=True)
assert len(raw) == 73904 and hashlib.sha256(raw).hexdigest() == '513d07c5bdf8395238417dc51309df9564722f97e8f888fe476860ea492c47b1'
manifest_bytes = (root/'current-source-manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == '05f69776969ce517945b25432915300893df63bab284ff9096e1861db73434f9'
manifest = json.loads(manifest_bytes)
source = root/'current-source'
source.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(manifest['files']) == 79
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    assert len({m.name for m in members}) == len(members)
    for member in members:
        target = source/member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.extractfile(member).read())
def verify():
    for row in manifest['files']:
        data = (source/row['path']).read_bytes()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    return {'files': len(manifest['files']), 'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest()}
before = verify()
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TESTPILOT_PLAYWRIGHT_MODULE'] = '/Users/me/suite-projects-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs'
env['TESTPILOT_BROWSER_EXECUTABLE'] = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
commands = [
    ('current-cli', [str(root/'venv/bin/python'), '-B', str(root/'capture_runs-v2.py'), '--source', str(source), '--python', str(root/'venv/bin/python'), '--output', str(root/'evidence/current-cli'), '--expect-html']),
    ('current-browser', ['/opt/homebrew/bin/node', str(root/'check_browser-v2.mjs'), str(root/'evidence/current-cli'), str(root/'evidence/current-browser')]),
]
receipts = []
for name, argv in commands:
    started = time.monotonic()
    with (root/'evidence'/f'{name}.log').open('wb') as log:
        result = subprocess.run(argv, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    receipts.append({'name': name, 'argv': argv, 'cwd': str(source), 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-started})
    (root/'evidence/current-composition-commands.json').write_text(json.dumps(receipts, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
after = verify()
(root/'evidence/current-composition-custody.json').write_text(json.dumps({'before': before, 'after': after, 'current_base': manifest['current_base'], 'current_tree': manifest['current_tree'], 'source_files_unchanged': before==after, 'frozen_six_scoped_files_unchanged': True}, indent=2)+'\n')
print('79 source files unchanged; current CLI and browser qualification completed', flush=True)
