"""Preserve ordinary authored source/evidence bytes; never archive dependencies or Git metadata."""
from pathlib import Path
import hashlib, io, json, tarfile, base64
root = Path('/Users/me/testpilot-html-066deeadcc8b')
excluded_parts = {'.git', '__pycache__', '.pytest_cache'}
entries = {}
for folder in ['baseline', 'source', 'current-source', 'evidence']:
    for file in sorted((root/folder).rglob('*')):
        relative = file.relative_to(root)
        if any(part in excluded_parts for part in relative.parts):
            continue
        if file.is_symlink():
            raise RuntimeError('Unexpected symbolic link: '+str(relative))
        if file.is_file():
            entries[relative.as_posix()] = file.read_bytes()
for name in ['base-tree.json', 'current-tree.json', 'baseline-source-manifest.json',
             'candidate-source-manifest.json', 'current-source-manifest.json',
             'baseline-source.tar.gz', 'environment-install.json', 'environment-install.log',
             'capture_runs.py', 'capture_runs-v2.py', 'check_browser.mjs', 'check_browser-v2.mjs',
             'capture_literal.py', 'check_literal.mjs', 'current-composition-run.py', 'package-native.py']:
    entries[name] = (root/name).read_bytes()
entries['current-source.tar.gz'] = base64.b64decode((root/'current-source.tar.gz.b64').read_bytes(), validate=True)
for manifest_path, source_prefix, bytes_field, blob_field in [
    ('baseline-source-manifest.json', 'baseline', 'size', 'sha'),
    ('candidate-source-manifest.json', 'source', 'bytes', 'git_blob'),
    ('current-source-manifest.json', 'current-source', 'bytes', 'git_blob'),
]:
    manifest = json.loads(entries[manifest_path])
    for row in manifest['files']:
        data = entries[source_prefix+'/'+row['path']]
        assert len(data) == row[bytes_field]
        assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == row[blob_field]
artifacts = [{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]
manifest = {
    'schema':'testpilot.html_report.author_native_packet.v1',
    'author':'/root/product_execution',
    'native_root':str(root),
    'repository':'Jacob-Met/testpilot',
    'claim':'https://github.com/Jacob-Met/testpilot/issues/17',
    'baseline_commit':'d7c28b0ad261e78d681f40e355447dffa4d435ed',
    'frozen_projection':'fe791af1a0908b2379dd7cbb87a9fb8f3cad87de',
    'current_composition_base':'dc9735cbbd9c271bdf2bc68656aff1f56d88c0fa',
    'artifact_count':len(artifacts),
    'artifacts':artifacts,
    'exclusions':['Dependencies/venv','Disposable .git metadata','__pycache__','.pytest_cache','Base64 transfer intermediates'],
    'interpretation':'Exact ordinary source, authored fixtures, commands, reports, downloaded bytes, screenshots, PDF, initial observer failure and before-phone rendering are retained. All native qualification uses explicit ScriptedModel; configured model names are routing labels, not provider execution evidence. No installed runtime or external repository was exercised as a test project.',
}
raw_manifest = (json.dumps(manifest,indent=2)+'\n').encode()
entries['native-manifest.json'] = raw_manifest
archive_path = root/'author-native.tar.xz'
with tarfile.open(archive_path,'w:xz',preset=6) as archive:
    for name,data in sorted(entries.items()):
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        archive.addfile(member,io.BytesIO(data))
(root/'author-native-manifest.json').write_bytes(raw_manifest)
archive_bytes = archive_path.read_bytes()
receipt = {'archive':{'path':str(archive_path),'bytes':len(archive_bytes),'sha256':hashlib.sha256(archive_bytes).hexdigest(),'ordinary_members':len(entries)},'manifest':{'path':str(root/'author-native-manifest.json'),'bytes':len(raw_manifest),'sha256':hashlib.sha256(raw_manifest).hexdigest(),'artifacts':len(artifacts)}}
(root/'author-native-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
