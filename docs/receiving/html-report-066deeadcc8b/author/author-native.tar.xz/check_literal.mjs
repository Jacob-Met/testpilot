import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {chromium} from '/Users/me/suite-projects-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs';
const root='/Users/me/testpilot-html-066deeadcc8b/evidence';
const dir=path.join(root,'literal-browser');await fs.mkdir(dir,{recursive:false});
const source=path.join(root,'literal-cli/passed/out');
const bytes=await fs.readFile(path.join(source,'report.html'));
const original=await fs.readFile(path.join(source,'report.json'));const data=JSON.parse(original);
await fs.writeFile(path.join(dir,'record.html'),bytes);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const report={schema:'testpilot.html_report.literal_browser.v1',htmlSha256:sha(bytes),reportSha256:sha(original),checks:[],requests:[],errors:[]};
const check=(label,actual,expected)=>{const passed=JSON.stringify(actual)===JSON.stringify(expected);report.checks.push({label,actual,expected,passed});if(!passed)throw Error(label);};
const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
let context;
try{
context=await browser.newContext({viewport:{width:1200,height:850},acceptDownloads:true});
await context.route('**/*',async r=>{if(/^https?:/.test(r.request().url())){report.requests.push(r.request().url());await r.abort();}else await r.continue();});
const page=await context.newPage();page.on('pageerror',e=>report.errors.push(String(e)));
await page.goto(pathToFileURL(path.join(dir,'record.html')).href);
check('actual model plan remains literal',await page.locator('#scope > pre code').textContent(),data.plan);
check('no script or image element',await page.locator('script,img,iframe,object,embed').count(),0);
check('script text did not execute',await page.evaluate(()=>typeof window.testpilotInjected),'undefined');
await page.locator('#tests > details > summary').click();
check('actual generated source remains literal',await page.locator('#tests > details pre code').textContent(),data.test_files['tests/test_generated.py']);
for(const name of ['report.json','testpilot.patch']){
const pending=page.waitForEvent('download');await page.locator('a[download="'+name+'"]').click();const d=await pending;await d.saveAs(path.join(dir,name));
check('literal exact download '+name,sha(await fs.readFile(path.join(dir,name))),sha(await fs.readFile(path.join(source,name))));}
await page.locator('#scope').screenshot({path:path.join(dir,'literal-plan.png')});
await page.setViewportSize({width:375,height:812});
check('literal phone no document overflow',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
await page.locator('#tests').screenshot({path:path.join(dir,'literal-tests-phone.png')});
check('no external request',report.requests,[]);check('no application error',report.errors,[]);
report.browser=browser.version();report.passed=report.checks.length;
}catch(e){report.failure=String(e.stack||e);process.exitCode=1}
finally{await context?.close();await browser.close();await fs.writeFile(path.join(dir,'report.json.receipt'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({checks:report.checks.length,passed:report.checks.filter(x=>x.passed).length,failure:report.failure}));}
