from m import double

def test_existing():
    assert callable(double)
