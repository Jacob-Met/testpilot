@deco(
    'Ω',
)
def outer(x):
    def inner():
        return 'inner'
    return inner()

class Box:
    @classmethod
    async def go(cls):
        return 'x y'

if True:
    def shadow():
        return 1
else:
    def shadow():
        return 2
try:
    pass
except Exception:
    def caught():
        return 3
finally:
    def finished():
        return 4
match 0:
    case 0:
        def branch():
            return 5
