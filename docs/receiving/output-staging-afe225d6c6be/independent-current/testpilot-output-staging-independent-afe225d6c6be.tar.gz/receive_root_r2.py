from pathlib import Path
import errno,hashlib,json,os,subprocess,sys,datetime
root=Path('/dev/testpilot-root-afe225d6c6be')
prior=json.loads((root/'independent-receiving.json').read_text())
assert prior['child_observations']==24 and prior['source_unchanged']
assert len(prior['failures'])==12
assert all(x['scenario'].startswith('bytes_') and x['reason'] in ('successful write','exact baseline/candidate bytes and retained modes','mapping compatibility') for x in prior['failures'])
observations={};failures=[];processes=[]
for variant in ('baseline','candidate'):
 for scenario in ('bytes_0','bytes_1','bytes_2','bytes_3'):
  case=root/'observations-r2'/variant/scenario
  command=[sys.executable,str(root/'receive_child_r2.py'),str(root/variant),str(case),scenario]
  p=subprocess.run(command,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','TMPDIR':str(root/'tmp')},capture_output=True,text=True,timeout=20)
  case.mkdir(parents=True,exist_ok=True);(case/'stdout.log').write_text(p.stdout);(case/'stderr.log').write_text(p.stderr)
  processes.append({'variant':variant,'scenario':scenario,'returncode':p.returncode})
  if p.returncode:failures.append({'variant':variant,'scenario':scenario,'stderr':p.stderr});continue
  observations[(variant,scenario)]=json.loads(p.stdout)
def check(value,reason,scenario):
 if not value:failures.append({'reason':reason,'scenario':scenario})
for scenario in ('bytes_0','bytes_1','bytes_2','bytes_3'):
 base=observations.get(('baseline',scenario));cand=observations.get(('candidate',scenario))
 if not base or not cand:continue
 check(not base['error'] and not cand['error'],'both variants succeed',scenario)
 check(base['after']==cand['after'],'exact existing-output bytes and modes',scenario)
 check(base['returned_mapping']==cand['returned_mapping'],'same returned path mapping',scenario)
 check(all(cand['new_bytes_match'].values()) and all(cand['inline_downloads_match_files'].values()),'all files and embedded downloads exact',scenario)
 check(base['fresh_modes']==cand['fresh_modes']==dict.fromkeys(('patch','json','md','html'),0o640),'new output umask modes match',scenario)
 check(base['fresh_bytes']==cand['fresh_bytes'],'new output bytes match',scenario)
 check(not cand['staging_leftovers'],'no staging leftovers',scenario)
# The original read-only cases are a real filesystem semantic boundary, not a product failure.
for scenario in ('bytes_0','bytes_1','bytes_2','bytes_3'):
 base=json.loads((root/'observations/baseline'/scenario/'observation.json').read_text())
 cand=json.loads((root/'observations/candidate'/scenario/'observation.json').read_text())
 check(base['error'] and base['error']['errno']==errno.EACCES,'read-only baseline write refuses after preceding replacements',scenario)
 check(not cand['error'] and all(cand['new_bytes_match'].values()) and cand['after']['report.md']['mode']==0o444,'directory-authorized replacement preserves read-only mode',scenario)
before=json.loads((root/'source-before.json').read_text())
after={v:{p.relative_to(root/v).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/v).rglob('*')) if p.is_file()} for v in ('baseline','candidate')}
check(before==after,'all 82 baseline and 83 candidate source leaves unchanged','source')
r={'kind':'Independent output staging accepted with retained permission-boundary evidence','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_commit':prior['baseline_commit'],'baseline_tree':prior['baseline_tree'],'original_observations':24,'additional_successful_write_observations':8,'accepted_case_groups':14,'all_checks_passed':not failures,'failures':failures,'source_unchanged':before==after,'candidate_native_leaves':83,'baseline_native_leaves':82,'original_receiver_sha256':prior['receiver_sha256'],'revised_receiver_sha256':hashlib.sha256((root/'receive_child_r2.py').read_bytes()).hexdigest(),'original_receiving_sha256':hashlib.sha256((root/'independent-receiving.json').read_bytes()).hexdigest(),'correction':'The original byte-success oracle combined successful-write expectations with mode 0444. Actual baseline EACCES and candidate successful directory-authorized replacement are preserved as a distinct permission boundary. Only four successful-write cases per variant were repeated with mode 0644; all other qualified cases were reused unchanged.','permission_boundary':'Replacement authorization follows output-directory permissions. Existing mode bits are copied to the new inode; an existing read-only regular file can be replaced when its directory permits replacement.','processes':processes}
(root/'independent-accepted.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='processes'}))
sys.exit(1 if failures else 0)
