from pathlib import Path
import base64, errno, hashlib, json, os, re, resource, signal, stat, sys
from unittest.mock import patch
source=Path(sys.argv[1]); folder=Path(sys.argv[2]); scenario=sys.argv[3]
sys.path.insert(0,str(source))
from testpilot import loop
folder.mkdir(parents=True)
out=folder/'out';expected=folder/'expected'
names={'patch':'testpilot.patch','json':'report.json','md':'report.md','html':'report.html'}
def result(tag):
 return loop.LoopResult(status='failed' if tag=='old' else 'passed',changed_functions=[{'path':'a.py','qualname':'shift'}],repair_rounds_used=0,max_repair_rounds=2,test_files={'tests/test_shift.py':'def test_shift():\n    assert 1\n'},tests_written=1,final=None,patch=f'diff --git a/a.py b/a.py\n--- a/a.py\n+++ b/a.py\n@@ -1 +1 @@\n-{tag}\n+{tag} revised\n',coverage=None,ledger={'total_tokens':0,'total_cost_usd':0.0,'cost_is_complete':True,'tokens_estimated':False,'by_model':{},'entries':[]},rounds=[],plan='local receiver',message=tag)
def pin(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def snapshot():
 d={}
 if not out.exists():return d
 for p in sorted(out.iterdir()):
  mode=p.lstat().st_mode
  if p.is_symlink():d[p.name]={'kind':'symlink','target':os.readlink(p),'mode':stat.S_IMODE(mode)}
  elif p.is_file():d[p.name]={'kind':'file','mode':stat.S_IMODE(mode),**pin(p.read_bytes())}
  elif p.is_dir():d[p.name]={'kind':'directory','children':sorted(x.name for x in p.iterdir())}
  else:d[p.name]={'kind':'other','mode':mode}
 return d
old=result('old');new=result('new');error=None;returned=None
if scenario.startswith('bytes_'):
 idx=int(scenario.split('_')[1])
 new.status=['passed','failed','no_tests','model_error'][idx]
 new.patch=['','alpha\r\nbeta\rgamma\nδ🙂 <script>alert("literal")</script>\n','no-final-newline é\x00','diff --git a/x.py b/x.py\n--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n-x\n+y\n'][idx]
 new.message='Mixed \r\ncarriage\rline\nUnicode Ω🙂 and <b>literal</b>'
 new.plan='retained plan \u2028 remains JSON data'
if scenario=='efbig_patch':new.patch='P'*18000+'\n'
if scenario=='efbig_json':new.plan='J'*24000
absent=scenario=='json_error_absent'
if not absent:
 loop.write_outputs(old,out)
 (out/'README.keep').write_bytes(b'unrelated receiver-owned marker\n')
 if scenario.startswith('bytes_'):
  for key,mode in zip(names,[0o600,0o640,0o644,0o660]):(out/names[key]).chmod(mode)
 if scenario=='nonregular_directory':
  (out/'report.json').unlink();(out/'report.json').mkdir();(out/'report.json'/'keep').write_bytes(b'directory member retained')
 if scenario=='nonregular_symlink':
  (out/'report.html').unlink();(folder/'linked-target').write_bytes(b'owned linked destination retained\n');(out/'report.html').symlink_to('../linked-target')
if not scenario.startswith('json_error'):
 loop.write_outputs(new,expected)
 expected_bytes={key:(expected/name).read_bytes() for key,name in names.items()}
else:
 expected_bytes={}
 new.plan={'not JSON serializable'}
before=snapshot()
linked_before=(folder/'linked-target').read_bytes() if (folder/'linked-target').exists() else None
old_limit=resource.getrlimit(resource.RLIMIT_FSIZE)
old_signal=signal.getsignal(signal.SIGXFSZ)
if scenario.startswith('efbig_'):
 signal.signal(signal.SIGXFSZ,signal.SIG_IGN)
 resource.setrlimit(resource.RLIMIT_FSIZE,(4096,old_limit[1]))
original_chmod=Path.chmod;original_replace=Path.replace
def fail_chmod(path,mode,*args,**kwargs):
 if path.parent.name.startswith('.testpilot-') and path.name=='report.md':raise OSError(errno.EPERM,'receiver staged chmod failure',str(path))
 return original_chmod(path,mode,*args,**kwargs)
def fail_replace(path,target):
 if path.parent.name.startswith('.testpilot-') and path.name=='report.html':raise OSError(errno.ENOSPC,'receiver last replace failure',str(target))
 return original_replace(path,target)
try:
 if scenario=='chmod_failure':
  with patch.object(Path,'chmod',fail_chmod):returned=loop.write_outputs(new,out)
 elif scenario=='late_replace':
  with patch.object(Path,'replace',fail_replace):returned=loop.write_outputs(new,out)
 else:returned=loop.write_outputs(new,out)
except Exception as e:
 error={'type':type(e).__name__,'errno':getattr(e,'errno',None),'message':str(e)}
finally:
 if scenario.startswith('efbig_'):
  resource.setrlimit(resource.RLIMIT_FSIZE,old_limit);signal.signal(signal.SIGXFSZ,old_signal)
after=snapshot()
matched={key:bool((out/name).is_file() and not (out/name).is_symlink() and (out/name).read_bytes()==expected_bytes[key]) for key,name in names.items()} if expected_bytes else {}
inline={}
if not error and (out/'report.html').is_file():
 html=(out/'report.html').read_text()
 for key,pattern in [('patch',r'data:text/plain;charset=utf-8;base64,([A-Za-z0-9+/=]*)'),('json',r'data:application/json;base64,([A-Za-z0-9+/=]*)')]:
  match=re.search(pattern,html)
  inline[key]=bool(match and base64.b64decode(match.group(1))==(out/names[key]).read_bytes())
r={'scenario':scenario,'source':str(source),'python':sys.version,'error':error,'before':before,'after':after,'old_snapshot_preserved':before==after,'new_bytes_match':matched,'returned_mapping':{k:str(v.relative_to(out)) for k,v in returned.items()} if returned else None,'staging_leftovers':[p.name for p in out.glob('.testpilot-*')] if out.exists() else [],'inline_downloads_match_files':inline,'linked_target_preserved':(folder/'linked-target').read_bytes()==linked_before if linked_before is not None else None,'destination_exists':out.exists()}
if scenario.startswith('bytes_'):
 fresh=folder/'umask-new'
 prior=os.umask(0o027)
 try:loop.write_outputs(new,fresh)
 finally:os.umask(prior)
 r['fresh_modes']={key:stat.S_IMODE((fresh/name).stat().st_mode) for key,name in names.items()}
 r['fresh_bytes']={key:pin((fresh/name).read_bytes()) for key,name in names.items()}
(folder/'observation.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
