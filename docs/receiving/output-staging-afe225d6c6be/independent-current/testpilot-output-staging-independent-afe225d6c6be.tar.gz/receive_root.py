from pathlib import Path
import errno,hashlib,json,os,subprocess,sys,datetime
root=Path('/dev/testpilot-root-afe225d6c6be')
def pins(folder):
 return {p.relative_to(folder).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(folder.rglob('*')) if p.is_file()}
before={v:pins(root/v) for v in ('baseline','candidate')}
(root/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
scenarios=['bytes_0','bytes_1','bytes_2','bytes_3','efbig_patch','efbig_json','efbig_html','json_error_existing','json_error_absent','nonregular_directory','nonregular_symlink']
observations={};processes=[];failures=[]
for variant in ('baseline','candidate'):
 for scenario in scenarios+(['chmod_failure','late_replace'] if variant=='candidate' else []):
  case=root/'observations'/variant/scenario
  command=[sys.executable,str(root/'receive_child.py'),str(root/variant),str(case),scenario]
  env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','TMPDIR':str(root/'tmp')}
  p=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=20)
  case.mkdir(parents=True,exist_ok=True)
  (case/'stdout.log').write_text(p.stdout);(case/'stderr.log').write_text(p.stderr)
  processes.append({'variant':variant,'scenario':scenario,'returncode':p.returncode,'command':command})
  if p.returncode:
   failures.append({'variant':variant,'scenario':scenario,'reason':'child process failed','stderr':p.stderr});continue
  observations[(variant,scenario)]=json.loads(p.stdout)
def check(ok,label,**context):
 if not ok:failures.append({'reason':label,**context})
for scenario in scenarios:
 base=observations.get(('baseline',scenario));cand=observations.get(('candidate',scenario))
 if not base or not cand:continue
 check(not cand['staging_leftovers'],'staging cleanup',scenario=scenario)
 if scenario.startswith('bytes_'):
  check(not base['error'] and not cand['error'],'successful write',scenario=scenario)
  check(base['after']==cand['after'],'exact baseline/candidate bytes and retained modes',scenario=scenario)
  check(all(cand['new_bytes_match'].values()),'all four replaced bytes',scenario=scenario)
  check(base['returned_mapping']==cand['returned_mapping'],'mapping compatibility',scenario=scenario)
  check(all(cand['inline_downloads_match_files'].values()),'HTML embedded exact downloads',scenario=scenario)
  check(base['fresh_modes']==cand['fresh_modes']=={key:0o640 for key in ('patch','json','md','html')},'new output umask compatibility',scenario=scenario)
  check(base['fresh_bytes']==cand['fresh_bytes'],'new output byte compatibility',scenario=scenario)
 elif scenario.startswith('efbig_'):
  check(base['error'] and base['error']['errno']==errno.EFBIG,'actual baseline EFBIG',scenario=scenario)
  check(cand['error'] and cand['error']['errno']==errno.EFBIG,'actual candidate EFBIG',scenario=scenario)
  check(cand['old_snapshot_preserved'] and not base['old_snapshot_preserved'],'EFBIG protects all old output; baseline falsifies contract',scenario=scenario)
 elif scenario.startswith('json_error'):
  check(base['error'] and base['error']['type']=='TypeError' and cand['error'] and cand['error']['type']=='TypeError','actual JSON type error',scenario=scenario)
  check(cand['old_snapshot_preserved'] and not base['old_snapshot_preserved'],'JSON failure precedes replacement',scenario=scenario)
  if scenario.endswith('absent'):check(not cand['destination_exists'] and base['destination_exists'],'prepare before directory creation')
 elif scenario=='nonregular_directory':
  check(cand['error'] and cand['error']['errno']==errno.EINVAL and cand['old_snapshot_preserved'],'directory refused before replacement')
  check(base['error'] and base['error']['errno']==errno.EISDIR and not base['old_snapshot_preserved'],'baseline directory failure follows patch replacement')
 elif scenario=='nonregular_symlink':
  check(cand['error'] and cand['error']['errno']==errno.EINVAL and cand['old_snapshot_preserved'] and cand['linked_target_preserved'],'symlink refused without target writes')
  check(not base['error'] and not base['linked_target_preserved'],'baseline follows owned symlink control')
for scenario in ('chmod_failure','late_replace'):
 cand=observations.get(('candidate',scenario))
 if not cand:continue
 check(not cand['staging_leftovers'],'fault cleanup',scenario=scenario)
 if scenario=='chmod_failure':
  check(cand['error'] and cand['error']['errno']==errno.EPERM and cand['old_snapshot_preserved'],'staged mode failure precedes all replacements')
 else:
  check(cand['error'] and cand['error']['errno']==errno.ENOSPC,'late replacement error propagates')
  check(cand['new_bytes_match']=={'patch':True,'json':True,'md':True,'html':False},'documented individual replacement boundary')
after={v:pins(root/v) for v in ('baseline','candidate')}
(root/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
check(before==after,'all materialized source files remain unchanged')
summary={'kind':'Independent TestPilot output staging receiving','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_commit':'e2285d68b2ea5eb2158c0a7e0d936ce5d56f8ff5','baseline_tree':'22da6a890c2befaf72d3826103538491b07793df','baseline_native_files':len(before['baseline']),'candidate_native_files':len(before['candidate']),'canonical_leaves':955,'child_observations':len(observations),'scenario_groups':13,'source_unchanged':before==after,'all_checks_passed':not failures,'failures':failures,'processes':processes,'contract_sha256':hashlib.sha256((root/'independent-contract.json').read_bytes()).hexdigest(),'receiver_sha256':hashlib.sha256((root/'receive_child.py').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256((root/'receive_root.py').read_bytes()).hexdigest()}
(root/'independent-receiving.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='processes'}))
sys.exit(1 if failures else 0)
