"""Focused hunk-admission regressions; stdlib-only and pytest-compatible."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from testpilot.diff import DiffFormatError, changed_functions, parse_unified_diff


HEADERS = "--- a/selected.py\n+++ b/selected.py\n"
VALID = HEADERS + "@@ -1,2 +1,2 @@\n def selected():\n-    return 1\n+    return 2\n"
SOURCE = "def selected():\n    return 2\n"
GUARDED_CLI = """
import sys
import testpilot.__main__ as cli
def forbidden(*args, **kwargs):
    print("FORBIDDEN_GENERATION_EFFECT", file=sys.stderr)
    raise SystemExit(79)
cli.make_client = forbidden
cli.TestPilot = forbidden
cli.write_outputs = forbidden
raise SystemExit(cli.main(sys.argv[1:]))
"""


class HunkAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="testpilot-hunk-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        (self.repo / "selected.py").write_text(SOURCE, encoding="utf-8")
        self.env = dict(os.environ, PYTHONPATH=str(Path(__file__).resolve().parents[1]),
                        PYTHONDONTWRITEBYTECODE="1")

    def invoke(self, text, *, command="targets", stdin=False, explicit=False):
        args = [command, "--repo", str(self.repo), "--diff", "-"]
        if not stdin:
            diff = self.root / "input.diff"
            diff.write_text(text, encoding="utf-8")
            args[-1] = str(diff)
        if command == "targets":
            args += ["--json"]
            entry = ["-m", "testpilot"]
        else:
            args += ["--out", str(self.root / "saved-output")]
            entry = ["-c", GUARDED_CLI]
        if explicit:
            args += ["--target", "selected.py::selected"]
        return subprocess.run(
            [sys.executable, "-B", *entry, *args], cwd=self.root, env=self.env,
            input=text if stdin else None, capture_output=True, text=True, timeout=10,
        )

    def assert_refused(self, result, diagnostic):
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(result.stdout, "")
        self.assertIn(diagnostic, result.stderr)
        self.assertNotIn("Traceback", result.stderr)
        self.assertNotIn("FORBIDDEN_GENERATION_EFFECT", result.stderr)

    @unittest.skipUnless(shutil.which("git"), "Git is needed for the real patch control")
    def test_real_git_patch_keeps_two_functions_unicode_and_no_newline(self):
        before = "def alpha():\n    return 'old'\n\n\ndef beta():\n    return 1"
        after = "def alpha():\n    return 'left\u2028right'\n\n\ndef beta():\n    return 2"
        (self.repo / "before.py").write_text(before, encoding="utf-8")
        (self.repo / "after.py").write_text(after, encoding="utf-8")
        run = subprocess.run(
            ["git", "diff", "--no-index", "--no-color", "--no-ext-diff",
             "--no-textconv", "--src-prefix=a/", "--dst-prefix=b/", "--unified=1",
             "--", "before.py", "after.py"],
            cwd=self.repo, capture_output=True, timeout=10,
        )
        self.assertEqual(run.returncode, 1, run.stderr)
        text = run.stdout.decode("utf-8")
        self.assertIn("\\ No newline at end of file", text)
        files = parse_unified_diff(text)
        self.assertEqual([(f.path, f.added_lines) for f in files], [
            ("after.py", {2, 6})])
        functions = changed_functions(self.repo, text)
        self.assertEqual([(f.qualname, f.changed_lines) for f in functions],
                         [("alpha", [2]), ("beta", [6])])
        self.assertEqual(functions[0].source, "def alpha():\n    return 'left\u2028right'")
        self.assertEqual(functions[1].source, "def beta():\n    return 2")

    def test_omitted_and_zero_counts_preserve_deletion_anchors(self):
        one = parse_unified_diff(HEADERS + "@@ -2 +2 @@\n-old\n+new\n")[0]
        self.assertEqual(one.added_lines, {2})
        self.assertEqual(one.touched_lines, {1, 2})
        added = parse_unified_diff(HEADERS + "@@ -2,0 +3,2 @@\n+one\n+two\n")[0]
        self.assertEqual(added.added_lines, {3, 4})
        deleted = parse_unified_diff(HEADERS + "@@ -3,2 +2,0 @@\n-one\n-two\n")[0]
        self.assertEqual(deleted.added_lines, set())
        self.assertEqual(deleted.touched_lines, {2, 3})
        self.assertEqual(parse_unified_diff(HEADERS + "@@ -0,0 +0,0 @@\n")[0].touched_lines,
                         set())

    def test_header_looking_source_is_payload_until_counts_are_satisfied(self):
        text = HEADERS + "@@ -1,2 +1,2 @@\n--- old header\n+++ new header\n tail\n"
        files = parse_unified_diff(text)
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0].path, "selected.py")
        self.assertEqual(files[0].added_lines, {1})

    def test_no_newline_markers_consume_neither_side(self):
        text = HEADERS + ("@@ -1 +1 @@\n-old\n\\ No newline at end of file\n"
                          "+new\n\\ No newline at end of file\n")
        self.assertEqual(parse_unified_diff(text)[0].added_lines, {1})
        for bad in (
            HEADERS + "@@ -1 +1 @@\n\\ No newline at end of file\n-old\n+new\n",
            text + "\\ No newline at end of file\n",
        ):
            with self.subTest(bad=bad), self.assertRaises(DiffFormatError):
                parse_unified_diff(bad)

    def test_bare_empty_context_is_real_but_terminal_split_element_is_not(self):
        incomplete = HEADERS + "@@ -1,2 +1,2 @@\n same\n"
        with self.assertRaises(DiffFormatError):
            parse_unified_diff(incomplete)
        self.assertEqual(parse_unified_diff(incomplete + "\n")[0].touched_lines, set())
        self.assertEqual(parse_unified_diff(incomplete + " \n")[0].touched_lines, set())

    def test_incomplete_or_overflowing_body_is_typed(self):
        bodies = [
            "@@ -1,2 +1,2 @@\n-old\n+new\n",
            "@@ -1 +1 @@\n-old\n+new\n+overflow\n",
            "@@ -1 +1 @@\n-old\n+new\n-overflow\n",
            "@@ -1,0 +1,1 @@\n-old\n",
            "@@ -1,1 +1,0 @@\n+new\n",
            "@@ -1,0 +1,1 @@\n context\n",
            "@@ -1 +1 @@\n?unknown prefix\n",
            "@@ -1,2 +1,2 @@\n-old\n+new\n@@ -4 +4 @@\n-x\n+y\n",
        ]
        for body in bodies:
            with self.subTest(body=body), self.assertRaises(DiffFormatError):
                parse_unified_diff(HEADERS + body)

    def test_later_bad_hunk_rejects_whole_selection_before_source_read(self):
        text = VALID + ("diff --git a/later.py b/later.py\n--- a/later.py\n"
                        "+++ b/later.py\n@@ -1,2 +1,2 @@\n-old\n+new\n")
        with patch("testpilot.diff.tokenize.open",
                   side_effect=AssertionError("source must not be read")):
            with self.assertRaises(DiffFormatError):
                changed_functions(self.repo, text)

    def test_overlong_recognized_number_uses_typed_boundary(self):
        # Exceeds Python's default integer-conversion digit limit. Even with
        # that limit disabled, an unfulfilled count is a typed incomplete hunk.
        for header in (
            "@@ -1," + "9" * 5000 + " +1 @@\n",
            "@@ -" + "9" * 5000 + " +1 @@\n",
        ):
            with self.subTest(header=header[:20]), self.assertRaises(DiffFormatError):
                parse_unified_diff(HEADERS + header)

    def test_long_diagnostic_label_does_not_change_parsed_path(self):
        name = "p" * 8192 + ".py"
        headers = f"--- a/{name}\n+++ b/{name}\n"
        valid = headers + "@@ -1 +1 @@\n-old\n+new\n"
        self.assertEqual(parse_unified_diff(valid)[0].path, name)
        with self.assertRaises(DiffFormatError) as caught:
            parse_unified_diff(headers + "@@ -1 +1 @@\n-old\n")
        message = str(caught.exception)
        self.assertLess(len(message), 300)
        self.assertIn("...[truncated]", message)
        self.assertIn("at diff line 5", message)
        self.assertNotIn(name, message)

    def test_quoted_path_and_completed_mail_footer_keep_existing_contract(self):
        text = ('--- "a/caf\\303\\251.py"\n+++ "b/caf\\303\\251.py"\n'
                '@@ -1 +1 @@\n-old\n+new\n-- \n2.53.0\n')
        self.assertEqual(parse_unified_diff(text)[0].path, "café.py")

    def test_real_targets_cli_file_and_stdin_admit_complete_input(self):
        for stdin in (False, True):
            with self.subTest(stdin=stdin):
                result = self.invoke(VALID, stdin=stdin)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, "")
                functions = json.loads(result.stdout)["changed_functions"]
                self.assertEqual([(f["qualname"], f["source"]) for f in functions],
                                 [("selected", SOURCE.rstrip("\n"))])

    def test_real_cli_refuses_before_preview_or_generation_effects(self):
        output = self.root / "saved-output"
        output.mkdir()
        (output / "report.json").write_bytes(b"previous accepted output\n")
        before = {p.name: p.read_bytes() for p in output.iterdir()}
        malformed = VALID.replace("@@ -1,2 +1,2 @@", "@@ -1,20 +1,20 @@")
        for command, explicit, diagnostic in (
            ("targets", False, "cannot inspect targets:"),
            ("run", False, "invalid diff hunk:"),
            ("run", True, "invalid target selection:"),
        ):
            with self.subTest(command=command, explicit=explicit):
                self.assert_refused(self.invoke(malformed, command=command, explicit=explicit),
                                    diagnostic)
                self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()}, before)
        self.assertEqual((self.repo / "selected.py").read_text(encoding="utf-8"), SOURCE)


if __name__ == "__main__":
    unittest.main()
