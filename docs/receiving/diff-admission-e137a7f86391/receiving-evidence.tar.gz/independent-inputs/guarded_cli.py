"""Invoke the unchanged CLI module while stopping every forbidden work effect."""
import json
import runpy
import sys
from pathlib import Path

source, effect_path, *arguments = sys.argv[1:]
sys.path.insert(0, source)
import testpilot.model as model
import testpilot.loop as loop
import testpilot.sandbox as sandbox

events = []
class ForbiddenEffect(BaseException):
    pass

def forbid(name):
    def stopped(*args, **kwargs):
        events.append({"effect": name})
        raise ForbiddenEffect(name)
    return stopped

model.make_client = forbid("make_client")
loop.TestPilot = forbid("TestPilot")
loop.write_outputs = forbid("write_outputs")
sandbox.run_pytest = forbid("sandbox.run_pytest")
if hasattr(loop, "run_pytest"):
    loop.run_pytest = forbid("loop.run_pytest")
sys.argv = ["testpilot", *arguments]
status = 0
try:
    runpy.run_module("testpilot", run_name="__main__", alter_sys=True)
except SystemExit as exc:
    status = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
except ForbiddenEffect as exc:
    print("RECEIVER_STOPPED_FORBIDDEN_EFFECT:" + str(exc), file=sys.stderr)
    status = 87
finally:
    p = Path(effect_path)
    with p.open("x") as handle:
        json.dump({"events": events, "exit": status}, handle, indent=2)
        handle.write("\n")
raise SystemExit(status)
