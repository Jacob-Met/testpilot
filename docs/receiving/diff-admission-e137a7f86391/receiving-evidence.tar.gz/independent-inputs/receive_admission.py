"""Independent frozen-input admission receiver; no model, tests or sandbox run."""
from __future__ import annotations
import argparse
import dataclasses
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument("--source", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--mode", choices=("baseline", "candidate"), required=True)
args = ap.parse_args()
source = Path(args.source).resolve()
out = Path(args.out)
out.mkdir(mode=0o700)
corpus_path = ROOT / "frozen-cases-v1/corpus.json"
corpus_bytes = corpus_path.read_bytes()
assert hashlib.sha256(corpus_bytes).hexdigest() == "0bcf507ecc9665c45360a2feb4addb8274b9cd8a23fbd34004a3a10f7f587b71"
corpus = json.loads(corpus_bytes)
cases = corpus["cases"][:]
addendum = json.loads((ROOT / "frozen-cases-v1/addendum.json").read_text())
cases.extend(addendum["cases"])
repo = Path(corpus["repo"])
env = dict(os.environ)
env["PYTHONPATH"] = str(source)
env["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
sys.path.insert(0, str(source))
diff = importlib.import_module("testpilot.diff")
targets = importlib.import_module("testpilot.targets")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source_snapshot():
    return {p.relative_to(source).as_posix(): sha(p.read_bytes())
            for p in sorted((source / "testpilot").glob("*.py"))}

before_sources = source_snapshot()
before_repo = {p.name: sha(p.read_bytes()) for p in repo.glob("*.py")}
assert before_repo == corpus["sourceAfter"]
rows, issues, cli_rows = [], [], []
def check(condition, message):
    if not condition:
        issues.append(message)

def records(value):
    result = []
    for item in value:
        x = dataclasses.asdict(item)
        for name in ("added_lines", "touched_lines"):
            if name in x:
                x[name] = sorted(x[name])
        result.append(x)
    return result

error_type = getattr(diff, "DiffFormatError", None)
if args.mode == "candidate":
    check(isinstance(error_type, type) and issubclass(error_type, ValueError),
          "public DiffFormatError must be a ValueError subclass")

for case in cases:
    patch = ROOT / "frozen-cases-v1" / case["patch"]["path"]
    raw = patch.read_bytes()
    assert len(raw) == case["patch"]["bytes"]
    assert sha(raw) == case["patch"]["sha256"]
    text = raw.decode()
    row = {"name": case["name"], "expectedValid": case["valid"], "observations": {}}
    for name, callback in (
        ("parse", lambda: records(diff.parse_unified_diff(text))),
        ("selection", lambda: records(diff.changed_functions(repo, text))),
        ("explicit", lambda: records(targets.resolve_targets(repo, text, ["beta.py::alter"]))),
    ):
        try:
            value = callback()
            row["observations"][name] = {"accepted": True, "value": value}
        except Exception as exc:
            row["observations"][name] = {
                "accepted": False, "type": type(exc).__name__,
                "valueError": isinstance(exc, ValueError),
                "message": str(exc),
                "causeType": type(exc.__cause__).__name__ if exc.__cause__ else None,
                "typed": bool(error_type and isinstance(exc, error_type)),
                "wrappedTyped": bool(error_type and isinstance(exc, targets.TargetSelectionError)
                                     and isinstance(exc.__cause__, error_type)),
            }
        observation = row["observations"][name]
        if case["valid"]:
            check(observation["accepted"], case["name"] + ": valid " + name + " rejected")
            if observation["accepted"] and name != "explicit":
                expected = case["expected_files"] if name == "parse" else case["expected_functions"]
                check(observation["value"] == expected, case["name"] + ": " + name + " differs from frozen literals")
            if observation["accepted"] and name == "explicit":
                check(len(observation["value"]) == 1 and
                      observation["value"][0]["path"] == "beta.py" and
                      observation["value"][0]["qualname"] == "alter",
                      case["name"] + ": explicit target identity changed")
        elif args.mode == "candidate":
            check(not observation["accepted"], case["name"] + ": malformed " + name + " admitted")
            if not observation["accepted"]:
                check(observation.get("wrappedTyped") if name == "explicit" else observation.get("typed"),
                      case["name"] + ": " + name + " did not expose the promised typed failure")
                check(bool(observation.get("message")), case["name"] + ": empty refusal diagnostic")
    rows.append(row)

def run_cli(label, arguments, input_bytes=None, guarded=False):
    effect = out / (label + ".effects.json")
    if guarded:
        argv = [sys.executable, "-B", str(ROOT / "guarded_cli.py"),
                str(source), str(effect), *arguments]
    else:
        argv = [sys.executable, "-B", "-m", "testpilot", *arguments]
    p = subprocess.run(argv, env=env, cwd=out, input=input_bytes,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    for suffix, body in (("stdout", p.stdout), ("stderr", p.stderr)):
        with (out / (label + "." + suffix)).open("xb") as handle:
            handle.write(body)
    record = {"label": label, "argv": argv, "exit": p.returncode,
              "stdout": {"path": label + ".stdout", "bytes": len(p.stdout), "sha256": sha(p.stdout)},
              "stderr": {"path": label + ".stderr", "bytes": len(p.stderr), "sha256": sha(p.stderr)},
              "effects": json.loads(effect.read_text())["events"] if guarded else None}
    cli_rows.append(record)
    return p, record

# Real target-inspection CLI: valid file and stdin produce the exact public records.
valid = cases[0]
valid_patch = ROOT / "frozen-cases-v1" / valid["patch"]["path"]
for route in ("file", "stdin"):
    p, _ = run_cli("valid-targets-" + route,
        ["targets", "--repo", str(repo), "--diff", str(valid_patch) if route == "file" else "-", "--json"],
        valid_patch.read_bytes() if route == "stdin" else None)
    check(p.returncode == 0, "valid CLI " + route + " failed")
    try:
        check(json.loads(p.stdout) == {"changed_functions": valid["expected_functions"]},
              "valid CLI " + route + " changed the exact target records")
    except Exception as exc:
        issues.append("valid CLI " + route + " produced non-JSON output: " + type(exc).__name__)

# Every malformed patch exercises targets and guarded automatic run; selected boundary
# cases additionally exercise the unchanged explicit-target wrapper.
for index, case in enumerate(x for x in cases if not x["valid"]):
    patch = ROOT / "frozen-cases-v1" / case["patch"]["path"]
    for entry in ("targets", "run"):
        label = "%02d-%s-%s" % (index, entry, case["name"])
        route_stdin = (index % 2 == 1)
        argv = [entry, "--repo", str(repo), "--diff", "-" if route_stdin else str(patch)]
        output = out / ("forbidden-output-" + label)
        if entry == "targets":
            argv += ["--json"]
        else:
            argv += ["--backend", "scripted", "--script", str(out / "no-responses"),
                     "--out", str(output)]
        p, record = run_cli(label, argv, patch.read_bytes() if route_stdin else None,
                            guarded=(entry == "run"))
        if args.mode == "candidate":
            check(p.returncode == 2, label + ": expected configuration refusal 2")
            check(p.stdout == b"", label + ": partial targets/report output")
            diagnostic = p.stderr.decode("utf-8", "replace")
            check("testpilot:" in diagnostic and
                  ("diff" in diagnostic.lower() or "hunk" in diagnostic.lower()),
                  label + ": no useful diff diagnostic")
            check("Traceback" not in diagnostic, label + ": leaked an incidental traceback")
            if entry == "run":
                check(record["effects"] == [], label + ": forbidden work effect was attempted")
        check(not output.exists(), label + ": output directory was created")
    if case["name"] in ("unfinished-before-git-file", "swallowed-next-file-headers", "overlong-declared-count"):
        for entry in ("targets", "run"):
            label = "explicit-" + entry + "-" + case["name"]
            argv = [entry, "--repo", str(repo), "--diff", str(patch),
                    "--target", "beta.py::alter"]
            output = out / ("forbidden-output-" + label)
            if entry == "targets":
                argv += ["--json"]
            else:
                argv += ["--backend", "scripted", "--script", str(out / "no-responses"),
                         "--out", str(output)]
            p, record = run_cli(label, argv, guarded=(entry == "run"))
            if args.mode == "candidate":
                check(p.returncode == 2 and p.stdout == b"", label + ": explicit refusal/output mismatch")
                if entry == "run":
                    check(record["effects"] == [], label + ": explicit selection allowed a work effect")
            check(not output.exists(), label + ": output directory created")

# Deliberate positive stop: a valid automatic input reaches the first client boundary.
# This is a receiver control, not an execution of a client/model/baseline.
p, guard_control = run_cli("valid-run-effect-control",
    ["run", "--repo", str(repo), "--diff", str(valid_patch),
     "--backend", "scripted", "--script", str(out / "no-responses"),
     "--out", str(out / "forbidden-positive-output")], guarded=True)
check(p.returncode == 87 and guard_control["effects"] == [{"effect": "make_client"}],
      "positive effect sentinel did not stop exactly at make_client")
check(not (out / "forbidden-positive-output").exists(), "positive guard created output")
check(before_repo == {p.name: sha(p.read_bytes()) for p in repo.glob("*.py")},
      "receiving changed authored fixture sources")
check(before_sources == source_snapshot(), "receiving changed captured product sources")

receipt = {
    "schema": "hamon.testpilot.independent-admission-receipt.v1",
    "recordedAt": datetime.now(timezone.utc).isoformat(),
    "mode": args.mode,
    "status": "QUALIFIED" if not issues and args.mode == "candidate" else
              "BASELINE_OBSERVED" if not issues else "RECEIVER_CHECK_FAILED",
    "source": str(source), "sourceSha256": before_sources,
    "python": sys.version,
    "corpusSha256": sha(corpus_bytes),
    "addendumSha256": sha((ROOT / "frozen-cases-v1/addendum.json").read_bytes()),
    "validCases": sum(x["valid"] for x in cases),
    "invalidCases": sum(not x["valid"] for x in cases),
    "publicObservations": rows, "cli": cli_rows, "issues": issues,
    "sourceAndFixturePreserved": before_sources == source_snapshot() and
        before_repo == {p.name: sha(p.read_bytes()) for p in repo.glob("*.py")},
    "effectsBoundary": "No client/model/test generation/baseline/sandbox/output effect ran. Every attempted make_client on the original invalid baseline and the one valid positive control was stopped by a receiver sentinel before construction.",
}
with (out / "receipt.json").open("x") as handle:
    json.dump(receipt, handle, indent=2)
    handle.write("\n")
b = (out / "receipt.json").read_bytes()
print(json.dumps({"status": receipt["status"], "receipt": str(out / "receipt.json"),
                  "bytes": len(b), "sha256": sha(b), "issues": issues,
                  "valid": receipt["validCases"], "invalid": receipt["invalidCases"],
                  "cliInvocations": len(cli_rows),
                  "malformedAcceptedByOriginalParser": sum(
                     not r["expectedValid"] and r["observations"]["parse"]["accepted"] for r in rows)}))
raise SystemExit(1 if issues else 0)
