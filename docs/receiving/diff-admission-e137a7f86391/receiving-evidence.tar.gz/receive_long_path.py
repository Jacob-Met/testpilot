"""Apply the existing bounded-path behavior witness to accepted PR48/PR49 source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,importlib,json,os,subprocess,sys
R=Path(__file__).resolve().parent
P=Path('/home/jacob/testpilot-hunk-receiving-e137a7f86391')
SOURCE=R/'source-513f1745'
OUT=R/'long-path-v1'
OUT.mkdir(mode=0o700)
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((R/'source-capture.json').read_text())
for row in pins['files']:
 b=(SOURCE/row['path']).read_bytes()
 assert sha(b)==row['sha256']
sys.dont_write_bytecode=True
sys.path.insert(0,str(SOURCE))
module=importlib.import_module('testpilot.diff')
assert module.DiffFormatError is not ValueError and issubclass(module.DiffFormatError,ValueError)
name='x'*8189+'.py'
header='diff --git a/'+name+' b/'+name+'\n--- a/'+name+'\n+++ b/'+name+'\n@@ -1 +1 @@\n'
valid=header+'-old\n+new\n'
invalid=header+'-old\n'
for label,text in [('valid.diff',valid),('invalid.diff',invalid)]:
 (OUT/label).write_text(text)
parsed=module.parse_unified_diff(valid)
assert len(parsed)==1 and parsed[0].path==parsed[0].old_path==name
assert parsed[0].added_lines=={1} and parsed[0].touched_lines=={1}
try:
 module.parse_unified_diff(invalid)
 raise AssertionError('malformed long-path patch admitted')
except module.DiffFormatError as exc:
 message=str(exc)
assert len(message)<=512 and name not in message
assert 'diff' in message and ('line' in message or 'record' in message)
env=dict(os.environ,PYTHONPATH=str(SOURCE),PYTHONDONTWRITEBYTECODE='1')
repo=json.loads((P/'frozen-cases-v1/corpus.json').read_text())['repo']
rows=[]
for mode in ['targets','run']:
 effect=OUT/(mode+'.effects.json')
 output=OUT/(mode+'-forbidden-output')
 argv=[mode,'--repo',repo,'--diff',str(OUT/'invalid.diff')]
 if mode=='targets':
  argv+=['--json']
  cmd=[sys.executable,'-B','-m','testpilot',*argv]
 else:
  argv+=['--backend','scripted','--script',str(OUT/'no-responses'),'--out',str(output)]
  cmd=[sys.executable,'-B',str(P/'guarded_cli.py'),str(SOURCE),str(effect),*argv]
 p=subprocess.run(cmd,cwd=OUT,env=env,capture_output=True,timeout=20)
 for ext,b in [('stdout',p.stdout),('stderr',p.stderr)]:
  (OUT/(mode+'.'+ext)).write_bytes(b)
 events=json.loads(effect.read_text())['events'] if mode=='run' else None
 stderr=p.stderr.decode()
 assert p.returncode==2 and p.stdout==b'' and 'testpilot:' in stderr and 'Traceback' not in stderr
 assert len(stderr)<=544 and not output.exists()
 if mode=='run':assert events==[]
 rows.append({'mode':mode,'argv':cmd,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stderrBytes':len(p.stderr),'stderrCharacters':len(stderr),'stderrSha256':sha(p.stderr),'effects':events})
for row in pins['files']:
 assert sha((SOURCE/row['path']).read_bytes())==row['sha256']
receipt={'schema':'hamon.testpilot.incumbent-long-path.v1','recordedAt':datetime.now(timezone.utc).isoformat(),'status':'QUALIFIED','sourceCommit':pins['commit'],'sourceTree':pins['tree'],'pathCharacters':8192,'validPathPreservedExactly':True,'typedError':module.DiffFormatError.__name__,'malformedMessage':message,'malformedMessageCharacters':len(message),'cli':rows,'sourcePreserved':True,'limits':'Same existing 8192-character witness and independent message limits; incumbent diagnostic uses record context and omits caller path. This is not a validation of arbitrary patch applicability.','effects':'Guarded run stopped no forbidden work because parser rejected before make_client. No model/provider/baseline/sandbox/output work ran.'}
p=OUT/'receipt.json'
p.write_text(json.dumps(receipt,indent=2)+'\n')
b=p.read_bytes()
print(json.dumps({'status':'QUALIFIED','path':str(p),'bytes':len(b),'sha256':sha(b),'messageCharacters':len(message),'cliInvocations':len(rows)}))
