from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,stat,shutil,tarfile
R=Path('/tmp/testpilot-hunk-incumbent-receiving-e137a7f86391')
OLD=Path('/tmp/testpilot-hunk-receiving-e137a7f86391-diagnostic-v2')
P=Path('/home/jacob/testpilot-hunk-receiving-e137a7f86391')
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p,expected=None):
 b=p.read_bytes()
 if expected:assert sha(b)==expected
 return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(p,obj):
 b=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b)
 return bind(p)
prior=R/'prior-packet';prior.mkdir()
for name in ['receiving-evidence.tar.gz','receiving-readback.json','SUPERSEDED-BY-PR48.json']:
 data=(OLD/name).read_bytes()
 with (prior/name).open('xb') as f:f.write(data)
 assert (prior/name).read_bytes()==data
inputs=R/'independent-inputs';inputs.mkdir()
for source,name in [(P/'pre-candidate-plan.json','pre-candidate-plan.json'),(P/'frozen-cases-v1/corpus.json','corpus.json'),(P/'frozen-cases-v1/addendum.json','addendum.json'),(P/'receive_admission.py','receive_admission.py'),(P/'guarded_cli.py','guarded_cli.py')]:
 b=source.read_bytes()
 with (inputs/name).open('xb') as f:f.write(b)
 assert (inputs/name).read_bytes()==b
full=bind(R/'incumbent-v1/receipt.json','b2c5b17797fedb19ba5c5c503bc4b7dc1b40a5c3d61978bc3bc2628bd2f082dd')
long=bind(R/'long-path-v1/receipt.json','67a99542251d485f2d6c7e843787ef96b8e8ccb3a7eda94c9b472bb19e109155')
a=json.loads((R/'incumbent-v1/receipt.json').read_text())
b=json.loads((R/'long-path-v1/receipt.json').read_text())
s=json.loads((R/'source-capture.json').read_text())
assert a['status']==b['status']=='QUALIFIED' and a['issues']==[] and a['sourceAndFixturePreserved'] and b['sourcePreserved']
for row in s['files']:
 data=(R/'source-513f1745'/row['path']).read_bytes()
 assert sha(data)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['gitBlob']
acceptance={
 'schema':'hamon.testpilot.incumbent-convergence-acceptance.v1',
 'recordedAt':datetime.now(timezone.utc).isoformat(),
 'producer':'/root/coordination',
 'status':'QUALIFIED_ACCEPTED_INCUMBENT_NO_ALTERNATE_RUNTIME',
 'repository':'Jacob-Met/testpilot','issue':45,
 'currentSource':{'commit':s['commit'],'tree':s['tree'],'capture':bind(R/'source-capture.json'),'files':s['files']},
 'incumbentCredit':{'pullRequest':48,'merge':'e5b7ac4a00704c0fad0c5d70da0aaafa40a722df','mergedAt':'2026-10-08T19:01:15Z','sourceHead':'c7b593ea652dd6b572d0f1076c839d155e0f4599','sourceEvidenceNamespace':'6cc6795e89f4','sourceContribution':'Complete hunk validation and automatic preflight were authored and merged by the incumbent. This receiving contribution does not claim its implementation.'},
 'preservedLaterContribution':{'pullRequest':49,'merge':'513f17454af378ee042ccd29dc930ef332a48734','meaning':'Current positive-finite timeout admission remains byte-exact in CLI 53b9436c. Its settled tests were not repeated.'},
 'independentFrozenCorpus':{'plan':bind(inputs/'pre-candidate-plan.json'),'corpus':bind(inputs/'corpus.json'),'addendum':bind(inputs/'addendum.json'),'expectedValues':'Authored before any candidate implementation/test access. Literal complete FileChange/function records from independently authored before/after files, genuine Git patches and Git apply --check controls. No author test expectations consumed.'},
 'currentExecution':{'receipt':full,'validCases':14,'invalidCases':12,'cliInvocations':33,'result':'Every valid public record matched unchanged frozen expectations; every malformed parse/selector refused with DiffFormatError, explicit targets retained wrapping, and actual automatic CLI refused before effects. No receiver modification or valid-behavior exception.','positiveGuardControl':'One valid automatic input reaches make_client and is stopped before construction, confirming the receiver effect guard.'},
 'longPathControl':{'receipt':long,'validPathCharacters':8192,'validPathPreservedExactly':True,'typedMalformedMessageCharacters':b['malformedMessageCharacters'],'cliInvocations':2,'result':'Incumbent diagnostic is 83 characters, preserves record context and omits the caller path. Actual targets and guarded run exit 2 without output, traceback or forbidden effects.'},
 'effectsBoundary':'35 actual CLI invocations total on accepted current source; automatic run is guarded before client/model/provider/baseline/sandbox/output functions. No such underlying function ran. This is admission receiving, not a test-generation or model run.',
 'sourceFence':'All eleven runtime module Git blobs match complete current-tree metadata; nine unaffected modules equal original cec. Receiver writes only isolated evidence/fixture paths. No installed service, owner source or runtime was changed.',
 'historicalDisposition':{'status':'Alternate cec-based runtime withdrawn for integration by root after incumbent merge detected. Historical count/CLI, root counterexample, v2 correction and ENOSPC receipts remain unchanged.','sidecar':bind(prior/'SUPERSEDED-BY-PR48.json'),'completePriorArchive':bind(prior/'receiving-evidence.tar.gz','f11ec1677380b1cc9ae59aa01b48628e29a1834f9f65cd201eec40416dc8e27e'),'priorReadback':bind(prior/'receiving-readback.json','b5222051b008d74da886b1b7bb6af2953cfd9178adafb0640c7e18f3ae48701a')},
 'limits':['Recognized two-way hunk structure and selection behavior, not complete patch applicability.','No heuristic rejects legitimate header-looking +/- body text.','No combined/binary/rename applicability claim.','No alternate source patch or competing pull request is proposed.','Current source and ownership API responses are retained in source-inputs.json. Hosted CI/public closure remain root responsibilities.','Packet is in isolated native /tmp after native home ENOSPC; readback proves present bytes, not indefinite persistence.']
}
ainfo=write(R/'final-convergence.json',acceptance)
excluded={'receiving-manifest.json','receiving-readback.json','receiving-evidence.tar.gz','seal.stdout','seal.stderr'}
rows=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(R).as_posix()
 if rel in excluded:continue
 data=p.read_bytes();rows.append({'path':rel,'bytes':len(data),'sha256':sha(data),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
m=write(R/'receiving-manifest.json',{'schema':'hamon.testpilot.incumbent-manifest.v1','files':rows,'count':len(rows),'bytes':sum(x['bytes'] for x in rows)})
archive=R/'receiving-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
 for row in rows:tar.add(R/row['path'],arcname=row['path'],recursive=False)
 tar.add(R/'receiving-manifest.json',arcname='receiving-manifest.json',recursive=False)
print(json.dumps({'acceptance':ainfo,'manifest':m,'archive':bind(archive),'files':len(rows),'payloadBytes':sum(x['bytes'] for x in rows)}))
