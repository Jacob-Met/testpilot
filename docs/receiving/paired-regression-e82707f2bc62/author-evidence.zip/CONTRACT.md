# Paired retained-suite regression execution: frozen receiving contract v1

Frozen before candidate implementation or peer candidate access. Baseline is
TestPilot main `191cca4e416286a9e1fa4b5d5daf5fc30b936db6`, tree
`2602440d626872f0293755723dc6ca610b1e360b`.

## Public entry points

`testpilot.regression.check_regression(repo, report_path, *, before, after,
timeout_s=60.0, python=None) -> dict` raises `RegressionError(ValueError)` for
input, Git admission, materialization, or execution setup failures. It writes
only disposable temporary snapshots; it does not publish output files.

`python -m testpilot regression --repo ROOT --report REPORT --before REF
--after REF --out NEW_DIRECTORY [--python EXECUTABLE] [--timeout SECONDS]`
uses the same public function. Output is `regression.json` and `regression.md`.
Exit 0 means `verified_regression`; exit 1 means a completed comparison that did
not establish that result; exit 2 means admission/setup/output refusal. The
destination must be new and outside the repository. Existing destinations and
source files are never replaced. Refusal before execution creates no result.

## Source and retained-suite custody

The report is admitted once through existing public `read_saved_tests`; exact
sorted UTF-8 test bytes and original report SHA-256 are frozen for both phases.
This adds no report format, model calls, repair, patch application, or historical
report comparison. The generation report's recorded status is context only.

`repo` must be the root of an existing local Git worktree. Both caller refs are
resolved once to commit and tree IDs before either test phase. Git replacement
objects, caller Git environment redirection, and lazy fetching are disabled.
No fetch, checkout, index, ref, worktree registration, clean, or Git hook runs.
No ancestor relationship is required: results describe those two explicit
revisions, without claiming which individual change caused a result.

Each committed tree is materialized from its original blobs, preserving regular
file bytes and executable mode. Git archive export-ignore/export-subst and
checkout filters do not transform it. Both snapshots and all retained-test
placements are admitted before pytest starts. A tracked retained-test path must
already contain the exact saved bytes, or be absent for temporary insertion;
conflicting bytes or file/directory conflicts refuse. Dirty and untracked
working-tree files are irrelevant and remain unchanged.

This first version supports regular Git files (100644/100755). Symlinks,
submodules/gitlinks, malformed/unsafe paths, unavailable objects, excessive tree
size, and non-finite/non-positive timeouts refuse explicitly. Source limits are
10,000 files, 8 MiB per file, and 64 MiB per revision. The established native
sandbox/collection/ignore policy and selected Python are unchanged. Each phase
calls existing `run_pytest` with `coverage=False, exact_files=True` and the same
retained mapping. Dependencies come from the selected interpreter; none are
installed automatically. This is the existing local execution boundary, not
additional operating-system or network isolation for project tests.

## Result shape

The result has `schema: "testpilot.regression/1"`, `status`, `ok`, `repo`,
`python`, `model_calls: 0`, timestamps, `source_report` (`path`, `sha256`,
`recorded_status`), exact `test_files`, and `retained_tests` descriptors (`path`,
`bytes`, `sha256`). `ok` is true only for `verified_regression`.

`before` and `after` each contain `requested_ref`, `commit`, `tree`,
`source_files`, `source_bytes`, `snapshot_sha256`, and `result` (the unchanged
native `SandboxResult.to_dict()` shape, including generated cases and JUnit
availability). The snapshot SHA-256 binds sorted path/mode/blob/byte-size facts.

`comparison` contains `comparable`, `reason`, `case_pairs`, `witnesses`,
`unmatched_before`, and `unmatched_after`. A paired identity is
`(generated_file, nodeid)` from the real native collector. `case_pairs` and
`witnesses` contain these two fields plus `before`/`after` outcome strings.

## Decision rules

Both native phases must complete without timeout, have available JUnit, return
0 or 1, and report no native errors. Every retained test file must contribute
at least one generated case in each phase. Generated case identities must be
unique and exactly equal across phases. Missing or duplicate identities,
missing retained-file collection, generated skips, import/setup/collection
errors, unavailable JUnit, and timeouts are `inconclusive` (`comparable:false`).

For otherwise comparable runs, a failed after native run is `after_failed`.
The after native run must be successful and every generated after case must
pass. A generated case with outcome `failed` before and `passed` after becomes
a witness. At least one witness yields `verified_regression`. If every before
generated case already passed, the result is `not_regression`, even when an
unrelated existing test failed before. Existing-suite skips retain the native
sandbox semantics; generated skips never establish a comparison.

## Original-source witness

`original_witness.py` uses exact maintained `eval/cases/calc_clamp` bytes, a
synthetic two-commit local repository, and real native generation/recheck CLI
processes. Its `original-witness/receipt.json` records three generated failures
and one pass before, four passes after, zero model calls in both rechecks,
identical retained bytes, and unchanged input/source hashes. The proposed
paired command returns argparse exit 2 on the original source and creates no
output. No candidate module exists when this contract is frozen.

## Source fence

New `testpilot/regression.py`, new regression tests, `docs/REGRESSION.md`, narrow
README additions, and additive CLI import/parser/dispatch only. Existing
`sandbox.py`, `recheck.py`, collector, model, generation/repair, selector,
saved-report comparison/history and their writers remain with their owners.
