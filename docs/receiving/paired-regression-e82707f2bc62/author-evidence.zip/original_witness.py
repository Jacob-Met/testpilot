"""Native original-source witness using the maintained calc_clamp fixture."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/e82707f2bc62/testpilot-revision-check/baseline')
PYTHON = ROOT / 'runtime/bin/python'
OUT = ROOT / 'original-witness'
OUT.mkdir()
FIXTURE = SOURCE / 'eval/cases/calc_clamp'
REPO = OUT / 'project'
shutil.copytree(FIXTURE / 'repo', REPO)
env = dict(os.environ, PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1',
           TMPDIR=str(ROOT / 'tmp'), GIT_CONFIG_NOSYSTEM='1',
           GIT_AUTHOR_NAME='TestPilot synthetic receiving',
           GIT_AUTHOR_EMAIL='receiving@example.invalid',
           GIT_COMMITTER_NAME='TestPilot synthetic receiving',
           GIT_COMMITTER_EMAIL='receiving@example.invalid')
commands = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def state(path):
    return {str(p.relative_to(path)): digest(p)
            for p in sorted(path.rglob('*')) if p.is_file() and '.git' not in p.parts}


def run(name, argv, expected):
    proc = subprocess.run([str(x) for x in argv], cwd=OUT, env=env,
                          capture_output=True, text=True, timeout=90)
    (OUT / f'{name}.stdout').write_text(proc.stdout)
    (OUT / f'{name}.stderr').write_text(proc.stderr)
    commands.append({'name': name, 'argv': [str(x) for x in argv],
                     'returncode': proc.returncode,
                     'stdout_sha256': digest(OUT / f'{name}.stdout'),
                     'stderr_sha256': digest(OUT / f'{name}.stderr')})
    assert proc.returncode == expected, (name, proc.returncode, proc.stdout, proc.stderr)
    return proc


def git(*args):
    return subprocess.run(['git', '-C', str(REPO), *args], check=True,
                          env=env, capture_output=True, text=True).stdout.strip()


source_before = state(SOURCE)
git('init', '--quiet', '--template=', '--initial-branch=main')
git('add', 'calc.py', 'tests/test_existing.py')
git('-c', 'core.hooksPath=/dev/null', 'commit', '--quiet', '-m', 'maintained buggy clamp')
before = git('rev-parse', 'HEAD')
before_tree = git('rev-parse', 'HEAD^{tree}')
shutil.copytree(FIXTURE / 'repo', OUT / 'before-snapshot')
initial_project = state(REPO)
run('generation', [PYTHON, '-B', '-m', 'testpilot', 'run', '--repo', REPO,
                  '--diff', FIXTURE / 'change.diff', '--backend', 'scripted',
                  '--script', FIXTURE / 'script', '--no-coverage', '--python', PYTHON,
                  '--timeout', '15', '--out', OUT / 'generation'], 1)
assert state(REPO) == initial_project
report = OUT / 'generation/report.json'
saved_hash = digest(report)
run('before-recheck', [PYTHON, '-B', '-m', 'testpilot', 'recheck', '--repo', REPO,
                      '--report', report, '--python', PYTHON, '--timeout', '15',
                      '--out', OUT / 'before-recheck'], 1)
assert state(REPO) == initial_project
(REPO / 'calc.py').write_bytes((FIXTURE / 'fix/calc.py').read_bytes())
git('add', 'calc.py')
git('-c', 'core.hooksPath=/dev/null', 'commit', '--quiet', '-m', 'maintained corrected clamp')
after = git('rev-parse', 'HEAD')
after_tree = git('rev-parse', 'HEAD^{tree}')
fixed_project = state(REPO)
run('after-recheck', [PYTHON, '-B', '-m', 'testpilot', 'recheck', '--repo', REPO,
                     '--report', report, '--python', PYTHON, '--timeout', '15',
                     '--out', OUT / 'after-recheck'], 0)
run('missing-paired-command', [PYTHON, '-B', '-m', 'testpilot', 'regression',
                             '--repo', REPO, '--report', report, '--before', before,
                             '--after', after, '--python', PYTHON, '--timeout', '15',
                             '--out', OUT / 'paired'], 2)
assert not (OUT / 'paired').exists()
assert "invalid choice: 'regression'" in (OUT / 'missing-paired-command.stderr').read_text()
assert state(REPO) == fixed_project and digest(report) == saved_hash
assert state(SOURCE) == source_before
first = json.loads(report.read_text())
old = json.loads((OUT / 'before-recheck/recheck.json').read_text())
new = json.loads((OUT / 'after-recheck/recheck.json').read_text())
assert first['status'] == 'suspected_code_bug'
assert old['final']['generated']['collected'] == 4
assert old['final']['generated']['failed'] == 3
assert old['final']['generated']['passed'] == 1
assert new['final']['generated']['passed'] == 4
assert new['status'] == 'passed'
assert old['model_calls'] == new['model_calls'] == 0
assert old['test_files'] == new['test_files'] == first['test_files']
receipt = {'source_commit': '191cca4e416286a9e1fa4b5d5daf5fc30b936db6',
           'fixture': 'maintained eval/cases/calc_clamp bytes',
           'before': {'commit': before, 'tree': before_tree},
           'after': {'commit': after, 'tree': after_tree},
           'source_report_sha256': saved_hash,
           'generation_status': first['status'],
           'before_native': old['final']['generated'],
           'after_native': new['final']['generated'],
           'model_calls_for_both_rechecks': 0,
           'retained_tests_exactly_equal': True,
           'baseline_paired_exit': 2, 'baseline_paired_output_created': False,
           'project_and_input_unchanged_by_execution': True,
           'source_unchanged': True, 'source_hashes': source_before,
           'commands': commands}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in {'source_hashes', 'commands'}}, indent=2))
