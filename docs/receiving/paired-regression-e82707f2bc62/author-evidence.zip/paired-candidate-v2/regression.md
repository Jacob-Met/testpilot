# TestPilot retained-suite regression check

Status: **verified_regression**

Reason: failed_before_passed_after

| Phase | Commit | Native result |
| --- | --- | --- |
| before | `339f13caa047b07c236138ea1b167e91c522a9a7` | 3 passed, 3 failed, 0 errors, 0 skipped (rc=1); generated: 1 passed of 4 collected |
| after | `4551203578c6b487693d6931115209f06c49de1f` | 6 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 4 passed of 4 collected |

Matched failure-to-pass witnesses: 3

```json
[
  {
    "generated_file": "tests/test_calc_clamp.py",
    "nodeid": "tests.test_calc_clamp::test_below_and_above",
    "before": "failed",
    "after": "passed"
  },
  {
    "generated_file": "tests/test_calc_clamp.py",
    "nodeid": "tests.test_calc_clamp::test_boundaries",
    "before": "failed",
    "after": "passed"
  },
  {
    "generated_file": "tests/test_calc_clamp.py",
    "nodeid": "tests.test_calc_clamp::test_inside_range_unchanged",
    "before": "failed",
    "after": "passed"
  }
]
```

Source report SHA-256: `42ca9cb3ec91f869783437c03c460e34f910201214134233e5789fa174bf6ec5`

Model calls: 0. These are observations on two explicit revisions; they do not identify which intervening change caused a result.

Project tests run within TestPilot's existing local execution boundary. This command adds no operating-system or network isolation.
