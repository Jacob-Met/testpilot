from pathlib import Path
import hashlib,json,os,subprocess,sys,time,traceback
ROOT=Path("/dev/shm/tp490f-ir");SOURCE=ROOT/"source";E=ROOT/"evidence"
OUT=ROOT/"comparisons";OUT.mkdir(exist_ok=True)
NEG=ROOT/"negative-inputs";NEG.mkdir(exist_ok=True)
m=json.loads((E/"candidate-source-manifest.json").read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def unchanged():return all(sha((SOURCE/x["path"]).read_bytes())==x["sha256"] for x in m["sourceFiles"])
assert unchanged()
def report(name):return ROOT/"reports"/name/"report.json"
transport=ROOT/"reports/bom-whitespace-and-unicode.json"
transport.write_bytes(b"\xef\xbb\xbf"+(ROOT/"reports/whitespace-and-unicode.json").read_bytes())
pairs=[
 ("bug-to-fix",report("before-bug"),report("after-fixed")),
 ("expanded-tests",report("after-fixed"),report("after-expanded")),
 ("missing-coverage",report("after-fixed"),report("coverage-unavailable")),
 ("no-final-result",report("after-fixed"),report("no-generated-tests")),
 ("different-targets",report("after-fixed"),report("different-target")),
 ("same-values-different-bytes",report("after-expanded"),transport)
]
env={**os.environ,"PYTHONPATH":str(SOURCE),"PYTHONDONTWRITEBYTECODE":"1","TMPDIR":"/dev/shm/tp490f-tmp","TESTPILOT_BACKEND":"independent-must-not-be-constructed","TESTPILOT_PRICES":"not-valid-json","TESTPILOT_SCRIPT":str(ROOT/"does-not-exist")}
result={"source_manifest_sha256":sha((E/"candidate-source-manifest.json").read_bytes()),"driver_sha256":sha(Path(__file__).read_bytes()),"positive":[],"negative":[],"passed":False};started=time.time()
def invoke(before,after,out):
    argv=[sys.executable,"-m","testpilot","compare","--before",str(before),"--after",str(after),"--out",str(out)]
    p=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,text=True,timeout=10)
    return p,argv
try:
    for name,before,after in pairs:
        old={str(p):sha(p.read_bytes()) for p in [before,after]};out=OUT/(name+".html");assert not out.exists()
        p,argv=invoke(before,after,out);assert p.returncode==0,(name,p.returncode,p.stdout,p.stderr)
        html=out.read_bytes();assert html.lower().startswith(b"<!doctype html")
        assert all(v.encode() in html for v in old.values())
        assert old=={str(p):sha(p.read_bytes()) for p in [before,after]}
        result["positive"].append({"name":name,"before":str(before),"after":str(after),"before_sha256":old[str(before)],"after_sha256":old[str(after)],"output":str(out),"output_sha256":sha(html),"bytes":len(html),"argv":argv,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"inputs_unchanged":True})
    valid=report("after-fixed").read_bytes()
    bad={
      "duplicate-field.json":b'{"status":"failed",'+valid[1:],
      "nonfinite-extra.json":b'{"independent_extra":NaN,'+valid[1:],
      "boolean-count.json":json.dumps({**json.loads(valid),"tests_written":True}).encode(),
      "truncated-second.json":valid[:-1]
    }
    for name,data in bad.items():
        after=NEG/name;after.write_bytes(data);out=OUT/(name+".html");p,argv=invoke(report("before-bug"),after,out)
        assert p.returncode==2,(name,p.returncode,p.stdout,p.stderr);assert not out.exists();assert after.read_bytes()==data
        result["negative"].append({"name":name,"argv":argv,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"no_output":True,"input_sha256":sha(data)})
    fifo=NEG/"not-a-regular-report.json";os.mkfifo(fifo,0o600)
    try:
        p,argv=invoke(report("before-bug"),fifo,OUT/"fifo.html");assert p.returncode==2,(p.returncode,p.stderr);assert not (OUT/"fifo.html").exists()
        result["negative"].append({"name":"fifo-before-open-refusal","argv":argv,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"no_output":True})
    finally:fifo.unlink()
    old=OUT/"previous.html";old.write_bytes(b"previous saved review must remain");p,argv=invoke(report("before-bug"),report("after-fixed"),old)
    assert p.returncode==2 and old.read_bytes()==b"previous saved review must remain"
    result["negative"].append({"name":"existing-output-preserved","argv":argv,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"existing_bytes_unchanged":True})
    alias=OUT/"input-alias.html";os.link(report("after-fixed"),alias);prior=sha(alias.read_bytes());p,argv=invoke(report("before-bug"),report("after-fixed"),alias)
    assert p.returncode==2 and sha(alias.read_bytes())==prior==sha(report("after-fixed").read_bytes())
    result["negative"].append({"name":"hardlink-input-alias-preserved","argv":argv,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr,"input_bytes_unchanged":True})
    result["passed"]=True
except Exception:
    result["failure"]=traceback.format_exc();raise
finally:
    result["seconds"]=round(time.time()-started,3);result["all_31_source_hashes_unchanged"]=unchanged()
    (E/"independent-cli-receipt.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"passed":result["passed"],"positive":len(result["positive"]),"negative":len(result["negative"]),"seconds":result["seconds"],"source_unchanged":result["all_31_source_hashes_unchanged"],"receipt_sha256":sha((E/"independent-cli-receipt.json").read_bytes())}))
