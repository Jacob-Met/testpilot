```python path=tests/test_calc_clamp.py
import pytest

from calc import clamp


def test_inside_range_unchanged():
    assert clamp(5, 0, 10) == 5


def test_below_and_above():
    assert clamp(-3, 0, 10) == 0
    assert clamp(42, 0, 10) == 10


def test_boundaries():
    assert clamp(0, 0, 10) == 0
    assert clamp(10, 0, 10) == 10


def test_inverted_bounds_raise():
    with pytest.raises(ValueError):
        clamp(1, 10, 0)
```
