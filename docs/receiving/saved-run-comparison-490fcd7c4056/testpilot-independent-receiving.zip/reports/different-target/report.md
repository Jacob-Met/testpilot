# TestPilot report: **passed**

- Changed functions: ratios.py::unit_fraction
- Tests written: 1 in tests/test_percent_generated.py
- Repair rounds used: 0/0
- Final run: 2 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 1 passed of 1 collected in 0.505s
- Coverage (total): 75.0% -> 75.0% (+0.0 pts)
- Coverage (changed lines, n=3): 66.7% -> 66.7%
- Tokens: 391 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `fixture-planner`: 1 calls, 118 in / 34 out
  - `fixture-editor`: 1 calls, 203 in / 36 out

## Patch

```diff
diff --git a/tests/test_percent_generated.py b/tests/test_percent_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_percent_generated.py
@@ -0,0 +1,4 @@
+from ratios import unit_fraction
+
+def test_quarter():
+    assert unit_fraction(1,4) == .25
```
