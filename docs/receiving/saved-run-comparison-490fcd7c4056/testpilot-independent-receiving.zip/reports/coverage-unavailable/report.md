# TestPilot report: **passed**

- Changed functions: metrics.py::percentage
- Tests written: 3 in tests/test_percent_generated.py
- Repair rounds used: 0/0
- Final run: 4 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 3 passed of 3 collected in 0.348s
- Coverage: unavailable
- Tokens: 448 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `fixture-planner`: 1 calls, 119 in / 34 out
  - `fixture-editor`: 1 calls, 204 in / 91 out

## Patch

```diff
diff --git a/tests/test_percent_generated.py b/tests/test_percent_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_percent_generated.py
@@ -0,0 +1,10 @@
+import pytest
+from metrics import percentage
+
+@pytest.mark.parametrize('part,total,expected', [(15,60,25), (30,60,50)])
+def test_fractions(part,total,expected):
+    assert percentage(part,total) == pytest.approx(expected)
+
+def test_nonpositive_total():
+    with pytest.raises(ValueError):
+        percentage(1,0)
```
