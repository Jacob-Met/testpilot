# TestPilot report: **suspected_code_bug**

The implementation multiplies by total instead of dividing; the recorded fractions expose that mismatch.

- Changed functions: metrics.py::percentage
- Tests written: 3 in tests/test_percent_generated.py
- Repair rounds used: 1/1
- Final run: 2 passed, 2 failed, 0 errors, 0 skipped (rc=1); generated: 1 passed of 3 collected in 0.601s
- Coverage (total): 75.0% -> 100.0% (+25.0 pts)
- Coverage (changed lines, n=3): 66.7% -> 100.0%
- Tokens: 1077 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `fixture-planner`: 1 calls, 119 in / 34 out
  - `fixture-editor`: 2 calls, 802 in / 122 out

## Patch

```diff
diff --git a/tests/test_percent_generated.py b/tests/test_percent_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_percent_generated.py
@@ -0,0 +1,10 @@
+import pytest
+from metrics import percentage
+
+@pytest.mark.parametrize('part,total,expected', [(15,60,25), (30,60,50)])
+def test_fractions(part,total,expected):
+    assert percentage(part,total) == pytest.approx(expected)
+
+def test_nonpositive_total():
+    with pytest.raises(ValueError):
+        percentage(1,0)
```
