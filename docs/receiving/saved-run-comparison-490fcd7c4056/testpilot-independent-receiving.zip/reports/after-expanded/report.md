# TestPilot report: **passed**

- Changed functions: metrics.py::percentage
- Tests written: 5 in tests/test_percent_boundaries.py, tests/test_percent_generated.py
- Repair rounds used: 0/0
- Final run: 6 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 5 passed of 5 collected in 0.603s
- Coverage (total): 75.0% -> 100.0% (+25.0 pts)
- Coverage (changed lines, n=3): 66.7% -> 100.0%
- Tokens: 521 (estimated); cost: $0.001625
  - `fixture-planner`: 1 calls, 119 in / 34 out
  - `fixture-editor`: 1 calls, 204 in / 164 out

## Patch

```diff
diff --git a/tests/test_percent_boundaries.py b/tests/test_percent_boundaries.py
new file mode 100644
--- /dev/null
+++ b/tests/test_percent_boundaries.py
@@ -0,0 +1,8 @@
+# Literal display control: </script><img src=x onerror=window.__testpilotInjected=1> & Δ
+from metrics import percentage
+
+def test_zero_part():
+    assert percentage(0,17) == 0
+
+def test_complete_total():
+    assert percentage(17,17) == 100
diff --git a/tests/test_percent_generated.py b/tests/test_percent_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_percent_generated.py
@@ -0,0 +1,10 @@
+import pytest
+from metrics import percentage
+
+@pytest.mark.parametrize('part,total,expected', [(15,60,25), (30,60,50)])
+def test_fractions(part,total,expected):
+    assert percentage(part,total) == pytest.approx(expected)
+
+def test_nonpositive_total():
+    with pytest.raises(ValueError):
+        percentage(1,0)
```
