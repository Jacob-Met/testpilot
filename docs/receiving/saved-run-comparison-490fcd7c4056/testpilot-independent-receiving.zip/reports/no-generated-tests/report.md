# TestPilot report: **no_tests**

model produced no test files

- Changed functions: metrics.py::percentage
- Tests written: 0 in -
- Repair rounds used: 0/0
- Coverage: unavailable
- Tokens: 367 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `fixture-planner`: 1 calls, 119 in / 34 out
  - `fixture-editor`: 1 calls, 204 in / 10 out
