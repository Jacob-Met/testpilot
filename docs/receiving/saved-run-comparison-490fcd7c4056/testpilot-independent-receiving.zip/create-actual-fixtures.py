from pathlib import Path
import difflib,hashlib,json,os,shutil,sys,time
ROOT=Path("/dev/shm/tp490f-ir")
AUTHOR=Path("/dev/shm/testpilot-490f-compare")
SOURCE=ROOT/"baseline-source";SOURCE.mkdir(exist_ok=True)
EVIDENCE=ROOT/"evidence";EVIDENCE.mkdir(exist_ok=True)
manifest=json.loads((AUTHOR/"evidence/source-manifest.json").read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
for row in manifest["sourceFiles"]:
    b=(AUTHOR/"baseline"/row["path"]).read_bytes()
    assert sha(b)==row["sha256"] and blob(b)==row["gitBlob"],row["path"]
    p=SOURCE/row["path"];p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert p.read_bytes()==b
    else:p.write_bytes(b)
(EVIDENCE/"baseline-source-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
sys.path.insert(0,str(SOURCE))
from testpilot.loop import TestPilot,write_outputs
from testpilot.model import ScriptedModel,RoutingConfig
PYTHON="/home/jacob/hamon-universal-e3a41d2b3368-testpilot-main-9f01/complete-tooling-receiving/venv-pytest9-complete/bin/python"
assert Path(PYTHON).is_file()
FENCE=chr(96)*3
literal="</script><img src=x onerror=window.__testpilotInjected=1> & Δ"
good="def percentage(part, total):\n    if total <= 0:\n        raise ValueError('total must be positive')\n    return part * 100 / total\n"
bad=good.replace("part * 100 / total","part * total / 100")
prior="def percentage(part, total):\n    return part\n"
base_tests="import pytest\nfrom metrics import percentage\n\n@pytest.mark.parametrize('part,total,expected', [(15,60,25), (30,60,50)])\ndef test_fractions(part,total,expected):\n    assert percentage(part,total) == pytest.approx(expected)\n\ndef test_nonpositive_total():\n    with pytest.raises(ValueError):\n        percentage(1,0)\n"
expanded="# Literal display control: "+literal+"\nfrom metrics import percentage\n\ndef test_zero_part():\n    assert percentage(0,17) == 0\n\ndef test_complete_total():\n    assert percentage(17,17) == 100\n"
specs=[
 {"name":"before-bug","source":bad,"coverage":True,"expected":"suspected_code_bug","repair":1,"files":{"tests/test_percent_generated.py":base_tests}},
 {"name":"after-fixed","source":good,"coverage":True,"expected":"passed","repair":0,"files":{"tests/test_percent_generated.py":base_tests}},
 {"name":"after-expanded","source":good,"coverage":True,"expected":"passed","repair":0,"files":{"tests/test_percent_generated.py":base_tests,"tests/test_percent_boundaries.py":expanded},"priced":True},
 {"name":"coverage-unavailable","source":good,"coverage":False,"expected":"passed","repair":0,"files":{"tests/test_percent_generated.py":base_tests}},
 {"name":"no-generated-tests","source":good,"coverage":True,"expected":"no_tests","repair":0,"files":{}},
 {"name":"different-target","source":"def unit_fraction(part,total):\n    if total == 0:\n        raise ValueError('zero denominator')\n    return part / total\n","prior":"def unit_fraction(part,total):\n    return part\n","module":"ratios","coverage":True,"expected":"passed","repair":0,"files":{"tests/test_percent_generated.py":"from ratios import unit_fraction\n\ndef test_quarter():\n    assert unit_fraction(1,4) == .25\n"}}
]
results=[];start=time.time()
for spec in specs:
    name=spec["name"];repo=ROOT/"projects"/name;out=ROOT/"reports"/name
    repo.mkdir(parents=True,exist_ok=False);(repo/"tests").mkdir()
    module=spec.get("module","metrics");rel=module+".py"
    (repo/rel).write_text(spec["source"])
    existing="from ratios import unit_fraction\n\ndef test_half():\n    assert unit_fraction(1,2)==.5\n" if module=="ratios" else "from metrics import percentage\n\ndef test_whole():\n    assert percentage(100,100)==100\n"
    (repo/"tests/test_existing.py").write_text(existing)
    diff="".join(difflib.unified_diff(spec.get("prior",prior).splitlines(True),spec["source"].splitlines(True),"a/"+rel,"b/"+rel))
    diff="diff --git a/"+rel+" b/"+rel+"\n"+diff
    files=spec["files"];reply="\n".join(FENCE+"python path="+p+"\n"+c+FENCE for p,c in files.items()) or "No generated Python files are available."
    responses=["Inspect fractions, boundary values and zero denominators. Literal text: "+literal,reply]
    if spec["repair"]:responses.append("VERDICT: CODE_BUG The implementation multiplies by total instead of dividing; the recorded fractions expose that mismatch.")
    client=ScriptedModel(responses,name="independent-percentage-fixture")
    prices={"fixture-planner":(3.0,6.0),"fixture-editor":(2.0,4.0)} if spec.get("priced") else {}
    routing=RoutingConfig(planner_model="fixture-planner",editor_model="fixture-editor",prices=prices)
    before={str(p.relative_to(repo)):sha(p.read_bytes()) for p in repo.rglob("*") if p.is_file()}
    result=TestPilot(client,routing,max_repair_rounds=spec["repair"],timeout_s=20,coverage=spec["coverage"],python=PYTHON).run(repo,diff)
    assert result.status==spec["expected"],(name,result.status,result.message)
    output=write_outputs(result,out)
    assert before=={str(p.relative_to(repo)):sha(p.read_bytes()) for p in repo.rglob("*") if p.is_file()},name
    raw=output["json"].read_bytes();record=result.to_dict()
    row={"name":name,"status":record["status"],"report":str(output["json"]),"bytes":len(raw),"sha256":sha(raw),"recorded_target":[x["path"]+"::"+x["qualname"] for x in record["changed_functions"]],"tests_written":record["tests_written"],"final_generated":record["final"].get("generated") if record["final"] else None,"coverage":record["coverage"],"cost_is_complete":record["ledger"]["cost_is_complete"],"total_cost_usd":record["ledger"]["total_cost_usd"],"scripted_calls":len(client.calls),"repository_inputs_unchanged":True}
    (out/"fixture-context.json").write_text(json.dumps({"name":name,"syntheticFixture":True,"nativeProducerBase":manifest["baseCommit"],"diff":diff,"projectSourceHashes":before,"routingModels":["fixture-planner","fixture-editor"],"fixturePricesPerMillion":prices},indent=2)+"\n")
    results.append(row)
raw=(ROOT/"reports/after-expanded/report.json").read_bytes()
variant=ROOT/"reports/whitespace-and-unicode.json"
variant.write_bytes(b" \n\t"+json.dumps(json.loads(raw),ensure_ascii=False,indent=3).replace("\n","\r\n").encode()+b"\n \t")
results.append({"name":"transport-only-variant","report":str(variant),"sha256":sha(variant.read_bytes()),"bytes":variant.stat().st_size,"same_value_as":"after-expanded","derived_transport_only":True})
unchanged=all(sha((SOURCE/x["path"]).read_bytes())==x["sha256"] for x in manifest["sourceFiles"])
assert unchanged
receipt={"producer_base":manifest["baseCommit"],"producer_source_files":len(manifest["sourceFiles"]),"producer_sources_unchanged":unchanged,"sandbox_python":PYTHON,"driver_sha256":sha(Path(__file__).read_bytes()),"actual_run_count":len(specs),"actual_reports":results,"seconds":round(time.time()-start,3),"no_external_provider":True,"fixture_models_are_scripted":True}
(EVIDENCE/"actual-run-fixtures.json").write_text(json.dumps(receipt,indent=2)+"\n")
(EVIDENCE/"setup-notes.txt").write_text("The default Python import check found no coverage package before any case ran. Reused the already installed complete pytest9/coverage interpreter read-only; no dependency installation or environment modification occurred.\n")
print(json.dumps(receipt))
