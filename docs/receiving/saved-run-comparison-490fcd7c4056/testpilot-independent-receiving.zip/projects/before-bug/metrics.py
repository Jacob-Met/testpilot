def percentage(part, total):
    if total <= 0:
        raise ValueError('total must be positive')
    return part * total / 100
