from ratios import unit_fraction

def test_half():
    assert unit_fraction(1,2)==.5
