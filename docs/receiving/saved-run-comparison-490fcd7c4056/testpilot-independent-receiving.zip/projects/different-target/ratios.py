def unit_fraction(part,total):
    if total == 0:
        raise ValueError('zero denominator')
    return part / total
