def percentage(part, total):
    if total <= 0:
        raise ValueError('total must be positive')
    return part * 100 / total
