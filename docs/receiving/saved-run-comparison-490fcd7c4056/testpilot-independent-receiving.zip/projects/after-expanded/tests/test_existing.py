from metrics import percentage

def test_whole():
    assert percentage(100,100)==100
