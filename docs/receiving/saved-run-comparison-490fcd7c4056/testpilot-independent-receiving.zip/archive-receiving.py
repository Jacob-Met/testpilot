from pathlib import Path
import base64,hashlib,json,stat,zipfile
root=Path('/dev/shm/tp490f-ir')
archive=Path('/dev/shm/testpilot-independent-490fcd7c4056.zip')
assert not archive.exists()
members=[]; special=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  if stat.S_ISDIR(s.st_mode):continue
  if not stat.S_ISREG(s.st_mode):
   special.append({'path':str(p.relative_to(root)),'kind':'fifo' if stat.S_ISFIFO(s.st_mode) else 'nonregular','mode':s.st_mode});continue
  b=p.read_bytes();name=str(p.relative_to(root));z.writestr(name,b)
  members.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 z.writestr('archive-manifest.json',json.dumps({'members':members,'special_files_not_serialized':special},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
b=archive.read_bytes()
encoded=base64.b64encode(b).decode();transport=Path('/dev/shm/testpilot-independent-490fcd7c4056.b64')
transport.write_text('\n'.join(encoded[i:i+131072] for i in range(0,len(encoded),131072))+'\n')
meta={'archive_path':str(archive),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'verified_members':len(members)+1,'special_files':special,'transport_path':str(transport),'base64_characters':len(encoded),'transport_lines':(len(encoded)+131071)//131072}
Path('/dev/shm/testpilot-independent-490fcd7c4056-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
