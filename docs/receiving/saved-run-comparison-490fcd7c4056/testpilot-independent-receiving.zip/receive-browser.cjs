const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
const { chromium } = require('/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules/playwright');
const ROOT='/dev/shm/tp490f-ir', E=path.join(ROOT,'evidence/browser');
fs.mkdirSync(path.join(E,'downloads'),{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const cli=JSON.parse(fs.readFileSync(path.join(ROOT,'evidence/independent-cli-receipt.json'),'utf8'));
const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'evidence/candidate-source-manifest.json'),'utf8'));
const rows=Array.isArray(manifest)?manifest:manifest.sourceFiles;
function sourcePins(){return rows.map(x=>({path:x.path,sha256:sha(fs.readFileSync(path.join(ROOT,'source',x.path)))}));}
const initialPins=sourcePins();
const receipt={driver_sha256:sha(fs.readFileSync(__filename)),candidate_manifest_sha256:cli.source_manifest_sha256,cli_receipt_sha256:sha(fs.readFileSync(path.join(ROOT,'evidence/independent-cli-receipt.json'))),javaScriptEnabled:true,groups:[],downloads:[],external_requests:[],page_errors:[],console_errors:[],passed:false};
let browser,context,page,active='launch';const started=Date.now();
async function load(name, width=1280){
  active=name;
  const rec=cli.positive.find(x=>x.name===name);assert.ok(rec);
  await page.setViewportSize({width,height:900});
  await page.goto(pathToFileURL(rec.output).href,{waitUntil:'load'});
  await page.locator('h1').waitFor();
  assert.equal(await page.title(),'Compare saved TestPilot runs');
  assert.equal(await page.locator('script').count(),0);
  assert.equal(await page.locator('img,iframe,object,embed').count(),0);
  assert.equal(await page.evaluate(()=>typeof window.__testpilotInjected),'undefined');
  assert.equal(sha(fs.readFileSync(rec.output)),rec.output_sha256);
  for(const role of ['before','after']){
    assert.equal(sha(fs.readFileSync(rec[role])),rec[role+'_sha256']);
    assert.ok((await page.locator('#originals').innerText()).includes(rec[role+'_sha256']));
  }
  const dimensions=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
  assert.ok(dimensions.document<=width && dimensions.body<=width,JSON.stringify(dimensions));
  return {rec,dimensions};
}
async function table(section){return Object.fromEntries(await page.locator(section+' tbody tr').evaluateAll(trs=>trs.map(tr=>Array.from(tr.cells,c=>c.textContent)).map(r=>[r[0],r.slice(1)])));}
async function openWithKeyboard(locator){
  const detail=locator.locator('..');const wasOpen=await detail.getAttribute('open');
  if(wasOpen===null){await locator.focus();await page.keyboard.press('Enter');assert.notEqual(await detail.getAttribute('open'),null);}
}
async function anchorWithKeyboard(label,id){
  await page.getByRole('navigation',{name:'Report sections'}).getByRole('link',{name:label,exact:true}).focus();
  await page.keyboard.press('Enter');await page.waitForURL(url=>url.hash==='#'+id);
}
async function downloads(rec){
  const items=[];
  for(const role of ['before','after']){
    const pending=page.waitForEvent('download');
    await page.locator('#download-'+role).focus();await page.keyboard.press('Enter');
    const d=await pending;assert.equal(d.suggestedFilename(),role+'-report.json');
    const saved=path.join(E,'downloads',rec.name+'-'+role+'.json');await d.saveAs(saved);
    assert.deepEqual(fs.readFileSync(saved),fs.readFileSync(rec[role]));
    items.push({comparison:rec.name,role,suggested_filename:d.suggestedFilename(),saved,bytes:fs.statSync(saved).size,sha256:sha(fs.readFileSync(saved))});
  }
  receipt.downloads.push(...items);return items;
}
async function shot(name){const p=path.join(E,name);await page.screenshot({path:p,fullPage:false});return{path:p,bytes:fs.statSync(p).size,sha256:sha(fs.readFileSync(p))};}
(async()=>{
 try{
  browser=await chromium.launch({executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  receipt.browser=browser.version();receipt.node=process.version;receipt.playwright=require('/home/jacob/.cache/returnby-backup-8b336fefde84/node_modules/playwright/package.json').version;
  context=await browser.newContext({acceptDownloads:true,javaScriptEnabled:true,viewport:{width:1280,height:900}});
  await context.route(/^https?:\/\//,route=>{receipt.external_requests.push(route.request().url());return route.abort();});
  page=await context.newPage();page.on('pageerror',e=>receipt.page_errors.push(e.message));page.on('console',m=>{if(m.type()==='error')receipt.console_errors.push(m.text());});
  {
   const {rec,dimensions}=await load('bug-to-fix');
   const results=await table('#results');
   assert.deepEqual(results['Recorded status'],['suspected_code_bug','passed']);
   assert.deepEqual(results['Tests written (reported)'],['3','3']);
   assert.deepEqual(results['Generated-case recorded counts'],['3 collected, 1 passed, 2 failed, 0 error, 0 skipped','3 collected, 3 passed, 0 failed, 0 error, 0 skipped']);
   assert.equal(await page.locator('.context strong').innerText(),'Matching target labels; selected source differs');
   assert.deepEqual((await table('#files'))['tests/test_percent_generated.py'].slice(0,1),['unchanged']);
   await anchorWithKeyboard('Selected source','source');
   const summary=page.locator('#source summary').first();await openWithKeyboard(summary);
   const source=await page.locator('#source').innerText();
   assert.ok(source.includes('part * total / 100'));assert.ok(source.includes('part * 100 / total'));
   await anchorWithKeyboard('Diagnostics','diagnostics');
   const failure=page.locator('#diagnostics summary').filter({hasText:'failed'}).first();await openWithKeyboard(failure);
   assert.ok((await page.locator('#diagnostics').innerText()).includes('AssertionError'));
   await anchorWithKeyboard('Original reports','originals');
   const saved=await downloads(rec);
   await page.goto(pathToFileURL(rec.output).href,{waitUntil:'load'});
   receipt.groups.push({name:'actual_bug_to_fix',passed:true,dimensions,results,downloads:saved.length,screenshot:await shot('desktop-bug-to-fix.png')});
  }
  {
   const {rec,dimensions}=await load('expanded-tests',390);
   assert.equal(await page.locator('.context strong').innerText(),'Same reported target records');
   const results=await table('#results');assert.deepEqual(results['Tests written (reported)'],['3','5']);
   const files=await table('#files');
   assert.equal(files['tests/test_percent_generated.py'][0],'unchanged');
   const added=Object.entries(files).find(([p,r])=>r[0]==='added');assert.ok(added);
   const usage=await table('#usage');assert.deepEqual(usage['Recorded total cost'],['Unpriced / incomplete','USD 0.001625']);
   await anchorWithKeyboard('Generated files','files');
   assert.ok((await page.locator('#files').innerText()).includes('</script><img src=x onerror=window.__testpilotInjected=1> & Δ'));
   const addedSummary=page.locator('#files summary').filter({hasText:added[0]});await openWithKeyboard(addedSummary);
   const layout=await page.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth,source_scroll_regions:Array.from(document.querySelectorAll('pre')).filter(x=>x.scrollWidth>x.clientWidth).length}));
   assert.equal(layout.document,390);assert.ok(layout.source_scroll_regions>0);
   const sourceShot=await shot('phone-expanded-files.png');
   await anchorWithKeyboard('Original reports','originals');const saved=await downloads(rec);
   receipt.groups.push({name:'expanded_tests_phone_pricing_and_literal_text',passed:true,dimensions,layout,results,added_file:added[0],recorded_costs:usage['Recorded total cost'],downloads:saved.length,screenshot:sourceShot});
  }
  {
   const {dimensions}=await load('missing-coverage',390);const coverage=await table('#coverage');
   assert.equal(Object.keys(coverage).length,6);
   for(const values of Object.values(coverage)){assert.equal(values[1],'Unavailable');assert.notEqual(values[0],'Unavailable');}
   assert.deepEqual((await table('#results'))['Generated-case recorded counts'],['3 collected, 3 passed, 0 failed, 0 error, 0 skipped','3 collected, 3 passed, 0 failed, 0 error, 0 skipped']);
   assert.ok((await page.locator('#coverage').innerText()).includes('within that original run'));
   receipt.groups.push({name:'coverage_unavailable_preserved_with_real_pass_counts',passed:true,dimensions,coverage});
  }
  {
   const {dimensions}=await load('no-final-result');
   const results=await table('#results');assert.deepEqual(results['Tests written (reported)'],['3','0']);
   assert.equal(results['Recorded status'][1],'no_tests');
   assert.equal(results['JUnit availability'][1],'No test result recorded');
   assert.equal(results['Generated-case recorded counts'][1],'Unavailable as complete execution evidence');
   assert.equal(results['Complete-suite recorded counts'][1],'Unavailable as complete execution evidence');
   assert.ok((await page.locator('#diagnostics').innerText()).includes('No final test result is recorded.'));
   receipt.groups.push({name:'actual_no_generated_tests_does_not_invent_execution',passed:true,dimensions,results});
  }
  {
   const {dimensions}=await load('different-targets',390);
   assert.equal(await page.locator('.context strong').innerText(),'Different selected targets');
   const summaries=await page.locator('#source summary').allTextContents();
   assert.deepEqual(summaries,['metrics.py::percentage','ratios.py::unit_fraction']);
   for(const summary of await page.locator('#source summary').all())await openWithKeyboard(summary);
   assert.equal(await page.locator('#source .empty').count(),2);
   assert.ok((await page.locator('#source').innerText()).includes('do not establish a full repository, commit, test configuration, or execution-environment identity'));
   assert.equal((await table('#files'))['tests/test_percent_generated.py'][0],'changed');
   receipt.groups.push({name:'different_targets_preserve_addition_removal_context',passed:true,dimensions,targets:summaries});
  }
  {
   const {rec,dimensions}=await load('same-values-different-bytes',390);
   assert.notEqual(rec.before_sha256,rec.after_sha256);
   assert.equal(await page.locator('.context strong').innerText(),'Same reported target records');
   for(const values of Object.values(await table('#results')))assert.equal(values[0],values[1]);
   for(const values of Object.values(await table('#files')))assert.equal(values[0],'unchanged');
   for(const sum of await page.locator('#files summary').all())await openWithKeyboard(sum);
   assert.ok((await page.locator('#files').innerText()).includes('</script><img src=x onerror=window.__testpilotInjected=1> & Δ'));
   assert.equal(await page.locator('img,script').count(),0);
   await anchorWithKeyboard('Original reports','originals');const saved=await downloads(rec);
   const downloaded=fs.readFileSync(saved[1].saved);assert.deepEqual(downloaded.subarray(0,3),Buffer.from([0xef,0xbb,0xbf]));assert.ok(downloaded.includes(Buffer.from('\r\n')));
   assert.ok(downloaded.includes(Buffer.from('Δ')));
   receipt.groups.push({name:'semantic_equality_with_distinct_BOM_CRLF_unicode_bytes',passed:true,dimensions,downloads:saved.length,before_sha256:rec.before_sha256,after_sha256:rec.after_sha256});
  }
  assert.equal(receipt.external_requests.length,0);assert.equal(receipt.page_errors.length,0);assert.equal(receipt.console_errors.length,0);
  assert.deepEqual(sourcePins(),initialPins);receipt.all31_source_hashes_unchanged=true;receipt.passed=true;
 }catch(e){receipt.failed_group=active;receipt.error=e.stack;if(page){try{fs.writeFileSync(path.join(E,'failed-page-text.txt'),await page.locator('body').innerText());receipt.failure_screenshot=await shot('failed.png');}catch{}}process.exitCode=1;}
 finally{if(browser)await browser.close();receipt.seconds=(Date.now()-started)/1000;const p=path.join(E,'independent-browser-receipt.json');fs.writeFileSync(p,JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({passed:receipt.passed,groups:receipt.groups.length,downloads:receipt.downloads.length,failed_group:receipt.failed_group,error:receipt.error,seconds:receipt.seconds,receipt_sha256:sha(fs.readFileSync(p))}));}
})();