# TestPilot report: **passed**

- Changed functions: calc.py::clamp
- Tests written: 4 in tests/test_calc_clamp.py
- Repair rounds used: 0/1
- Final run: 6 passed, 0 failed, 0 errors, 0 skipped (rc=0); generated: 4 passed of 4 collected in 0.346s
- Coverage (total): 60.0% -> 90.0% (+30.0 pts)
- Coverage (changed lines, n=4): 25.0% -> 100.0%
- Tokens: 513 (estimated); cost: unpriced (set TESTPILOT_PRICES)
  - `nvidia/nemotron-3-super-120b-a12b`: 1 calls, 125 in / 51 out
  - `nvidia/Nemotron-3_5-Lightning`: 1 calls, 228 in / 109 out

## Patch

```diff
diff --git a/tests/test_calc_clamp.py b/tests/test_calc_clamp.py
new file mode 100644
--- /dev/null
+++ b/tests/test_calc_clamp.py
@@ -0,0 +1,22 @@
+import pytest
+
+from calc import clamp
+
+
+def test_inside_range_unchanged():
+    assert clamp(5, 0, 10) == 5
+
+
+def test_below_and_above():
+    assert clamp(-3, 0, 10) == 0
+    assert clamp(42, 0, 10) == 10
+
+
+def test_boundaries():
+    assert clamp(0, 0, 10) == 0
+    assert clamp(10, 0, 10) == 10
+
+
+def test_inverted_bounds_raise():
+    with pytest.raises(ValueError):
+        clamp(1, 10, 0)
```
