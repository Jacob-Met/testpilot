from pathlib import Path
import shutil,json,hashlib,subprocess,os,time,sys
r=Path(__file__).resolve().parent; source=r/'baseline'; evidence=r/'evidence'/'baseline';evidence.mkdir(exist_ok=True)
py='/home/jacob/hamon-universal-e3a41d2b3368-testpilot-main-9f01/complete-tooling-receiving/venv-pytest9-complete/bin/python'
case=source/'eval/cases/calc_clamp'
manifest=json.loads((r/'evidence/source-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for row in manifest['sourceFiles']:assert sha((source/row['path']).read_bytes())==row['sha256']
for name in ['before','after']:
 target=r/'fixtures'/name
 assert not target.exists()
 shutil.copytree(case/'repo',target)
 if name=='after':(target/'calc.py').write_bytes((case/'fix/calc.py').read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('TESTPILOT_')}
env.update(PYTHONPATH=str(source),TMPDIR='/dev/shm/tp490f-tmp',PYTHONDONTWRITEBYTECODE='1')
commands=[];outputs={}
for name in ['before','after']:
 out=evidence/name
 cmd=[py,'-B','-m','testpilot','run','--repo',str(r/'fixtures'/name),'--diff',str(case/'change.diff'),'--backend','scripted','--script',str(case/'script'),'--out',str(out),'--rounds','1','--timeout','15','--python',py]
 at=time.monotonic();p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True,timeout=90)
 (evidence/(name+'-stdout.txt')).write_text(p.stdout);(evidence/(name+'-stderr.txt')).write_text(p.stderr)
 assert p.returncode==({'before':1,'after':0}[name]),(name,p.returncode,p.stdout,p.stderr)
 report=json.loads((out/'report.json').read_text())
 assert report['status']==({'before':'suspected_code_bug','after':'passed'}[name]),report['status']
 outputs[name]={'status':report['status'],'reportSha256':sha((out/'report.json').read_bytes()),'final':report['final'],'ledger':report['ledger'],'reportKeys':list(report)}
 commands.append({'argv':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-at})
requested=evidence/'missing-comparison.html'
cmd=[py,'-B','-m','testpilot','compare','--before',str(evidence/'before/report.json'),'--after',str(evidence/'after/report.json'),'--out',str(requested)]
p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True,timeout=10)
assert p.returncode==2 and not requested.exists()
(evidence/'missing-command-stdout.txt').write_text(p.stdout);(evidence/'missing-command-stderr.txt').write_text(p.stderr)
commands.append({'argv':cmd,'exitCode':p.returncode,'outputExists':requested.exists()})
for row in manifest['sourceFiles']:assert sha((source/row['path']).read_bytes())==row['sha256']
receipt={'base':manifest['baseCommit'],'sourceFilesUnchanged':len(manifest['sourceFiles']),'commands':commands,'outputs':outputs,'provider':'Actual ScriptedModel only; no network provider calls','candidateSourceModified':False}
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'sourceFilesUnchanged':len(manifest['sourceFiles']),'statuses':{k:v['status'] for k,v in outputs.items()},'reportHashes':{k:v['reportSha256'] for k,v in outputs.items()},'missingCommandExit':p.returncode,'receiptSha256':sha((evidence/'receipt.json').read_bytes())}))
