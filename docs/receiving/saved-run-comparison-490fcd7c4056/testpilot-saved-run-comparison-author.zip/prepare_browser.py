import copy, hashlib, json, os, pathlib, sys
ROOT=pathlib.Path('/dev/shm/testpilot-490f-compare')
sys.path.insert(0,str(ROOT/'candidate'))
from testpilot.compare import write_comparison
out=ROOT/'evidence/candidate/browser'
out.mkdir(parents=True,exist_ok=True)
before=json.loads((ROOT/'evidence/baseline/before/report.json').read_bytes())
after=json.loads((ROOT/'evidence/baseline/after/report.json').read_bytes())
literal='<img src="https://saved-literal.invalid/x" onerror="alert(1)"> & </script> "quote"'
before['message']=literal+'\r\nliteral separator:\u2028 lone surrogate:\ud800'
before['final']['junit_available']=False
before['tests_written']=731
before['coverage']=None
before['ledger']['cost_is_complete']=False
before['ledger']['total_cost_usd']=12.345
before['final']['cases'][0]['message']=literal
after['test_files']['tests/test_empty_added.py']=''
after['test_files']['tests/test_literal<&>.py']='def test_literal():\r\n    assert '+repr(literal)+'\r\n'
after['changed_functions'][0]['source'] += '\n# literal:'+literal+'\n'
before['extra_review_fixture']={'unrendered':'retained exactly','number':1.25}
after['extra_review_fixture']={'role':'changed input, not an actual second execution'}
left=out/'literal-before.json';right=out/'literal-after.json'
left.write_bytes(b'\xef\xbb\xbf'+json.dumps(before,ensure_ascii=True,indent=2).replace('\n','\r\n').encode('utf-8')+b'\r\n')
right.write_bytes(json.dumps(after,ensure_ascii=True,separators=(',',':')).encode('utf-8')+b'\n')
write_comparison(left,right,out/'literal-pair.html')
paths=[ROOT/'evidence/baseline/before/report.json',ROOT/'evidence/baseline/after/report.json',ROOT/'evidence/candidate/native-pair.html',left,right,out/'literal-pair.html']
manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
(out/'fixtures.json').write_text(json.dumps({'kind':'author browser fixtures, including clearly modified saved reports','files':manifest},indent=2)+'\n')
print(json.dumps({'files':manifest,'freeTmpfs':os.statvfs('/dev/shm').f_bavail*os.statvfs('/dev/shm').f_frsize}))
