def add_fee(amount):
    return amount + 2
