from fees import add_fee

def test_integer_type():
    assert isinstance(add_fee(0), int)
