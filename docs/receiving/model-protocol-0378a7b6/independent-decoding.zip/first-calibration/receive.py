# Independent receiving; Apache-2.0, matching the reviewed project.
import hashlib,json,os,pathlib,subprocess,sys,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=pathlib.Path(sys.argv[1]); PIN=sys.argv[2]; OUT=pathlib.Path(__file__).resolve().parent
MODEL=ROOT/"testpilot/model.py"
sha=lambda b:hashlib.sha256(b).hexdigest()
def sources(): return {p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in (ROOT/"testpilot").glob("*.py")}
before=sources();assert before["testpilot/model.py"]==PIN
LIMIT=sys.get_int_max_str_digits();assert LIMIT>0
BODIES={"integer":b'{"choices":[{"message":{"content":"unusable"}}],"usage":{"prompt_tokens":'+b"9"*(LIMIT+1)+b',"completion_tokens":1}}',"recursion":b"["*(sys.getrecursionlimit()+100)+b"0"+b"]"*(sys.getrecursionlimit()+100)}
calibration={}
for name,blob in BODIES.items():
    try:json.loads(blob)
    except (ValueError,RecursionError) as exc:calibration[name]=type(exc).__name__
assert calibration=={"integer":"ValueError","recursion":"RecursionError"},calibration
PLAN="Pin add_fee(4) == 6 while keeping the existing integer-type control."
FENCE=chr(96)*3
def completion(value):return FENCE+"python path=tests/test_generated_fee.py\nfrom fees import add_fee\n\ndef test_fee():\n    assert add_fee(4) == "+str(value)+"\n"+FENCE
BAD=completion(999);GOOD=completion(6)
env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),NEBIUS_API_KEY="independent-loopback-placeholder",TESTPILOT_PLANNER_MODEL="independent-plan",TESTPILOT_EDITOR_MODEL="independent-editor",TESTPILOT_PRICES="{}",PYTHONUTF8="1")
results=[]
for case in ("integer","recursion","incomplete200","incomplete400","incomplete503","valid"):
    area=OUT/case;area.mkdir(exist_ok=False);repo=area/"repo";repo.mkdir();(repo/"tests").mkdir()
    (repo/"fees.py").write_text("def add_fee(amount):\n    return amount\n",encoding="utf-8")
    (repo/"tests/test_existing.py").write_text("from fees import add_fee\n\ndef test_integer_type():\n    assert isinstance(add_fee(0), int)\n",encoding="utf-8")
    def git(*args):return subprocess.check_output(["git","-C",str(repo),*args],stderr=subprocess.STDOUT)
    git("init","-q");git("add",".");git("-c","user.name=Independent Fixture","-c","user.email=fixture@example.invalid","commit","-qm","authored before")
    (repo/"fees.py").write_text("def add_fee(amount):\n    return amount + 2\n",encoding="utf-8")
    diff=area/"change.diff";diff.write_bytes(git("diff","--","fees.py"))
    original={p.relative_to(repo).as_posix():sha(p.read_bytes()) for p in repo.rglob("*.py")}
    requests=[];wire=[]
    class Handler(BaseHTTPRequestHandler):
        protocol_version="HTTP/1.1"
        def log_message(self,*args):pass
        def do_POST(self):
            request=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            requests.append({"path":self.path,"model":request["model"],"payload":request})
            n=len(requests);status=200;extra=0
            content=PLAN if n==1 else BAD if n==2 else GOOD
            blob=json.dumps({"model":request["model"],"choices":[{"message":{"content":content}}],"usage":{"prompt_tokens":3,"completion_tokens":2}}).encode()
            if n>=3 and case in BODIES:blob=BODIES[case]
            if n>=3 and case.startswith("incomplete"):
                status=int(case[len("incomplete"):]);blob=b'{"partial":"independent body"}';extra=37
            wire.append({"status":status,"declared_bytes":len(blob)+extra,"actual_bytes":len(blob),"sha256":sha(blob)})
            (area/("reply-"+str(n)+".bin")).write_bytes(blob)
            self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(blob)+extra));self.send_header("Connection","close");self.end_headers()
            self.wfile.write(blob);self.wfile.flush();self.close_connection=True
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler);server.daemon_threads=True
    worker=threading.Thread(target=server.serve_forever,kwargs={"poll_interval":0.02},daemon=True);worker.start()
    try:
        cmd=[sys.executable,"-m","testpilot","run","--repo",str(repo),"--diff",str(diff),"--backend","openai","--base-url",f"http://127.0.0.1:{server.server_port}/v1/","--rounds","1","--timeout","20","--no-coverage","--python",sys.executable,"--out",str(area/"output")]
        proc=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=70)
    finally:server.shutdown();server.server_close();worker.join(2)
    (area/"stdout.txt").write_bytes(proc.stdout);(area/"stderr.txt").write_bytes(proc.stderr)
    (area/"requests.json").write_text(json.dumps(requests,indent=2)+"\n")
    (area/"wire.json").write_text(json.dumps(wire,indent=2)+"\n")
    outputs=area/"output";required=("report.json","report.md","report.html","testpilot.patch")
    assert all((outputs/n).is_file() for n in required),(case,proc.returncode,proc.stderr.decode(errors="replace"))
    report=json.loads((outputs/"report.json").read_text());patch=(outputs/"testpilot.patch").read_text()
    expected="passed" if case=="valid" else "model_error"
    assert report["status"]==expected and proc.returncode==(0 if case=="valid" else 1),(case,report)
    assert report["plan"]==PLAN and report["repair_rounds_used"]==1
    assert len(requests)==(5 if case=="incomplete503" else 3),(case,len(requests))
    assert [x["model"] for x in requests]==["independent-plan"]+["independent-editor"]*(len(requests)-1)
    assert len(report["ledger"]["entries"])==(3 if case=="valid" else 2)
    assert report["ledger"]["total_tokens"]==(15 if case=="valid" else 10)
    if case!="valid":
        assert report["final"]["failed"]==1 and len(report["rounds"])==1
        assert "== 999" in patch and "test_generated_fee.py" in patch
        if case.startswith("incomplete") and case!="incomplete200":assert "HTTP "+case[len("incomplete"):] in report["message"]
    else:assert report["final"]["passed"]==2 and "== 6" in patch
    after={p.relative_to(repo).as_posix():sha(p.read_bytes()) for p in repo.rglob("*.py")}
    assert after==original
    check=subprocess.run(["git","-C",str(repo),"apply","--check",str(outputs/"testpilot.patch")],capture_output=True)
    assert check.returncode==0,(case,check.stderr)
    results.append({"case":case,"exit":proc.returncode,"requests":len(requests),"status":report["status"],"message":report.get("message"),"originals_preserved":True,"patch_applies":True,"output_sha256":{n:sha((outputs/n).read_bytes()) for n in required}})
    print(json.dumps(results[-1]),flush=True)
sys.path.insert(0,str(ROOT))
from testpilot.model import OpenAICompatClient
calls=[];sleeps=[];original=ValueError("independent custom transport sentinel")
def unrelated(*args):calls.append(1);raise original
client=OpenAICompatClient(api_key="independent-local-placeholder",transport=unrelated,sleep=sleeps.append)
try:client.chat("independent",[{"role":"user","content":"bounded countercontrol"}])
except ValueError as caught:assert caught is original
else:raise AssertionError("custom transport exception was swallowed")
assert len(calls)==1 and sleeps==[]
assert sources()==before
receipt={"at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"python":sys.version,"model_sha256":PIN,"source_map":before,"source_preserved":True,"calibration":calibration,"cli_cases":results,"custom_transport_valueerror_identity_preserved":True,"scope":"Six authored actual CLI/local HTTP receivers plus a custom-transport identity control; no provider, installation, source edit or repetition of the earlier23-case suite"}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print("INDEPENDENT RECEIVING PASSED",flush=True)
