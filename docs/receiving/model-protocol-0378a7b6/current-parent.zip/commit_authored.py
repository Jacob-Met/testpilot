from pathlib import Path
import subprocess, hashlib, json, datetime
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
PROOF = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
OUT = ROOT/"docs/receiving/model-protocol-0378a7b6"
def git(*args): return subprocess.check_output(["git","-C",str(ROOT),*args])
def sha(data): return hashlib.sha256(data).hexdigest()
base = git("rev-parse","HEAD").decode().strip()
assert base == "513f17454af378ee042ccd29dc930ef332a48734"
pins = json.loads((OUT/"adoption.json").read_bytes())["final_source_sha256"]
for name, expected in pins.items(): assert sha((ROOT/name).read_bytes()) == expected, name
addition = (PROOF/"readme-owned-addition.txt").read_bytes()
readme = (ROOT/"README.md").read_bytes()
assert readme.count(addition) == 1
assert readme.replace(addition,b"",1) == git("show",base+":README.md")
owned_existing = {"README.md","testpilot/model.py"}
unowned = {}
for entry in git("ls-tree","-r","-z",base).split(b"\0"):
    if not entry: continue
    meta, rel = entry.split(b"\t",1)
    mode, kind, blob = meta.decode().split()
    name = rel.decode()
    if name in owned_existing: continue
    assert kind == "blob" and mode in ("100644","100755"), (name,mode,kind)
    data = (ROOT/name).read_bytes()
    actual = hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert actual == blob, (name,actual,blob)
    unowned[name] = blob
(OUT/"README.md").write_bytes("""# Model response receiving

This native contribution addresses TestPilot issue #54. Its only runtime change is
the model-response boundary in testpilot/model.py; it preserves the existing loop,
sandbox, retry budget, report writers, request format and admitted-usage policy.

## Evidence

independent-admission.zip contains the original real-CLI data-loss reproduction
on baseline 513f174 and 23 independent CLI cases on candidate v1 (model SHA-256
0903eaf6...). Its original input contract and the separately documented compatibility
overlay are both retained. Existing integer coercion was deliberately preserved.

independent-decoding.zip contains six independent CLI cases on the final model
SHA-256 4cd8367f..., including native JSON decoder limits, truncated HTTP 200/400/503
bodies and successful repair. Four retained outputs, exact previous work, ledger
and retry behavior were checked. The receiver's initial too-shallow nesting
calibration failed before CLI execution and is preserved beside its corrected run.

author-receiving.zip preserves the authored changes, exact source versions,
drivers, raw logs, original four-file outputs and corrections. Candidate v1 first
recorded 53 passes and 7 author-test failures because the assertion used files
instead of the existing test_files field. Corrected assertions produced 61 passes.
The final model run produced 66 passes and 1 test-fixture failure: depth 1010 did
not reach the native JSON recursion limit. Only the fixture depth changed to 4000,
and that corrected case passed separately. These are historical runs, not one
full final-source pass; current-parent qualification is recorded separately.

Every independently supplied manifest and listed file was hash-checked before
adoption. Archive members were read back byte for byte. adoption.json records
archive and source hashes. Acceptance prose is copied unchanged alongside them.

## Publication boundary

The no-GitHub-Actions instruction was recovered from HAMON issue 143 comment
6067592767 during this work. No TestPilot source branch, PR, merge, or Actions
trigger has been published by this lane. Native work continues. Hosted gates are
unrun and remain required; a quota reset does not release the Actions hold.
Current-parent composition and receiving are recorded as subsequent native work.
""".encode())
receipt = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":base,"unchanged_unowned_leaves":len(unowned),"unowned_git_blobs":unowned,"owned_source_sha256":pins,"readme_projection_exact":True}
(OUT/"baseline-preservation.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
paths = ["README.md","testpilot/model.py","tests/test_model_protocol.py","docs/MODEL_RESPONSES.md","docs/receiving/model-protocol-0378a7b6"]
git("add","--",*paths[:4])
git("add","-f","--",paths[4])
git("diff","--cached","--check")
message = "fix(model): retain completed work after unusable model responses"
result = subprocess.run(["git","-C",str(ROOT),"-c","user.name=HAMON External Contributor 0378a7b6","-c","user.email=chatgpt-0378a7b6b7c2@users.noreply.github.com","commit","-m",message],capture_output=True)
(PROOF/"native-author-commit.stdout.log").write_bytes(result.stdout)
(PROOF/"native-author-commit.stderr.log").write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode(errors="replace")
receipt = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":git("rev-parse","HEAD").decode().strip(),"tree":git("rev-parse","HEAD^{tree}").decode().strip(),"status":git("status","--porcelain").decode(),"unchanged_unowned_leaves":len(unowned),"paths":git("diff-tree","--no-commit-id","--name-only","-r","HEAD").decode().splitlines()}
assert receipt["status"] == "",receipt["status"]
(PROOF/"native-author-commit.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps(receipt,indent=2))
