from pathlib import Path
import subprocess, hashlib, json, datetime, sys, time, os
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
P = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")/"current-parent-v2"
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(["git","-C",str(ROOT),*args])
source_paths = git("ls-files","-z").decode().split("\0")
before = {name:sha((ROOT/name).read_bytes()) for name in source_paths if name}
cmd = [sys.executable,"-m","pytest","-q","-rA"]
env = dict(os.environ,PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
start = time.time()
timeout = False
try:
    p = subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=600)
    stdout,stderr,code = p.stdout,p.stderr,p.returncode
except subprocess.TimeoutExpired as exc:
    stdout,stderr,code,timeout = exc.stdout or b"",exc.stderr or b"",-1,True
(P/"full-suite.stdout.log").write_bytes(stdout)
(P/"full-suite.stderr.log").write_bytes(stderr)
after = {name:sha((ROOT/name).read_bytes()) for name in before}
changes = [name for name in before if before[name] != after[name]]
receipt = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"runtime":sys.version,"exit_code":code,"timeout":timeout,"seconds":time.time()-start,"source_tree":git("write-tree").decode().strip(),"model_sha256":sha((ROOT/"testpilot/model.py").read_bytes()),"test_sha256":sha((ROOT/"tests/test_model_protocol.py").read_bytes()),"stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr),"checked_source_leaves":len(before),"changed_source_leaves":changes,"source_sha256_before":before}
(P/"full-suite.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps({k:v for k,v in receipt.items() if k!="source_sha256_before"},indent=2),flush=True)
print(stdout.decode("utf-8","replace")[-5000:],flush=True)
print(stderr.decode("utf-8","replace")[-1000:],flush=True)
assert not changes, changes
raise SystemExit(code)
