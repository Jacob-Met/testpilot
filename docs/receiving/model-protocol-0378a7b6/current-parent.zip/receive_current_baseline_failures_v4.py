from pathlib import Path
import subprocess, hashlib, json, datetime, sys, time, os, re
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
BASE = Path(r"C:\Users\minec\tp-base-0378a7b6")
P = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")/"current-parent-v2"
sha = lambda b: hashlib.sha256(b).hexdigest()
raw = (P/"full-suite.stdout.log").read_bytes()
failure_lines = [line for line in raw.decode("utf-8","replace").splitlines() if line.startswith("FAILED ") or line.startswith("SUBFAILED(")]
ids = list(dict.fromkeys(re.findall(r"^(?:FAILED\s+|SUBFAILED\(.*\)\s+)(tests/\S+)",raw.decode("utf-8","replace"),re.M)))
assert len(failure_lines) == 36 and len(ids) == 30, (failure_lines,ids)
assert not BASE.exists(), "Inspect existing baseline before any retry"
checkout = subprocess.run(["git","-C",str(ROOT),"worktree","add","--detach",str(BASE),"906ce149fba770a62c9f5f2fbc1b7238b949d423"],capture_output=True)
(P/"baseline-checkout-v4.stdout.log").write_bytes(checkout.stdout)
(P/"baseline-checkout-v4.stderr.log").write_bytes(checkout.stderr)
assert checkout.returncode == 0, checkout.stderr
git = lambda *args: subprocess.check_output(["git","-C",str(BASE),*args])
assert git("status","--porcelain") == b""
parent = git("rev-parse","HEAD").decode().strip()
cmd = [sys.executable,"-m","pytest","-q","-rA",*ids]
env = dict(os.environ,PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
start = time.time()
p = subprocess.run(cmd,cwd=BASE,env=env,capture_output=True,timeout=600)
(P/"baseline-36-v4.stdout.log").write_bytes(p.stdout)
(P/"baseline-36-v4.stderr.log").write_bytes(p.stderr)
baseline_lines = [line for line in p.stdout.decode("utf-8","replace").splitlines() if line.startswith("FAILED ") or line.startswith("SUBFAILED(")]
failed = list(dict.fromkeys(re.findall(r"^(?:FAILED\s+|SUBFAILED\(.*\)\s+)(tests/\S+)",p.stdout.decode("utf-8","replace"),re.M)))
receipt = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"parent":parent,"parent_tree":git("rev-parse","HEAD^{tree}").decode().strip(),"command":cmd,"runtime":sys.version,"exit_code":p.returncode,"seconds":time.time()-start,"candidate_failed_ids":ids,"baseline_failed_ids":failed,"same_failed_ids":sorted(ids)==sorted(failed),"candidate_failure_lines":failure_lines,"baseline_failure_lines":baseline_lines,"same_all36_failure_summaries":sorted(failure_lines)==sorted(baseline_lines),"model_sha256":sha((BASE/"testpilot/model.py").read_bytes()),"git_status_after":git("status","--porcelain").decode(),"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr)}
(P/"baseline-36-v4.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps(receipt,indent=2),flush=True)
print(p.stdout.decode("utf-8","replace")[-2000:],flush=True)
assert receipt["same_failed_ids"] and receipt["same_all36_failure_summaries"], receipt
assert not receipt["git_status_after"], receipt["git_status_after"]
