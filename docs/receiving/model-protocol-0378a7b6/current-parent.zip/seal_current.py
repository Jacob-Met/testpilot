from pathlib import Path
import hashlib, json, subprocess, zipfile, datetime, base64
ROOT=Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
P=Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
C=P/"current-parent-v2"
OUT=ROOT/"docs/receiving/model-protocol-0378a7b6"
PUB=Path(r"C:\Users\minec\testpilot-publication-0378a7b6")
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(["git","-C",str(ROOT),*args])
def put(path,value):path.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+"\n").encode())
focused=json.loads((C/"focused.json").read_bytes())
full=json.loads((C/"full-suite.json").read_bytes())
baseline=json.loads((C/"baseline-36-v4.json").read_bytes())
composition=json.loads((C/"composition.json").read_bytes())
boundary=json.loads((C/"workflow-publication-boundary.json").read_text(encoding="utf-8-sig"))
assert focused["exit_code"]==0 and "67 passed" in (C/"focused.stdout.log").read_text(encoding="utf-8")
assert full["exit_code"]==1 and not full["changed_source_leaves"]
assert baseline["same_all36_failure_summaries"] and baseline["same_failed_ids"] and not baseline["git_status_after"]
assert baseline["model_sha256"]=="f6ae697f1f5d686ffdcb96f5451d1a9600d7d41c7bcf324d7e8c276a107e8673"
for name,expected in full["source_sha256_before"].items():assert sha((ROOT/name).read_bytes())==expected,name
assert git("rev-parse","HEAD").decode().strip()=="f037259a0b6abed28f9b50c5cc0c89c6329bee5f"
parent=git("rev-parse","MERGE_HEAD").decode().strip()
assert parent==boundary["current_parent"]=="906ce149fba770a62c9f5f2fbc1b7238b949d423"
files={}
for folder in ["current-parent","current-parent-v2"]:
 for p in (P/folder).rglob("*"):
  if p.is_file():files[p.relative_to(P).as_posix()]=p.read_bytes()
for name in ["commit_authored.py","compose_current.py","compose_current_v2.py","qualify_composition.py","run_current_full.py","receive_current_baseline_failures.py","receive_current_baseline_failures_v2.py","receive_current_baseline_failures_v3.py","receive_current_baseline_failures_v4.py","native-author-commit.json","native-author-commit.stdout.log","native-author-commit.stderr.log","seal_current.py"]:
 files[name]=(P/name).read_bytes()
manifest={name:{"sha256":sha(data),"bytes":len(data)} for name,data in sorted(files.items())}
files["archive-manifest.json"]=(json.dumps(manifest,indent=2)+"\n").encode()
archive=OUT/"current-parent.zip"
assert not archive.exists()
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(2026,10,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,data)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(files)
 for name,data in files.items():assert z.read(name)==data,name
qualification={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"authored_head":"f037259a0b6abed28f9b50c5cc0c89c6329bee5f","current_parent":parent,"current_parent_tree":boundary["current_parent_tree"],"qualified_source_tree":full["source_tree"],"focused":"67 passed","full_native":"478 passed, 36 failed, 35 skipped, 17 subtests passed","baseline_receiving":"All 36 FAILED/SUBFAILED summaries reproduced on unchanged current parent, selecting their 30 containing test nodes; native baseline result 36 failed, 2 passed, 5 subtests passed. Full baseline suite was not repeated.","unowned_current_parent_leaves_exact":composition["unowned_current_parent_leaves_exact"],"source_leaves_unchanged_by_tests":full["checked_source_leaves"],"archive":{"path":archive.name,"entries":len(files),"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size},"publication":"Native source accepted with reproduced baseline failures; only non-triggering source branch and issue checkpoint permitted. Required hosted gate unrun; no PR/main/Actions."}
put(OUT/"current-parent-adoption.json",qualification)
(OUT/"NATIVE-VALIDATION.md").write_bytes("""# Current-parent native qualification

The final model source and tests were composed with current main 906ce149, which
includes the existing cancellation, pytest selection and paired regression work.
All 1,497 unowned current-parent leaves and the exact owned README insertion were
preserved. The source tree before receiving is 937c241ef63ebfc78f8a0deecbbf39144c0eecb2.

On native Windows CPython 3.12.10, the complete model-focused command passed all
67 tests. The full repository command completed with 478 passed, 36 failed,
35 skipped and 17 passing subtests; all 1,509 tracked files remained unchanged.
Every one of those 36 FAILED/SUBFAILED summaries was reproduced on an untouched
checkout of the same current parent, with the original model file. That bounded
baseline run selected the 30 containing test nodes and reported 36 failed,
2 passed and 5 passing subtests. These are retained native baseline failures,
not a claim that the complete repository suite passed. The full baseline suite
was not repeated. Raw commands, versions, failures, skips, outputs and source maps
are in current-parent.zip.

The production model SHA-256 remains 4cd8367f511d32ada95b5d37bdd7faf06f38aa8f15c046cee3dd3eefe2f3cb6c.
The final test file remains 1e875743a2b6a6217fd9c6ca6557cc79dc1e414837ec19796c8273eb93a916d1.
The earlier independent CLI receiving remains bound to its original source pins.

Receiving corrections are retained without editing existing product or tests:
the first merge command lacked an explicit committer identity; the subsequent
preservation helper applied whitespace checking to incoming historical patch
receipts, whose blank context lines must remain exact; its correctly scoped check
of this contribution passed. The first baseline selector incorrectly equated 36
reported failures with 36 test nodes, missing subtests. After including all their
parents, a too-long Windows checkout path failed before testing. A new shorter
owned path admitted the exact original tree and reproduced all 36 failures.
These setup failures and their scripts are included alongside the final receipts.

The sole current workflow, .github/workflows/ci.yml, is unchanged and triggers
only for push to main and pull_request. Under the recovered no-Actions instruction,
a unique non-main source branch and issue checkpoint may be published. No PR,
main merge, workflow changes or Actions run is authorized by this qualification.
The required hosted Python 3.12 gate remains unrun. Quota recovery does not lift
the Actions instruction.
""".encode())
git("add","-f","--","docs/receiving/model-protocol-0378a7b6")
git("diff","--cached",parent,"--check")
p=subprocess.run(["git","-C",str(ROOT),"-c","user.name=HAMON External Contributor 0378a7b6","-c","user.email=chatgpt-0378a7b6b7c2@users.noreply.github.com","commit","-m","Compose response recovery with current planner and sandbox; retain native qualification"],capture_output=True)
(P/"native-current-commit.stdout.log").write_bytes(p.stdout);(P/"native-current-commit.stderr.log").write_bytes(p.stderr)
assert p.returncode==0,p.stderr
assert git("status","--porcelain")==b""
head=git("rev-parse","HEAD").decode().strip();tree=git("rev-parse","HEAD^{tree}").decode().strip()
assert not PUB.exists();PUB.mkdir()
bundle=PUB/"native-history.bundle"
git("bundle","create",str(bundle),"--all")
verified=subprocess.run(["git","-C",str(ROOT),"bundle","verify",str(bundle)],capture_output=True)
(PUB/"bundle-verify.stdout.log").write_bytes(verified.stdout);(PUB/"bundle-verify.stderr.log").write_bytes(verified.stderr)
assert verified.returncode==0,verified.stderr
entries=[];whole={}
for item in git("ls-tree","-r","-z","HEAD").split(b"\0"):
 if not item:continue
 meta,rel=item.split(b"\t",1);mode,kind,blob=meta.decode().split();whole[rel.decode()]={"mode":mode,"type":kind,"sha":blob}
for index,name in enumerate(git("diff","--name-only",parent,"HEAD").decode().splitlines()):
 data=(ROOT/name).read_bytes();blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
 assert whole[name]["sha"]==blob,name
 try:content=data.decode("utf-8");encoding="utf-8"
 except UnicodeDecodeError:content=base64.b64encode(data).decode();encoding="base64"
 entry={"path":name,"mode":whole[name]["mode"],"sha":blob,"sha256":sha(data),"encoding":encoding,"content":content}
 filename="entry-%03d.json"%index;put(PUB/filename,entry)
 entries.append({k:v for k,v in entry.items() if k!="content"}|{"packet":filename})
receipt={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"native_head":head,"native_tree":tree,"qualified_parent":parent,"parent_tree":boundary["current_parent_tree"],"entries":entries,"whole_tree":whole,"bundle":{"path":str(bundle),"sha256":sha(bundle.read_bytes()),"bytes":bundle.stat().st_size},"status":"native accepted; exact non-main source publication pending; hosted gate unrun under no-Actions instruction"}
put(PUB/"publication.json",receipt)
print(json.dumps({k:v for k,v in receipt.items() if k not in ("entries","whole_tree")}|{"changed_paths":len(entries),"total_leaves":len(whole)},indent=2))
