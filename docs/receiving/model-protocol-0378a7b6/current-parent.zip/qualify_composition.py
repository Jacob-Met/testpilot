from pathlib import Path
import subprocess, hashlib, json, datetime, sys, time, os, traceback
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
P = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")/"current-parent-v2"
def git(*args): return subprocess.check_output(["git","-C",str(ROOT),*args])
def sha(data): return hashlib.sha256(data).hexdigest()
head = git("rev-parse","HEAD").decode().strip()
parent = git("rev-parse","MERGE_HEAD").decode().strip()
assert head == "f037259a0b6abed28f9b50c5cc0c89c6329bee5f"
assert parent == "906ce149fba770a62c9f5f2fbc1b7238b949d423"
assert git("diff","--name-only","--diff-filter=U") == b""
owned = {name:sha(git("show",head+":"+name)) for name in git("diff-tree","--no-commit-id","--name-only","-r",head).decode().splitlines()}
errors = []
for name, expected in owned.items():
    if name != "README.md" and sha((ROOT/name).read_bytes()) != expected: errors.append({"path":name,"expected":expected,"actual":sha((ROOT/name).read_bytes()),"type":"owned"})
addition = (P.parent/"readme-owned-addition.txt").read_bytes()
readme = (ROOT/"README.md").read_bytes()
projection = readme.count(addition) == 1 and readme.replace(addition,b"",1) == git("show",parent+":README.md")
if not projection: errors.append({"type":"readme_projection"})
unowned = {}
for entry in git("ls-tree","-r","-z",parent).split(b"\0"):
    if not entry: continue
    meta, rel = entry.split(b"\t",1)
    mode, kind, blob = meta.decode().split()
    name = rel.decode()
    if name in owned: continue
    data = (ROOT/name).read_bytes()
    actual = hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    if actual != blob: errors.append({"path":name,"expected":blob,"actual":actual,"type":"unowned"})
    unowned[name] = blob
checks = {}
for label, args in [("all_incoming",["diff","--cached","--check"]),("owned_delta",["diff","--cached",parent,"--check"])]:
    p = subprocess.run(["git","-C",str(ROOT),*args],capture_output=True)
    (P/(label+"-diff-check.stdout.log")).write_bytes(p.stdout)
    (P/(label+"-diff-check.stderr.log")).write_bytes(p.stderr)
    checks[label] = {"exit_code":p.returncode,"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr),"stdout_bytes":len(p.stdout)}
state = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"authored_head":head,"current_parent":parent,"errors":errors,"unowned_current_parent_leaves_exact":len(unowned) if not errors else None,"readme_projection_exact":projection,"owned_non_readme_exact":len(owned)-1 if not errors else None,"owned_sha256_after":{name:sha((ROOT/name).read_bytes()) for name in owned},"qualified_source_tree_before_testing":git("write-tree").decode().strip(),"unowned_git_blobs":unowned,"diff_checks":checks}
(P/"composition.json").write_bytes((json.dumps(state,indent=2)+"\n").encode())
print(json.dumps({k:v for k,v in state.items() if k != "unowned_git_blobs"},indent=2),flush=True)
assert not errors, errors
assert checks["owned_delta"]["exit_code"] == 0, checks
cmd = [sys.executable,"-m","pytest","-q","-rA","tests/test_model_protocol.py","tests/test_model.py","tests/test_model_timeouts.py"]
env = dict(os.environ,PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
start = time.time()
p = subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=600)
(P/"focused.stdout.log").write_bytes(p.stdout)
(P/"focused.stderr.log").write_bytes(p.stderr)
receipt = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"runtime":sys.version,"exit_code":p.returncode,"seconds":time.time()-start,"source_tree":state["qualified_source_tree_before_testing"],"model_sha256":sha((ROOT/"testpilot/model.py").read_bytes()),"test_sha256":sha((ROOT/"tests/test_model_protocol.py").read_bytes()),"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr)}
(P/"focused.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps(receipt,indent=2),flush=True)
print(p.stdout.decode("utf-8","replace")[-4000:],flush=True)
raise SystemExit(p.returncode)
