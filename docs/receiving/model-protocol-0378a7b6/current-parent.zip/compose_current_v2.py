from pathlib import Path
import subprocess, hashlib, json, datetime
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
P = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")/"current-parent-v2"
P.mkdir()
def git(*args): return subprocess.check_output(["git","-C",str(ROOT),*args])
def sha(data): return hashlib.sha256(data).hexdigest()
head = git("rev-parse","HEAD").decode().strip()
parent = git("rev-parse","FETCH_HEAD").decode().strip()
assert head == "f037259a0b6abed28f9b50c5cc0c89c6329bee5f"
assert parent == "906ce149fba770a62c9f5f2fbc1b7238b949d423"
assert git("status","--porcelain") == b""
(P/"incoming.diff").write_bytes(git("diff","513f17454af378ee042ccd29dc930ef332a48734",parent,"--","README.md","testpilot","tests"))
owned = {}
for name in git("diff-tree","--no-commit-id","--name-only","-r",head).decode().splitlines():
    owned[name] = sha((ROOT/name).read_bytes())
result = subprocess.run(["git","-C",str(ROOT),"-c","user.name=HAMON External Contributor 0378a7b6","-c","user.email=chatgpt-0378a7b6b7c2@users.noreply.github.com","merge","--no-ff","--no-commit",parent],capture_output=True)
(P/"merge.stdout.log").write_bytes(result.stdout)
(P/"merge.stderr.log").write_bytes(result.stderr)
state = {"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"authored_head":head,"current_parent":parent,"merge_exit":result.returncode,"status":git("status","--porcelain").decode(),"conflicts":git("diff","--name-only","--diff-filter=U").decode().splitlines()}
(P/"merge-attempt.json").write_bytes((json.dumps(state,indent=2)+"\n").encode())
assert result.returncode == 0, state
for name, expected in owned.items():
    if name != "README.md": assert sha((ROOT/name).read_bytes()) == expected, name
addition = (P.parent/"readme-owned-addition.txt").read_bytes()
readme = (ROOT/"README.md").read_bytes()
assert readme.count(addition) == 1
assert readme.replace(addition,b"",1) == git("show",parent+":README.md")
unowned = {}
for entry in git("ls-tree","-r","-z",parent).split(b"\0"):
    if not entry: continue
    meta, rel = entry.split(b"\t",1)
    mode, kind, blob = meta.decode().split()
    name = rel.decode()
    if name in owned: continue
    assert kind == "blob" and mode in ("100644","100755"), (name,mode,kind)
    data = (ROOT/name).read_bytes()
    actual = hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert actual == blob, (name,actual,blob)
    unowned[name] = blob
git("diff","--cached","--check")
state.update({"unowned_current_parent_leaves_exact":len(unowned),"readme_projection_exact":True,"owned_non_readme_exact":len(owned)-1,"owned_sha256_after":{name:sha((ROOT/name).read_bytes()) for name in owned},"qualified_source_tree_before_testing":git("write-tree").decode().strip(),"unowned_git_blobs":unowned})
(P/"composition.json").write_bytes((json.dumps(state,indent=2)+"\n").encode())
print(json.dumps({k:v for k,v in state.items() if k not in ("unowned_git_blobs","status")},indent=2))
