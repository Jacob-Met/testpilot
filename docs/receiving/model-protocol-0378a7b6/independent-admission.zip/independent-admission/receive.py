"""Independent, pre-candidate-read protocol consumer. Synthetic localhost only."""
from __future__ import annotations
import hashlib, http.server, io, json, os, subprocess, sys, threading, traceback
from datetime import datetime, timezone
from pathlib import Path
import urllib.error
ROOT=Path(sys.argv[1]).resolve()
PIN=sys.argv[2]
PROOF=Path(__file__).resolve().parent
OUT=PROOF/sys.argv[3]
OUT.mkdir()
ORIGINAL=PROOF.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original_pins={"receive_original.py":"a93dc2d842495ddbb8ae89b62e6db891aede7ebe1e9adc4c4f201ea882433b6b","receipt.json":"8584e5b586eea4558342ce29a8049da0c0a5ab1daa6101f68f32141ea0ce4ab7"}
assert sha(PROOF/"fixtures.json")=="7f549d4fcd27eb65c74ecb20d7a0e33d2c31b61e6b010d6ac757f76bc3f04c98"
for name,digest in original_pins.items(): assert sha(ORIGINAL/name)==digest
assert sha(ROOT/"testpilot/model.py")==PIN
source={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/"testpilot").glob("*.py"))}
git=lambda *a:subprocess.check_output(["git","-C",str(ROOT),*a],text=True).strip()
fixture=json.loads((PROOF/"fixtures.json").read_text(encoding="utf-8"))
overlay=json.loads((PROOF/"contract-overlay.json").read_text(encoding="utf-8"))
cases=[{**c,**overlay["overrides"].get(c["id"],{})} for c in fixture["cases"]]
SOURCE="def nonnegative(value):\n    return max(value, 0)\n"
EXISTING="from subject import nonnegative\n\ndef test_positive():\n    assert nonnegative(2) == 2\n"
DIFF="--- /dev/null\n+++ b/subject.py\n@@ -0,0 +1,2 @@\n+def nonnegative(value):\n+    return max(value, 0)\n"
PLAN="Check a negative argument and keep the existing positive-input case."
BAD="from subject import nonnegative\n\n\ndef test_negative():\n    assert nonnegative(-3) == -3\n"
GOOD=BAD.replace("== -3","== 0")
FENCE=chr(96)*3
block=lambda text:FENCE+"python path=tests/test_generated.py\n"+text+FENCE+"\n"
for c in overlay["additional"]:
    c=dict(c)
    body={"choices":[{"message":{"content":block(GOOD)}}]}
    for key in ("usage","model"):
        if key in c: body[key]=c.pop(key)
    c["body"]=body
    cases.append(c)
env={k:os.environ[k] for k in ("PATH","SystemRoot","WINDIR","COMSPEC","SYSTEMDRIVE") if k in os.environ}
env.update(PYTHONPATH=str(ROOT),PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",NEBIUS_API_KEY="synthetic-local-only",TESTPILOT_PLANNER_MODEL="local-plan",TESTPILOT_EDITOR_MODEL="local-edit",TESTPILOT_PRICES='{"local-plan":[1,2],"local-edit":[3,4]}')
receipt={"at":datetime.now(timezone.utc).isoformat(),"source":str(ROOT),"head":git("rev-parse","HEAD"),"model_sha256":PIN,"python":sys.version,"executable":sys.executable,"fixture_sha256":sha(PROOF/"fixtures.json"),"overlay_sha256":sha(PROOF/"contract-overlay.json"),"driver_sha256":sha(__file__),"runtime_source":source,"cases":[],"transport_controls":[],"failures":[]}
def save():
    (OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
probe=subprocess.run([sys.executable,"-B","-c","import pytest,testpilot;print(pytest.__version__);print(testpilot.__file__)"],cwd=ROOT,env=env,capture_output=True,text=True,encoding="utf-8")
assert probe.returncode==0,probe.stderr
assert str(ROOT).lower() in probe.stdout.lower(),probe.stdout
receipt["runtime_probe"]=probe.stdout.splitlines()
original_report=json.loads((ORIGINAL/"terminal-http-error/output/report.json").read_text(encoding="utf-8"))
for fixture_case in cases:
    case=OUT/fixture_case["id"]
    (case/"project/tests").mkdir(parents=True)
    project=case/"project"
    (project/"subject.py").write_text(SOURCE,encoding="utf-8")
    (project/"tests/test_existing.py").write_text(EXISTING,encoding="utf-8")
    (case/"change.diff").write_text(DIFF,encoding="utf-8")
    (case/"temp").mkdir()
    fixture_before={str(p.relative_to(project)):sha(p) for p in project.rglob("*") if p.is_file()}
    requests=[]
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self,*a): pass
        def do_POST(self):
            data=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            n=len(requests)+1
            requests.append({"ordinal":n,"path":self.path,"model":data["model"],"messages":data["messages"]})
            status=200
            if n<=2:
                body=json.dumps({"choices":[{"message":{"content":PLAN if n==1 else block(BAD)}}],"model":data["model"],"usage":{"prompt_tokens":11 if n==1 else 13,"completion_tokens":7 if n==1 else 5}}).encode()
            else:
                status=fixture_case.get("status",200)
                if "bodyHex" in fixture_case: body=bytes.fromhex(fixture_case["bodyHex"])
                elif "bodyText" in fixture_case: body=fixture_case["bodyText"].encode()
                else: body=json.dumps(fixture_case["body"]).encode()
            self.send_response(status)
            self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    server=http.server.ThreadingHTTPServer(("127.0.0.1",0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    run_env={**env,"TEMP":str(case/"temp"),"TMP":str(case/"temp"),"APPDATA":str(case/"appdata"),"LOCALAPPDATA":str(case/"localappdata")}
    cmd=[sys.executable,"-B","-m","testpilot","run","--repo",str(project),"--diff",str(case/"change.diff"),"--backend","openai","--base-url",f"http://127.0.0.1:{server.server_port}/v1/","--rounds","1","--timeout","10","--no-coverage","--python",sys.executable,"--out",str(case/"output")]
    row={"id":fixture_case["id"],"expected":fixture_case["expected"],"command":cmd}
    try:
        try:
            result=subprocess.run(cmd,cwd=ROOT,env=run_env,capture_output=True,text=True,encoding="utf-8",timeout=35)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=2)
        (case/"stdout.txt").write_text(result.stdout,encoding="utf-8")
        (case/"stderr.txt").write_text(result.stderr,encoding="utf-8")
        (case/"requests.json").write_text(json.dumps(requests,indent=2)+"\n",encoding="utf-8")
        row.update(returncode=result.returncode,requests=len(requests),traceback="Traceback" in result.stderr)
        assert len(requests)==3,("protocol retried",len(requests))
        assert requests[2]["path"]=="/v1/chat/completions"
        assert "assert 0 == -3" in requests[2]["messages"][-1]["content"],"actual generated pytest failure absent"
        assert not row["traceback"],result.stderr
        assert sorted(p.name for p in (case/"output").glob("*"))==["report.html","report.json","report.md","testpilot.patch"]
        report=json.loads((case/"output/report.json").read_text(encoding="utf-8"))
        row.update(status=report["status"],ledger_entries=len(report["ledger"]["entries"]),total_tokens=report["ledger"]["total_tokens"],rounds=len(report["rounds"]),generated=report["final"]["generated"],message=report["message"])
        assert report["status"]==fixture_case["expected"],row
        assert result.returncode==(0 if fixture_case["expected"]=="passed" else 1)
        assert report["plan"]==PLAN
        assert report["rounds"][0]["contents"]=={"tests/test_generated.py":BAD}
        assert report["rounds"][0]["result"]["generated"]=={"collected":1,"passed":0,"failed":1,"error":0,"skipped":0}
        assert report["ledger"]["entries"][:2]==original_report["ledger"]["entries"]
        if fixture_case["expected"]=="model_error":
            assert report["ledger"]==original_report["ledger"],"unknown failed usage entered ledger"
            assert report["test_files"]==original_report["test_files"]
            assert report["patch"]==original_report["patch"]
            assert len(report["rounds"])==1
            assert report["final"]==report["rounds"][0]["result"]
            assert report["message"]
        else:
            assert len(report["ledger"]["entries"])==3
            assert len(report["rounds"])==2
            if "expectedTotal" in fixture_case: assert report["ledger"]["total_tokens"]==fixture_case["expectedTotal"]
            else: assert report["ledger"]["total_tokens"]>36
            assert report["ledger"]["tokens_estimated"]==fixture_case["estimated"]
            assert report["test_files"]=={"tests/test_generated.py":GOOD if fixture_case["expected"]=="passed" else BAD}
            if fixture_case["expected"]=="passed":
                assert report["final"]["ok"] and report["final"]["generated"]["passed"]==1
            else:
                assert report["final"]==report["rounds"][0]["result"],"empty repair invented new execution"
                assert any("no code block" in w for w in report["rounds"][1]["warnings"])
        assert (case/"output/testpilot.patch").read_text(encoding="utf-8")==report["patch"]
        after={str(p.relative_to(project)):sha(p) for p in project.rglob("*") if p.is_file()}
        assert after==fixture_before,"fixture mutation"
        row["pass"]=True
    except Exception as exc:
        row["pass"]=False;row["error"]=repr(exc)
        (case/"receiving-failure.txt").write_text(traceback.format_exc(),encoding="utf-8")
        receipt["failures"].append({"id":row["id"],"error":repr(exc)})
    receipt["cases"].append(row);save()
    print(json.dumps({k:v for k,v in row.items() if k not in ("command","message")}),flush=True)

# Different transport exceptions are deliberately outside protocol normalization.
sys.path.insert(0,str(ROOT))
from testpilot.model import OpenAICompatClient
for cls in (ValueError,KeyboardInterrupt):
    calls=[]
    sentinel=cls("independent custom transport sentinel")
    def raises(*args): calls.append(args);raise sentinel
    client=OpenAICompatClient(api_key="synthetic",transport=raises,retries=2,sleep=lambda _:None)
    try: client.chat("local",[{"role":"user","content":"owned synthetic prompt"}])
    except BaseException as exc:
        assert exc is sentinel,(cls,type(exc))
    else: raise AssertionError(cls)
    assert len(calls)==1
    receipt["transport_controls"].append({"case":cls.__name__,"same_exception":True,"calls":1})
calls=[];sleeps=[]
def sequence(url,headers,body,timeout):
    calls.append((url,json.loads(body),timeout))
    if len(calls)==1: raise TimeoutError("authored timeout")
    if len(calls)==2: raise urllib.error.HTTPError(url,503,"authored retryable status",{},io.BytesIO(b"temporary"))
    return {"choices":[{"message":{"content":"accepted"}}],"usage":{"prompt_tokens":3,"completion_tokens":2}}
client=OpenAICompatClient(base_url="http://127.0.0.1:1/v1",api_key="synthetic",transport=sequence,retries=2,timeout=7,sleep=sleeps.append)
reply=client.chat("local",[{"role":"user","content":"owned synthetic prompt"}],max_tokens=5)
assert len(calls)==3 and calls[0]==calls[1]==calls[2]
assert sleeps==[2,4] and reply.content=="accepted" and reply.usage.total_tokens==5
receipt["transport_controls"].append({"case":"timeout-then-HTTP503-then-success","calls":3,"sleeps":sleeps,"request_preserved":True})
assert {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/"testpilot").glob("*.py"))}==source
for name,digest in original_pins.items(): assert sha(ORIGINAL/name)==digest
receipt["source_and_original_preserved"]=True
receipt["pass"]=not receipt["failures"]
save()
print(json.dumps({"pass":receipt["pass"],"cases":len(receipt["cases"]),"transport_controls":receipt["transport_controls"],"failures":receipt["failures"]},indent=2))
sys.exit(0 if receipt["pass"] else 1)
