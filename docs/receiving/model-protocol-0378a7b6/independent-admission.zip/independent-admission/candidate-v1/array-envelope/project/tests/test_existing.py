from subject import nonnegative

def test_positive():
    assert nonnegative(2) == 2
