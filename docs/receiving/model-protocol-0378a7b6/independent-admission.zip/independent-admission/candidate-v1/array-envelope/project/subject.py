def nonnegative(value):
    return max(value, 0)
