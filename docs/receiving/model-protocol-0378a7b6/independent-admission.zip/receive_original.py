"""Independent original-source CLI receiving; synthetic localhost responses only."""
from __future__ import annotations
import hashlib
import http.server
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
from datetime import datetime, timezone

ROOT=Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-baseline")
PROOF=Path(__file__).resolve().parent
PIN="513f17454af378ee042ccd29dc930ef332a48734"
SOURCE="def nonnegative(value):\n    return max(value, 0)\n"
DIFF="--- /dev/null\n+++ b/subject.py\n@@ -0,0 +1,2 @@\n+def nonnegative(value):\n+    return max(value, 0)\n"
PLAN="Check a negative argument and keep the existing positive-input case."
FENCE=chr(96)*3
GENERATED=FENCE+"python path=tests/test_generated.py\nfrom subject import nonnegative\n\n\ndef test_negative():\n    assert nonnegative(-3) == -3\n"+FENCE+"\n"
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(["git","-C",str(ROOT),*args],text=True).strip()
assert git("rev-parse","HEAD")==PIN
original={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [*sorted((ROOT/"testpilot").glob("*.py")),ROOT/"pyproject.toml",ROOT/"README.md"]}
receipt={"at":datetime.now(timezone.utc).isoformat(),"head":PIN,"tree":git("rev-parse","HEAD^{tree}"),"python":sys.version,"executable":sys.executable,"driver_sha256":sha(Path(__file__).read_bytes()),"source":original,"cases":[]}
env={name:os.environ[name] for name in ("PATH","SystemRoot","WINDIR","COMSPEC","SYSTEMDRIVE") if name in os.environ}
env.update(PYTHONPATH=str(ROOT),PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",NEBIUS_API_KEY="synthetic-local-only",TESTPILOT_PLANNER_MODEL="local-plan",TESTPILOT_EDITOR_MODEL="local-edit",TESTPILOT_PRICES='{"local-plan":[1,2],"local-edit":[3,4]}')
probe=subprocess.run([sys.executable,"-c","import pytest,testpilot;print(pytest.__version__);print(testpilot.__file__)"],cwd=ROOT,env=env,capture_output=True,text=True,encoding="utf-8")
assert probe.returncode==0,probe.stderr
receipt["runtime_probe"]=probe.stdout.splitlines()
assert str(ROOT).lower() in probe.stdout.lower()
for mode in ("terminal-http-error","malformed-json"):
    case=PROOF/mode
    case.mkdir()
    project=case/"project"
    (project/"tests").mkdir(parents=True)
    (project/"subject.py").write_text(SOURCE,encoding="utf-8")
    (project/"tests"/"test_existing.py").write_text("from subject import nonnegative\n\ndef test_positive():\n    assert nonnegative(2) == 2\n",encoding="utf-8")
    (case/"change.diff").write_text(DIFF,encoding="utf-8")
    (case/"temp").mkdir()
    fixture_before={str(p.relative_to(project)):sha(p.read_bytes()) for p in project.rglob("*") if p.is_file()}
    requests=[]
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            data=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            ordinal=len(requests)+1
            requests.append({"ordinal":ordinal,"path":self.path,"model":data["model"],"messages":data["messages"]})
            if ordinal<=2:
                content=PLAN if ordinal==1 else GENERATED
                body=json.dumps({"choices":[{"message":{"content":content}}],"model":data["model"],"usage":{"prompt_tokens":11 if ordinal==1 else 13,"completion_tokens":7 if ordinal==1 else 5}}).encode()
                status=200
            elif mode=="terminal-http-error":
                body=b'{"error":{"message":"authored terminal provider failure"}}'
                status=400
            else:
                body=b'{"choices":'
                status=200
            self.send_response(status)
            self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    server=http.server.ThreadingHTTPServer(("127.0.0.1",0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    run_env={**env,"TEMP":str(case/"temp"),"TMP":str(case/"temp"),"APPDATA":str(case/"appdata"),"LOCALAPPDATA":str(case/"localappdata")}
    command=[sys.executable,"-B","-m","testpilot","run","--repo",str(project),"--diff",str(case/"change.diff"),"--backend","openai","--base-url",f"http://127.0.0.1:{server.server_port}/v1/","--rounds","1","--timeout","10","--no-coverage","--python",sys.executable,"--out",str(case/"output")]
    try:
        run=subprocess.run(command,cwd=ROOT,env=run_env,capture_output=True,text=True,encoding="utf-8",timeout=40)
    finally:
        server.shutdown();server.server_close();thread.join(timeout=2)
    (case/"stdout.txt").write_text(run.stdout,encoding="utf-8")
    (case/"stderr.txt").write_text(run.stderr,encoding="utf-8")
    (case/"requests.json").write_text(json.dumps(requests,indent=2)+"\n",encoding="utf-8")
    row={"mode":mode,"command":command,"returncode":run.returncode,"requests":len(requests),"repair_contains_actual_failure":len(requests)==3 and "assert 0 == -3" in requests[2]["messages"][-1]["content"],"outputs":sorted(p.name for p in (case/"output").glob("*")) if (case/"output").exists() else [],"traceback":"Traceback" in run.stderr,"json_decode_error":"JSONDecodeError" in run.stderr}
    assert len(requests)==3
    assert row["repair_contains_actual_failure"],requests[-1]
    for name,digest in fixture_before.items(): assert sha((project/name).read_bytes())==digest,name
    assert sorted(str(p.relative_to(project)) for p in project.rglob("*") if p.is_file())==sorted(fixture_before)
    row["fixture_preserved"]=True
    if mode=="terminal-http-error":
        report=json.loads((case/"output"/"report.json").read_text(encoding="utf-8"))
        row.update(status=report["status"],ledger_entries=len(report["ledger"]["entries"]),total_tokens=report["ledger"]["total_tokens"],rounds=len(report["rounds"]),test_files=report["test_files"],final=report["final"],plan=report["plan"])
        assert report["status"]=="model_error"
        assert len(report["ledger"]["entries"])==2 and report["ledger"]["total_tokens"]==36
        assert len(report["rounds"])==1 and "test_negative" in report["test_files"]["tests/test_generated.py"]
        assert row["traceback"] is False
        assert (case/"output"/"testpilot.patch").read_text(encoding="utf-8").find("assert nonnegative(-3) == -3")>=0
    else:
        assert row["json_decode_error"] and row["outputs"]==[]
    receipt["cases"].append(row)
for name,digest in original.items(): assert sha((ROOT/name).read_bytes())==digest,name
assert git("status","--porcelain")==""
receipt["source_preserved"]=True
receipt["finding"]="Existing ModelError retention works; malformed JSON on the later HTTP200 repair response raises uncaught JSONDecodeError after actual pytest failure and creates no report or patch."
(PROOF/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in receipt.items() if k not in ("source","cases")},indent=2))
for case in receipt["cases"]:
    print(json.dumps({k:v for k,v in case.items() if k not in ("command","final","test_files","plan")},indent=2))
