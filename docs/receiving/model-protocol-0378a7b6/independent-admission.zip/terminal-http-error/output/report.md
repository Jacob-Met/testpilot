# TestPilot report: **model_error**

HTTP 400 from http://127.0.0.1:50893/v1/chat/completions: {"error":{"message":"authored terminal provider failure"}}

- Changed functions: subject.py::nonnegative
- Tests written: 1 in tests/test_generated.py
- Repair rounds used: 1/1
- Final run: 1 passed, 1 failed, 0 errors, 0 skipped (rc=1); generated: 0 passed of 1 collected in 0.375s
- Coverage: unavailable
- Tokens: 36; cost: $0.000084
  - `local-plan`: 1 calls, 11 in / 7 out
  - `local-edit`: 1 calls, 13 in / 5 out

## Patch

```diff
diff --git a/tests/test_generated.py b/tests/test_generated.py
new file mode 100644
--- /dev/null
+++ b/tests/test_generated.py
@@ -0,0 +1,5 @@
+from subject import nonnegative
+
+
+def test_negative():
+    assert nonnegative(-3) == -3
```
