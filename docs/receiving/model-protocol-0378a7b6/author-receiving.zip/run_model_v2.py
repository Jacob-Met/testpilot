import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
proof = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
command = [sys.executable, "-m", "pytest", "-q", "-rA",
           "tests/test_model_protocol.py", "tests/test_model.py", "tests/test_model_timeouts.py"]
env = dict(os.environ, PYTHONUTF8="1")
start = time.time()
process = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=600)
(proof / "model-v2-focused.stdout.log").write_bytes(process.stdout)
(proof / "model-v2-focused.stderr.log").write_bytes(process.stderr)
receipt = {"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "command": command,
           "runtime": sys.version, "exit_code": process.returncode,
           "seconds": time.time() - start,
           "source_sha256": hashlib.sha256((root / "testpilot/model.py").read_bytes()).hexdigest(),
           "test_sha256": hashlib.sha256((root / "tests/test_model_protocol.py").read_bytes()).hexdigest()}
(proof / "model-v2-focused.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
print(process.stdout.decode("utf-8", "replace")[-4000:])
print(process.stderr.decode("utf-8", "replace")[-1000:])
raise SystemExit(process.returncode)
