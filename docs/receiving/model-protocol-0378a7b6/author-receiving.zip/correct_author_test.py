import hashlib
import json
import shutil
from pathlib import Path

root = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
proof = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
test = root / "tests/test_model_protocol.py"
before = test.read_bytes()
assert hashlib.sha256(before).hexdigest() == "0188439c05e77a3cba48e5108121ff74557bdc708bee74b5b6bba8a3c76a0fdd"
(proof / "test_model_protocol.initial.py").write_bytes(before)
source = before.decode("utf-8")
assert source.count('report["files"]') == 2
source = source.replace('report["files"]', 'report["test_files"]')
old = """            body = bodies[index] if index < len(bodies) else b"unexpected extra request"
            self.send_response(200)
"""
new = """            entry = bodies[index] if index < len(bodies) else b"unexpected extra request"
            status, body = entry if isinstance(entry, tuple) else (200, entry)
            self.send_response(status)
"""
assert source.count(old) == 1
source = source.replace(old, new)
source += """

def test_malformed_reply_after_retryable_http_error_does_not_replay_again():
    delays = []
    with local_responses([(503, b"temporary fixture failure"), b"{unusable reply"]) as (url, calls):
        client = OpenAICompatClient(base_url=url, api_key="local-fixture", retries=2,
                                   timeout=2, sleep=delays.append)
        with pytest.raises(ModelError, match="valid UTF-8 JSON"):
            client.chat("fixture-model", MESSAGES)
        assert len(calls) == 2
        assert calls[0] == calls[1]
    assert delays == [2]
"""
test.write_bytes(source.encode("utf-8"))
initial_runs = Path(r"C:\Windows\Temp\pytest-of-DESKTOP-LA7CMTA$\pytest-5")
saved = []
for run in sorted(initial_runs.glob("test_real_cli_saves_completed_[0-9]")):
    output = run / "output"
    assert output.is_dir()
    destination = proof / "initial-cli-artifacts" / run.name
    shutil.copytree(output, destination)
    saved.append(run.name)
assert len(saved) == 7
receipt = {"correction": 'The author test used "files"; unchanged native LoopResult serializes "test_files". Corrected only the two field references, preserving the same exact expected bodies.',
           "initial_tests_sha256": hashlib.sha256(before).hexdigest(),
           "current_tests_sha256": hashlib.sha256(test.read_bytes()).hexdigest(),
           "model_unchanged_sha256": hashlib.sha256((root / "testpilot/model.py").read_bytes()).hexdigest(),
           "preserved_initial_cli_artifacts": saved,
           "added_check": "Real HTTP503 followed by malformed JSON shares only the previous retry delay and stops after its second request."}
(proof / "author-test-correction.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
runner = (proof / "run_candidate_v1.py").read_text(encoding="utf-8")
(proof / "run_candidate_v2.py").write_text(runner.replace("candidate-v1-focused", "candidate-v2-focused"), encoding="utf-8")
