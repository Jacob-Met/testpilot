import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
proof = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
test = root / "tests/test_model_protocol.py"
before = test.read_bytes()
assert hashlib.sha256(before).hexdigest() == "0a6cf0cad4c0f6285d77f7ed136aee1b322b26432c32f0109eaf460f12bf1674"
(proof / "test_model_protocol.v2_shallow_nesting.py").write_bytes(before)
source = before.decode("utf-8")
old = "        depth = sys.getrecursionlimit() + 10\n"
assert source.count(old) == 1
source = source.replace(old, "        depth = 4000  # Exercise the native JSON decoder's own nesting limit.\n")
test.write_bytes(source.encode("utf-8"))
command = [sys.executable, "-m", "pytest", "-q", "-rA",
           "tests/test_model_protocol.py::test_real_json_decoder_limits_are_terminal_model_errors[nesting-limit]"]
start = time.time()
process = subprocess.run(command, cwd=root, capture_output=True, timeout=60,
                         env=dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1"))
(proof / "nesting-correction.stdout.log").write_bytes(process.stdout)
(proof / "nesting-correction.stderr.log").write_bytes(process.stderr)
receipt = {"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "exit_code": process.returncode,
           "seconds": time.time() - start, "command": command,
           "reason": "The 1010-deep fixture was accepted by this native JSON decoder; its resulting top-level array was correctly refused as a response shape. The receiver had incorrectly assumed sys.getrecursionlimit matched the decoder limit. A bounded 4000-deep fixture exercises the intended decoder RecursionError.",
           "previous_test_sha256": hashlib.sha256(before).hexdigest(),
           "test_sha256": hashlib.sha256(test.read_bytes()).hexdigest(),
           "unchanged_model_sha256": hashlib.sha256((root / "testpilot/model.py").read_bytes()).hexdigest(),
           "prior_native_result": "66 passed; one fixture-depth expectation failed, original log retained.",
           "qualification": "Only the corrected nesting case is repeated here; final normal hosted CI will receive the complete current source."}
(proof / "nesting-correction.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
print(process.stdout.decode("utf-8", "replace"))
raise SystemExit(process.returncode)
