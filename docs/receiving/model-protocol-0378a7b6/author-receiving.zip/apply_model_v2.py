import hashlib
import json
from pathlib import Path

root = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
proof = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
payload = json.loads(r'''{"changes":[{"old":"import json\n","next":"import http.client\nimport json\n"},{"old":"    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (https URL from config)\n        try:\n            return json.loads(resp.read().decode(\"utf-8\"))\n        except (UnicodeDecodeError, json.JSONDecodeError) as exc:\n            # An unusable completed reply is terminal, not a reason to replay\n            # generation. The run retains its earlier work through ModelError.\n            raise ModelError(\"response is not valid UTF-8 JSON\") from exc\n","next":"    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (https URL from config)\n        try:\n            response_bytes = resp.read()\n        except http.client.IncompleteRead as exc:\n            raise ModelError(\"response body incomplete\") from exc\n        try:\n            return json.loads(response_bytes.decode(\"utf-8\"))\n        except (ValueError, RecursionError) as exc:\n            # This catches only decoding failures, including decoder limits.\n            # Errors from a caller-supplied transport keep their own meaning.\n            raise ModelError(\"response could not be decoded as UTF-8 JSON\") from exc\n"},{"old":"                except TimeoutError:\n                    # Preserve a terminal status even if its diagnostic body stalls.\n                    detail = \"response body timed out\"\n                finally:\n","next":"                except TimeoutError:\n                    # Preserve a terminal status even if its diagnostic body stalls.\n                    detail = \"response body timed out\"\n                except http.client.IncompleteRead:\n                    detail = \"response body incomplete\"\n                finally:\n"}],"newTests":"\n\n@pytest.mark.parametrize(\"kind\", [\"integer-limit\", \"nesting-limit\"])\ndef test_real_json_decoder_limits_are_terminal_model_errors(kind):\n    if kind == \"integer-limit\":\n        limit = sys.get_int_max_str_digits()\n        if limit == 0:\n            pytest.skip(\"This interpreter explicitly disables the integer digit limit\")\n        body, cause = b\"7\" * (limit + 1), ValueError\n    else:\n        depth = sys.getrecursionlimit() + 10\n        body, cause = b\"[\" * depth + b\"0\" + b\"]\" * depth, RecursionError\n    delays = []\n    with local_responses([body]) as (url, calls):\n        client = OpenAICompatClient(base_url=url, api_key=\"local-fixture\", retries=2,\n                                   timeout=2, sleep=delays.append)\n        with pytest.raises(ModelError, match=\"decoded as UTF-8 JSON\") as caught:\n            client.chat(\"fixture-model\", MESSAGES)\n        assert isinstance(caught.value.__cause__, cause)\n        assert len(calls) == 1\n    assert delays == []\n\n\n@pytest.mark.parametrize(\"status\", [200, 400, 503])\ndef test_truncated_http_body_preserves_terminal_status_and_retry_budget(status):\n    delays = []\n    expected_calls = 3 if status == 503 else 1\n    with local_responses([(status, b\"cut\", 30)] * expected_calls) as (url, calls):\n        client = OpenAICompatClient(base_url=url, api_key=\"local-fixture\", retries=2,\n                                   timeout=2, sleep=delays.append)\n        with pytest.raises(ModelError, match=\"response body incomplete\") as caught:\n            client.chat(\"fixture-model\", MESSAGES)\n        assert len(calls) == expected_calls\n        assert all(call == calls[0] for call in calls)\n        if status == 200:\n            assert isinstance(caught.value.__cause__, http.client.IncompleteRead)\n        else:\n            assert isinstance(caught.value.__cause__, urllib.error.HTTPError)\n            assert caught.value.__cause__.code == status\n            assert f\"HTTP {status}\" in str(caught.value)\n    assert delays == ([2, 4] if status == 503 else [])\n"}''')
model = root / "testpilot/model.py"
tests = root / "tests/test_model_protocol.py"
assert hashlib.sha256(model.read_bytes()).hexdigest() == "0903eaf677b000dc8f13c4b7d128b51072ee5c88adce8ecce3e227351189ddec"
assert hashlib.sha256(tests.read_bytes()).hexdigest() == "072cda5255854ee83c5a9fd91c29d2f122cd2270b7798905546a1e514bea67cb"
(proof / "model.v1.py").write_bytes(model.read_bytes())
(proof / "test_model_protocol.v1_corrected.py").write_bytes(tests.read_bytes())
source = model.read_text(encoding="utf-8")
for change in payload["changes"]:
    assert source.count(change["old"]) == 1
    source = source.replace(change["old"], change["next"])
model.write_bytes(source.encode("utf-8"))
t = tests.read_text(encoding="utf-8")
t = t.replace("import json\n", "import http.client\nimport json\n").replace("import threading\n", "import threading\nimport urllib.error\n")
assert t.count('            status, body = entry if isinstance(entry, tuple) else (200, entry)') == 1
t = t.replace('            status, body = entry if isinstance(entry, tuple) else (200, entry)', '            status, body, *length = entry if isinstance(entry, tuple) else (200, entry)')
t = t.replace('self.send_header("Content-Length", str(len(body)))', 'self.send_header("Content-Length", str(length[0] if length else len(body)))')
t = t.replace('match="valid UTF-8 JSON"', 'match="decoded as UTF-8 JSON"')
assert t.count('    (2, b"\\xff"),') == 1
t = t.replace('    (2, b"\\xff"),', '    (2, b"\\xff"), (2, (200, b"cut", 30)),')
t += payload["newTests"]
tests.write_bytes(t.encode("utf-8"))
receipt = {"model_sha256": hashlib.sha256(model.read_bytes()).hexdigest(), "tests_sha256": hashlib.sha256(tests.read_bytes()).hexdigest(), "reason": "Handle decoder ValueError/RecursionError only around real UTF-8/JSON decoding; terminal incomplete response bodies and HTTP diagnostic bodies preserve normal ModelError retention without changing unrelated custom transport or retry behavior."}
(proof / "model-v2-source.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt))
runner = (proof / "run_candidate_v1.py").read_text(encoding="utf-8")
(proof / "run_model_v2.py").write_text(runner.replace("candidate-v1-focused", "model-v2-focused"), encoding="utf-8")
