### Retained work after an unusable model reply

An incomplete or undecodable model response now returns `model_error` through
the normal run result. The four outputs retain any earlier plan, generated test
files, pytest results, repair history and admitted usage. The failed response is
not added to the ledger or automatically replayed. See [model response handling](docs/MODEL_RESPONSES.md)
for the supported reply shapes, existing retry rules and saved-work boundaries.

