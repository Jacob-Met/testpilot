# TestPilot report: **model_error**

response is not valid UTF-8 JSON

- Changed functions: sample.py::step
- Tests written: 0 in -
- Repair rounds used: 0/1
- Coverage: unavailable
- Tokens: 20; cost: unpriced (set TESTPILOT_PRICES)
  - `fixture-model`: 1 calls, 14 in / 6 out
