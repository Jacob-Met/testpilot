from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, datetime
ROOT = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-protocol")
AUTHOR = Path(r"C:\Users\minec\testpilot-protocol-author-0378a7b6")
OUT = ROOT / "docs/receiving/model-protocol-0378a7b6"
sha = lambda data: hashlib.sha256(data).hexdigest()
def write_json(path, obj):
    path.write_bytes((json.dumps(obj, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))
pins = {
    "testpilot/model.py": "4cd8367f511d32ada95b5d37bdd7faf06f38aa8f15c046cee3dd3eefe2f3cb6c",
    "tests/test_model_protocol.py": "1e875743a2b6a6217fd9c6ca6557cc79dc1e414837ec19796c8273eb93a916d1",
    "README.md": "3933f0a845e88018021f6b8f73a2f2db5241373ea690218de3807a916eec031a",
    "docs/MODEL_RESPONSES.md": "00f62324c90c3d8630a9b3a82d734f6284c64cc729bff31cdcbbc3e445f7088e",
}
for name, expected in pins.items():
    data = (ROOT/name).read_bytes()
    assert sha(data) == expected, (name, sha(data))
    target = AUTHOR / "final-source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists(): assert target.read_bytes() == data, target
    else: target.write_bytes(data)
assert not OUT.exists(), "Review existing output before repeating a mutation"
OUT.mkdir(parents=True)
write_json(AUTHOR/"final-source-pins.json", pins)
def archive(name, files):
    assert len(files) == len(set(files))
    path = OUT/name
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel, data in sorted(files.items()):
            p = PurePosixPath(rel)
            assert not p.is_absolute() and ".." not in p.parts, rel
            info = zipfile.ZipInfo(rel, (2026,10,8,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    with zipfile.ZipFile(path) as z:
        assert sorted(z.namelist()) == sorted(files)
        for rel, data in files.items(): assert z.read(rel) == data, rel
    data = path.read_bytes()
    return {"file": name, "entries": len(files), "sha256": sha(data), "bytes": len(data)}
def adopt(folder, manifest_name, expected, count, archive_name):
    raw = (folder/manifest_name).read_bytes()
    assert sha(raw) == expected, (manifest_name, sha(raw))
    m = json.loads(raw.decode("utf-8-sig"))
    entries = m["files"] if "files" in m else [{"path": k, "sha256": v} for k, v in m.items()]
    assert len(entries) == count
    files = {manifest_name: raw}
    for item in entries:
        rel = item["path"]
        assert rel not in files
        p = PurePosixPath(rel)
        assert not p.is_absolute() and ".." not in p.parts
        data = (folder/rel).read_bytes()
        assert sha(data) == item["sha256"], rel
        if "bytes" in item: assert len(data) == item["bytes"], rel
        files[rel] = data
    result = archive(archive_name, files)
    result.update({"producer_manifest": manifest_name, "producer_manifest_sha256": expected, "verified_artifacts": count})
    return result
admission = Path(r"C:\Users\minec\testpilot-protocol-receiving-0378a7b6")
decoding = Path(r"C:\Users\minec\hamon-0378a7b6-testpilot-independent-protocol-v3\receiving-packet")
archives = [
    adopt(admission, "independent-manifest.json", "52ecf2c5790f8ca08a2e7549478290f94e325f6ecfd3d2d5a7d3c43f86b0b8b7", 254, "independent-admission.zip"),
    adopt(decoding, "manifest.json", "bc497a8c81c3a2f2e84649de0fa1fc3806e972ab09c643a6b2935b9e4ff8aa5e", 93, "independent-decoding.zip"),
]
for src, dst in [(admission/"independent-admission/ACCEPTANCE.md", "independent-admission.md"), (decoding/"REVIEW.md", "independent-decoding.md")]:
    (OUT/dst).write_bytes(src.read_bytes())
author_files = {p.relative_to(AUTHOR).as_posix(): p.read_bytes() for p in AUTHOR.rglob("*") if p.is_file() and not set(p.parts)&{".git","__pycache__",".pytest_cache"}}
author_manifest = {name: {"sha256": sha(data), "bytes": len(data)} for name, data in sorted(author_files.items())}
author_files["archive-manifest.json"] = (json.dumps(author_manifest, indent=2)+"\n").encode("utf-8")
archives.append(archive("author-receiving.zip", author_files))
result = {"created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "identity": "chatgpt-0378a7b6b7c2/root", "baseline_commit": "513f17454af378ee042ccd29dc930ef332a48734", "final_source_sha256": pins, "archives": archives, "state": "Native authored and independently received; current-parent qualification pending. No TestPilot source publication or Actions trigger. Governed by recovered no-Actions instruction."}
write_json(OUT/"adoption.json", result)
print(json.dumps(result, indent=2))
